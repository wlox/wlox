-- phpMyAdmin SQL Dump
-- version 3.4.11.1deb2+deb7u1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Sep 08, 2014 at 04:53 PM
-- Server version: 5.5.38
-- PHP Version: 5.4.4-14+deb7u12

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `wlox_generic`
--

-- --------------------------------------------------------

--
-- Table structure for table `account_types`
--

CREATE TABLE IF NOT EXISTS `account_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `account_types`
--

INSERT INTO `account_types` (`id`, `name`) VALUES
(1, 'Personal'),
(2, 'Company');

-- --------------------------------------------------------

--
-- Table structure for table `admin_controls`
--

CREATE TABLE IF NOT EXISTS `admin_controls` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `page_id` int(10) unsigned NOT NULL,
  `tab_id` int(10) unsigned NOT NULL,
  `action` varchar(50) NOT NULL,
  `class` varchar(50) DEFAULT NULL,
  `arguments` text NOT NULL,
  `order` smallint(3) NOT NULL DEFAULT '0',
  `is_static` enum('Y','N') NOT NULL DEFAULT 'N',
  PRIMARY KEY (`id`),
  KEY `page_id` (`page_id`),
  KEY `tab_id` (`tab_id`),
  KEY `page_id_2` (`page_id`,`tab_id`,`action`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=269 ;

--
-- Dumping data for table `admin_controls`
--

INSERT INTO `admin_controls` (`id`, `page_id`, `tab_id`, `action`, `class`, `arguments`, `order`, `is_static`) VALUES
(98, 0, 1, 'form', 'Form', 'a:10:{s:4:"name";s:7:"content";s:6:"method";s:0:"";s:5:"class";s:0:"";s:5:"table";s:7:"content";s:14:"return_to_self";s:1:"Y";s:18:"start_on_construct";s:0:"";s:9:"go_to_url";s:0:"";s:12:"go_to_action";s:0:"";s:12:"go_to_is_tab";s:0:"";s:6:"target";s:0:"";}', 0, 'N'),
(99, 0, 1, 'record', 'Record', 'a:1:{s:5:"table";s:7:"content";}', 0, 'N'),
(100, 0, 1, '', 'Grid', 'a:22:{s:5:"table";s:7:"content";s:4:"mode";s:0:"";s:13:"rows_per_page";s:0:"";s:5:"class";s:0:"";s:12:"show_buttons";s:1:"Y";s:14:"target_elem_id";s:7:"content";s:9:"max_pages";s:0:"";s:16:"pagination_label";s:0:"";s:18:"show_list_captions";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:10:"save_order";s:0:"";s:12:"enable_graph";s:0:"";s:12:"enable_table";s:0:"";s:11:"enable_list";s:0:"";s:17:"enable_graph_line";s:0:"";s:16:"enable_graph_pie";s:0:"";s:15:"button_link_url";s:0:"";s:18:"button_link_is_tab";s:0:"";s:10:"sql_filter";s:0:"";s:16:"alert_condition1";s:0:"";s:16:"alert_condition2";s:0:"";}', 0, 'N'),
(23, 0, 4, 'record', 'Record', 'a:1:{s:5:"table";s:6:"emails";}', 0, 'N'),
(24, 0, 4, '', 'MultiList', 'a:4:{s:5:"class";s:0:"";s:8:"dragdrop";s:1:"Y";s:8:"rootname";s:16:"Automated Emails";s:14:"row_end_button";s:0:"";}', 0, 'N'),
(22, 0, 4, 'form', 'Form', 'a:6:{s:4:"name";s:6:"emails";s:6:"method";s:0:"";s:5:"class";s:0:"";s:5:"table";s:6:"emails";s:14:"return_to_self";s:1:"Y";s:18:"start_on_construct";s:0:"";}', 0, 'N'),
(130, 0, 30, 'form', 'Form', 'a:10:{s:4:"name";s:10:"site_users";s:6:"method";s:0:"";s:5:"class";s:0:"";s:5:"table";s:10:"site_users";s:14:"return_to_self";s:1:"Y";s:18:"start_on_construct";s:0:"";s:9:"go_to_url";s:0:"";s:12:"go_to_action";s:0:"";s:12:"go_to_is_tab";s:0:"";s:6:"target";s:0:"";}', 0, 'N'),
(131, 0, 30, 'record', 'Record', 'a:1:{s:5:"table";s:10:"site_users";}', 0, 'N'),
(132, 0, 30, '', 'Grid', 'a:24:{s:5:"table";s:10:"site_users";s:4:"mode";s:0:"";s:13:"rows_per_page";s:0:"";s:5:"class";s:0:"";s:12:"show_buttons";s:1:"Y";s:14:"target_elem_id";s:7:"content";s:9:"max_pages";s:0:"";s:16:"pagination_label";s:0:"";s:18:"show_list_captions";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:10:"save_order";s:0:"";s:12:"enable_graph";s:0:"";s:12:"enable_table";s:0:"";s:11:"enable_list";s:0:"";s:17:"enable_graph_line";s:0:"";s:16:"enable_graph_pie";s:0:"";s:15:"button_link_url";s:0:"";s:18:"button_link_is_tab";s:0:"";s:10:"sql_filter";s:0:"";s:16:"alert_condition1";s:0:"";s:16:"alert_condition2";s:0:"";s:8:"group_by";s:0:"";s:11:"no_group_by";s:0:"";}', 0, 'N'),
(268, 81, 0, '', 'Grid', 'a:24:{s:5:"table";s:12:"fee_schedule";s:4:"mode";s:0:"";s:13:"rows_per_page";s:0:"";s:5:"class";s:0:"";s:12:"show_buttons";s:1:"Y";s:14:"target_elem_id";s:8:"edit_box";s:9:"max_pages";s:0:"";s:16:"pagination_label";s:0:"";s:18:"show_list_captions";s:0:"";s:8:"order_by";s:3:"fee";s:9:"order_asc";s:0:"";s:10:"save_order";s:0:"";s:12:"enable_graph";s:0:"";s:12:"enable_table";s:0:"";s:11:"enable_list";s:0:"";s:17:"enable_graph_line";s:0:"";s:16:"enable_graph_pie";s:0:"";s:15:"button_link_url";s:0:"";s:18:"button_link_is_tab";s:0:"";s:10:"sql_filter";s:0:"";s:16:"alert_condition1";s:0:"";s:16:"alert_condition2";s:0:"";s:8:"group_by";s:0:"";s:11:"no_group_by";s:0:"";}', 0, 'N'),
(239, 82, 0, 'form', 'Form', 'a:10:{s:4:"name";s:6:"phones";s:6:"method";s:0:"";s:5:"class";s:0:"";s:5:"table";s:6:"phones";s:18:"start_on_construct";s:0:"";s:9:"go_to_url";s:0:"";s:12:"go_to_action";s:0:"";s:12:"go_to_is_tab";s:0:"";s:6:"target";s:0:"";s:14:"return_to_self";s:0:"";}', 0, 'N'),
(240, 83, 0, 'form', 'Form', 'a:10:{s:4:"name";s:13:"bank_accounts";s:6:"method";s:0:"";s:5:"class";s:0:"";s:5:"table";s:13:"bank_accounts";s:18:"start_on_construct";s:0:"";s:9:"go_to_url";s:0:"";s:12:"go_to_action";s:0:"";s:12:"go_to_is_tab";s:0:"";s:6:"target";s:0:"";s:14:"return_to_self";s:0:"";}', 0, 'N'),
(237, 81, 0, 'form', 'Form', 'a:10:{s:4:"name";s:12:"fee_schedule";s:6:"method";s:0:"";s:5:"class";s:0:"";s:5:"table";s:12:"fee_schedule";s:18:"start_on_construct";s:0:"";s:9:"go_to_url";s:0:"";s:12:"go_to_action";s:0:"";s:12:"go_to_is_tab";s:0:"";s:6:"target";s:0:"";s:14:"return_to_self";s:0:"";}', 0, 'N'),
(139, 0, 32, 'form', 'Form', 'a:6:{s:4:"name";s:4:"lang";s:6:"method";s:0:"";s:5:"class";s:0:"";s:5:"table";s:4:"lang";s:18:"start_on_construct";s:0:"";s:14:"return_to_self";s:0:"";}', 0, 'N'),
(178, 0, 32, 'record', 'Record', 'a:1:{s:5:"table";s:4:"lang";}', 0, 'N'),
(141, 0, 32, '', 'MultiList', 'a:4:{s:5:"class";s:0:"";s:8:"dragdrop";s:1:"Y";s:8:"rootname";s:14:"Language Table";s:14:"row_end_button";s:0:"";}', 0, 'N'),
(173, 64, 0, 'form', 'Form', 'a:10:{s:4:"name";s:7:"authors";s:6:"method";s:0:"";s:5:"class";s:0:"";s:5:"table";s:7:"authors";s:18:"start_on_construct";s:0:"";s:9:"go_to_url";s:0:"";s:12:"go_to_action";s:0:"";s:12:"go_to_is_tab";s:0:"";s:6:"target";s:0:"";s:14:"return_to_self";s:0:"";}', 0, 'N'),
(174, 64, 0, 'record', 'Record', 'a:1:{s:5:"table";s:7:"authors";}', 0, 'N'),
(175, 64, 0, '', 'Grid', 'a:24:{s:5:"table";s:7:"authors";s:4:"mode";s:0:"";s:13:"rows_per_page";s:0:"";s:5:"class";s:0:"";s:12:"show_buttons";s:1:"Y";s:14:"target_elem_id";s:8:"edit_box";s:9:"max_pages";s:0:"";s:16:"pagination_label";s:0:"";s:18:"show_list_captions";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:10:"save_order";s:0:"";s:12:"enable_graph";s:0:"";s:12:"enable_table";s:0:"";s:11:"enable_list";s:0:"";s:17:"enable_graph_line";s:0:"";s:16:"enable_graph_pie";s:0:"";s:15:"button_link_url";s:0:"";s:18:"button_link_is_tab";s:0:"";s:10:"sql_filter";s:0:"";s:16:"alert_condition1";s:0:"";s:16:"alert_condition2";s:0:"";s:8:"group_by";s:0:"";s:11:"no_group_by";s:0:"";}', 0, 'N'),
(243, 84, 0, '', 'Grid', 'a:24:{s:5:"table";s:17:"bitcoin_addresses";s:4:"mode";s:0:"";s:13:"rows_per_page";s:0:"";s:5:"class";s:0:"";s:12:"show_buttons";s:1:"Y";s:14:"target_elem_id";s:8:"edit_box";s:9:"max_pages";s:0:"";s:16:"pagination_label";s:0:"";s:18:"show_list_captions";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:10:"save_order";s:0:"";s:12:"enable_graph";s:0:"";s:12:"enable_table";s:0:"";s:11:"enable_list";s:0:"";s:17:"enable_graph_line";s:0:"";s:16:"enable_graph_pie";s:0:"";s:15:"button_link_url";s:0:"";s:18:"button_link_is_tab";s:0:"";s:10:"sql_filter";s:0:"";s:16:"alert_condition1";s:0:"";s:16:"alert_condition2";s:0:"";s:8:"group_by";s:0:"";s:11:"no_group_by";s:0:"";}', 0, 'N'),
(242, 84, 0, 'form', 'Form', 'a:10:{s:4:"name";s:17:"bitcoin_addresses";s:6:"method";s:0:"";s:5:"class";s:0:"";s:5:"table";s:17:"bitcoin_addresses";s:18:"start_on_construct";s:0:"";s:9:"go_to_url";s:0:"";s:12:"go_to_action";s:0:"";s:12:"go_to_is_tab";s:0:"";s:6:"target";s:0:"";s:14:"return_to_self";s:0:"";}', 0, 'N'),
(241, 83, 0, '', 'Grid', 'a:24:{s:5:"table";s:13:"bank_accounts";s:4:"mode";s:0:"";s:13:"rows_per_page";s:0:"";s:5:"class";s:0:"";s:12:"show_buttons";s:1:"Y";s:14:"target_elem_id";s:8:"edit_box";s:9:"max_pages";s:0:"";s:16:"pagination_label";s:0:"";s:18:"show_list_captions";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:10:"save_order";s:0:"";s:12:"enable_graph";s:0:"";s:12:"enable_table";s:0:"";s:11:"enable_list";s:0:"";s:17:"enable_graph_line";s:0:"";s:16:"enable_graph_pie";s:0:"";s:15:"button_link_url";s:0:"";s:18:"button_link_is_tab";s:0:"";s:10:"sql_filter";s:0:"";s:16:"alert_condition1";s:0:"";s:16:"alert_condition2";s:0:"";s:8:"group_by";s:0:"";s:11:"no_group_by";s:0:"";}', 0, 'N'),
(210, 0, 62, 'form', 'Form', 'a:10:{s:4:"name";s:6:"orders";s:6:"method";s:0:"";s:5:"class";s:0:"";s:5:"table";s:6:"orders";s:18:"start_on_construct";s:0:"";s:9:"go_to_url";s:0:"";s:12:"go_to_action";s:0:"";s:12:"go_to_is_tab";s:0:"";s:6:"target";s:0:"";s:14:"return_to_self";s:0:"";}', 0, 'N'),
(211, 74, 0, 'form', 'Form', 'a:10:{s:4:"name";s:11:"order_types";s:6:"method";s:0:"";s:5:"class";s:0:"";s:5:"table";s:11:"order_types";s:18:"start_on_construct";s:0:"";s:9:"go_to_url";s:0:"";s:12:"go_to_action";s:0:"";s:12:"go_to_is_tab";s:0:"";s:6:"target";s:0:"";s:14:"return_to_self";s:0:"";}', 0, 'N'),
(212, 74, 0, 'record', 'Record', 'a:1:{s:5:"table";s:11:"order_types";}', 0, 'N'),
(213, 74, 0, '', 'MultiList', 'a:4:{s:5:"class";s:0:"";s:8:"dragdrop";s:1:"Y";s:8:"rootname";s:11:"Order Types";s:14:"row_end_button";s:0:"";}', 0, 'N'),
(214, 0, 62, 'record', 'Record', 'a:1:{s:5:"table";s:6:"orders";}', 0, 'N'),
(215, 0, 62, '', 'Grid', 'a:24:{s:5:"table";s:6:"orders";s:4:"mode";s:0:"";s:13:"rows_per_page";s:0:"";s:5:"class";s:0:"";s:12:"show_buttons";s:1:"Y";s:14:"target_elem_id";s:8:"edit_box";s:9:"max_pages";s:0:"";s:16:"pagination_label";s:0:"";s:18:"show_list_captions";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:10:"save_order";s:0:"";s:12:"enable_graph";s:0:"";s:12:"enable_table";s:0:"";s:11:"enable_list";s:0:"";s:17:"enable_graph_line";s:0:"";s:16:"enable_graph_pie";s:0:"";s:15:"button_link_url";s:0:"";s:18:"button_link_is_tab";s:0:"";s:10:"sql_filter";s:0:"";s:16:"alert_condition1";s:0:"";s:16:"alert_condition2";s:0:"";s:8:"group_by";s:0:"";s:11:"no_group_by";s:0:"";}', 0, 'N'),
(216, 75, 0, 'form', 'Form', 'a:10:{s:4:"name";s:12:"transactions";s:6:"method";s:0:"";s:5:"class";s:0:"";s:5:"table";s:12:"transactions";s:14:"return_to_self";s:1:"Y";s:18:"start_on_construct";s:0:"";s:9:"go_to_url";s:0:"";s:12:"go_to_action";s:0:"";s:12:"go_to_is_tab";s:0:"";s:6:"target";s:0:"";}', 0, 'N'),
(217, 75, 0, 'record', 'Record', 'a:1:{s:5:"table";s:12:"transactions";}', 0, 'N'),
(218, 75, 0, '', 'Grid', 'a:24:{s:5:"table";s:12:"transactions";s:4:"mode";s:0:"";s:13:"rows_per_page";s:0:"";s:5:"class";s:0:"";s:12:"show_buttons";s:1:"Y";s:14:"target_elem_id";s:7:"content";s:9:"max_pages";s:0:"";s:16:"pagination_label";s:0:"";s:18:"show_list_captions";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:10:"save_order";s:0:"";s:12:"enable_graph";s:0:"";s:12:"enable_table";s:0:"";s:11:"enable_list";s:0:"";s:17:"enable_graph_line";s:0:"";s:16:"enable_graph_pie";s:0:"";s:15:"button_link_url";s:0:"";s:18:"button_link_is_tab";s:0:"";s:10:"sql_filter";s:0:"";s:16:"alert_condition1";s:0:"";s:16:"alert_condition2";s:0:"";s:8:"group_by";s:0:"";s:11:"no_group_by";s:0:"";}', 0, 'N'),
(219, 76, 0, 'form', 'Form', 'a:10:{s:4:"name";s:17:"transaction_types";s:6:"method";s:0:"";s:5:"class";s:0:"";s:5:"table";s:17:"transaction_types";s:18:"start_on_construct";s:0:"";s:9:"go_to_url";s:0:"";s:12:"go_to_action";s:0:"";s:12:"go_to_is_tab";s:0:"";s:6:"target";s:0:"";s:14:"return_to_self";s:0:"";}', 0, 'N'),
(220, 76, 0, 'record', 'Record', 'a:1:{s:5:"table";s:17:"transaction_types";}', 0, 'N'),
(221, 76, 0, '', 'MultiList', 'a:4:{s:5:"class";s:0:"";s:8:"rootname";s:17:"Transaction Types";s:14:"row_end_button";s:0:"";s:8:"dragdrop";s:0:"";}', 0, 'N'),
(222, 77, 0, 'form', 'Form', 'a:10:{s:4:"name";s:13:"request_types";s:6:"method";s:0:"";s:5:"class";s:0:"";s:5:"table";s:13:"request_types";s:18:"start_on_construct";s:0:"";s:9:"go_to_url";s:0:"";s:12:"go_to_action";s:0:"";s:12:"go_to_is_tab";s:0:"";s:6:"target";s:0:"";s:14:"return_to_self";s:0:"";}', 0, 'N'),
(223, 77, 0, 'record', 'Record', 'a:1:{s:5:"table";s:13:"request_types";}', 0, 'N'),
(224, 77, 0, '', 'MultiList', 'a:4:{s:5:"class";s:0:"";s:8:"rootname";s:13:"Request Types";s:14:"row_end_button";s:0:"";s:8:"dragdrop";s:0:"";}', 0, 'N'),
(225, 0, 63, 'form', 'Form', 'a:10:{s:4:"name";s:8:"requests";s:6:"method";s:0:"";s:5:"class";s:0:"";s:5:"table";s:8:"requests";s:18:"start_on_construct";s:0:"";s:9:"go_to_url";s:0:"";s:12:"go_to_action";s:0:"";s:12:"go_to_is_tab";s:0:"";s:6:"target";s:0:"";s:14:"return_to_self";s:0:"";}', 0, 'N'),
(226, 78, 0, 'form', 'Form', 'a:10:{s:4:"name";s:14:"request_status";s:6:"method";s:0:"";s:5:"class";s:0:"";s:5:"table";s:14:"request_status";s:18:"start_on_construct";s:0:"";s:9:"go_to_url";s:0:"";s:12:"go_to_action";s:0:"";s:12:"go_to_is_tab";s:0:"";s:6:"target";s:0:"";s:14:"return_to_self";s:0:"";}', 0, 'N'),
(227, 78, 0, 'record', 'Record', 'a:1:{s:5:"table";s:14:"request_status";}', 0, 'N'),
(228, 78, 0, '', 'MultiList', 'a:4:{s:5:"class";s:0:"";s:8:"rootname";s:14:"Request Status";s:14:"row_end_button";s:0:"";s:8:"dragdrop";s:0:"";}', 0, 'N'),
(229, 79, 0, 'form', 'Form', 'a:10:{s:4:"name";s:20:"request_descriptions";s:6:"method";s:0:"";s:5:"class";s:0:"";s:5:"table";s:20:"request_descriptions";s:18:"start_on_construct";s:0:"";s:9:"go_to_url";s:0:"";s:12:"go_to_action";s:0:"";s:12:"go_to_is_tab";s:0:"";s:6:"target";s:0:"";s:14:"return_to_self";s:0:"";}', 0, 'N'),
(230, 79, 0, 'record', 'Record', 'a:1:{s:5:"table";s:20:"request_descriptions";}', 0, 'N'),
(231, 79, 0, '', 'MultiList', 'a:4:{s:5:"class";s:0:"";s:8:"rootname";s:20:"Request Descriptions";s:14:"row_end_button";s:0:"";s:8:"dragdrop";s:0:"";}', 0, 'N'),
(232, 0, 63, 'record', 'Record', 'a:1:{s:5:"table";s:8:"requests";}', 0, 'N'),
(233, 0, 63, '', 'Grid', 'a:24:{s:5:"table";s:8:"requests";s:4:"mode";s:0:"";s:13:"rows_per_page";s:0:"";s:5:"class";s:0:"";s:12:"show_buttons";s:1:"Y";s:14:"target_elem_id";s:8:"edit_box";s:9:"max_pages";s:0:"";s:16:"pagination_label";s:0:"";s:18:"show_list_captions";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:10:"save_order";s:0:"";s:12:"enable_graph";s:0:"";s:12:"enable_table";s:0:"";s:11:"enable_list";s:0:"";s:17:"enable_graph_line";s:0:"";s:16:"enable_graph_pie";s:0:"";s:15:"button_link_url";s:0:"";s:18:"button_link_is_tab";s:0:"";s:10:"sql_filter";s:0:"";s:16:"alert_condition1";s:111:"''[request_status]'' == ''Pending'' && ''[currency]'' != ''BTC'' && ''[request_type]'' == ''Withdrawal'' && ''[done]'' != ''Y''";s:16:"alert_condition2";s:26:"strlen(''[site_user]'') <= 1";s:8:"group_by";s:0:"";s:11:"no_group_by";s:0:"";}', 0, 'N'),
(234, 80, 0, 'form', 'Form', 'a:10:{s:4:"name";s:4:"news";s:6:"method";s:0:"";s:5:"class";s:0:"";s:5:"table";s:4:"news";s:14:"return_to_self";s:1:"Y";s:18:"start_on_construct";s:0:"";s:9:"go_to_url";s:0:"";s:12:"go_to_action";s:0:"";s:12:"go_to_is_tab";s:0:"";s:6:"target";s:0:"";}', 0, 'N'),
(235, 80, 0, 'record', 'Record', 'a:1:{s:5:"table";s:4:"news";}', 0, 'N'),
(236, 80, 0, '', 'Grid', 'a:24:{s:5:"table";s:4:"news";s:4:"mode";s:0:"";s:13:"rows_per_page";s:0:"";s:5:"class";s:0:"";s:12:"show_buttons";s:1:"Y";s:14:"target_elem_id";s:7:"content";s:9:"max_pages";s:0:"";s:16:"pagination_label";s:0:"";s:18:"show_list_captions";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:10:"save_order";s:0:"";s:12:"enable_graph";s:0:"";s:12:"enable_table";s:0:"";s:11:"enable_list";s:0:"";s:17:"enable_graph_line";s:0:"";s:16:"enable_graph_pie";s:0:"";s:15:"button_link_url";s:0:"";s:18:"button_link_is_tab";s:0:"";s:10:"sql_filter";s:0:"";s:16:"alert_condition1";s:0:"";s:16:"alert_condition2";s:0:"";s:8:"group_by";s:0:"";s:11:"no_group_by";s:0:"";}', 0, 'N'),
(244, 0, 64, 'form', 'Form', 'a:10:{s:4:"name";s:6:"status";s:6:"method";s:0:"";s:5:"class";s:0:"";s:5:"table";s:6:"status";s:14:"return_to_self";s:1:"Y";s:18:"start_on_construct";s:0:"";s:9:"go_to_url";s:0:"";s:12:"go_to_action";s:0:"";s:12:"go_to_is_tab";s:0:"";s:6:"target";s:0:"";}', 0, 'N'),
(245, 0, 64, '', 'MultiList', 'a:4:{s:5:"class";s:0:"";s:8:"rootname";s:6:"Status";s:14:"row_end_button";s:0:"";s:8:"dragdrop";s:0:"";}', 0, 'N'),
(246, 85, 0, 'form', 'Form', 'a:10:{s:4:"name";s:4:"fees";s:6:"method";s:0:"";s:5:"class";s:0:"";s:5:"table";s:4:"fees";s:18:"start_on_construct";s:0:"";s:9:"go_to_url";s:0:"";s:12:"go_to_action";s:0:"";s:12:"go_to_is_tab";s:0:"";s:6:"target";s:0:"";s:14:"return_to_self";s:0:"";}', 0, 'N'),
(247, 85, 0, '', 'Grid', 'a:24:{s:5:"table";s:4:"fees";s:4:"mode";s:0:"";s:13:"rows_per_page";s:0:"";s:5:"class";s:0:"";s:14:"target_elem_id";s:8:"edit_box";s:9:"max_pages";s:0:"";s:16:"pagination_label";s:0:"";s:18:"show_list_captions";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:10:"save_order";s:0:"";s:12:"enable_graph";s:0:"";s:12:"enable_table";s:0:"";s:11:"enable_list";s:0:"";s:17:"enable_graph_line";s:0:"";s:16:"enable_graph_pie";s:0:"";s:15:"button_link_url";s:0:"";s:18:"button_link_is_tab";s:0:"";s:10:"sql_filter";s:0:"";s:16:"alert_condition1";s:0:"";s:16:"alert_condition2";s:0:"";s:8:"group_by";s:0:"";s:11:"no_group_by";s:0:"";s:12:"show_buttons";s:0:"";}', 0, 'N'),
(248, 86, 0, 'form', 'Form', 'a:10:{s:4:"name";s:13:"daily_reports";s:6:"method";s:0:"";s:5:"class";s:0:"";s:5:"table";s:13:"daily_reports";s:18:"start_on_construct";s:0:"";s:9:"go_to_url";s:0:"";s:12:"go_to_action";s:0:"";s:12:"go_to_is_tab";s:0:"";s:6:"target";s:0:"";s:14:"return_to_self";s:0:"";}', 0, 'N'),
(249, 86, 0, '', 'Grid', 'a:24:{s:5:"table";s:13:"daily_reports";s:4:"mode";s:0:"";s:13:"rows_per_page";s:0:"";s:5:"class";s:0:"";s:14:"target_elem_id";s:8:"edit_box";s:9:"max_pages";s:0:"";s:16:"pagination_label";s:0:"";s:18:"show_list_captions";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:10:"save_order";s:0:"";s:12:"enable_graph";s:0:"";s:12:"enable_table";s:1:"1";s:11:"enable_list";s:0:"";s:17:"enable_graph_line";s:1:"1";s:16:"enable_graph_pie";s:0:"";s:15:"button_link_url";s:0:"";s:18:"button_link_is_tab";s:0:"";s:10:"sql_filter";s:0:"";s:16:"alert_condition1";s:0:"";s:16:"alert_condition2";s:0:"";s:8:"group_by";s:0:"";s:11:"no_group_by";s:0:"";s:12:"show_buttons";s:0:"";}', 0, 'N'),
(250, 87, 0, 'form', 'Form', 'a:10:{s:4:"name";s:15:"monthly_reports";s:6:"method";s:0:"";s:5:"class";s:0:"";s:5:"table";s:15:"monthly_reports";s:18:"start_on_construct";s:0:"";s:9:"go_to_url";s:0:"";s:12:"go_to_action";s:0:"";s:12:"go_to_is_tab";s:0:"";s:6:"target";s:0:"";s:14:"return_to_self";s:0:"";}', 0, 'N'),
(251, 87, 0, '', 'Grid', 'a:24:{s:5:"table";s:15:"monthly_reports";s:4:"mode";s:0:"";s:13:"rows_per_page";s:0:"";s:5:"class";s:0:"";s:14:"target_elem_id";s:8:"edit_box";s:9:"max_pages";s:0:"";s:16:"pagination_label";s:0:"";s:18:"show_list_captions";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:10:"save_order";s:0:"";s:12:"enable_graph";s:0:"";s:12:"enable_table";s:1:"1";s:11:"enable_list";s:0:"";s:17:"enable_graph_line";s:1:"1";s:16:"enable_graph_pie";s:0:"";s:15:"button_link_url";s:0:"";s:18:"button_link_is_tab";s:0:"";s:10:"sql_filter";s:0:"";s:16:"alert_condition1";s:0:"";s:16:"alert_condition2";s:0:"";s:8:"group_by";s:0:"";s:11:"no_group_by";s:0:"";s:12:"show_buttons";s:0:"";}', 0, 'N'),
(252, 88, 0, 'form', 'Form', 'a:10:{s:4:"name";s:9:"order_log";s:6:"method";s:0:"";s:5:"class";s:0:"";s:5:"table";s:9:"order_log";s:18:"start_on_construct";s:0:"";s:9:"go_to_url";s:0:"";s:12:"go_to_action";s:0:"";s:12:"go_to_is_tab";s:0:"";s:6:"target";s:0:"";s:14:"return_to_self";s:0:"";}', 0, 'N'),
(253, 88, 0, 'record', 'Record', 'a:1:{s:5:"table";s:9:"order_log";}', 0, 'N'),
(254, 88, 0, '', 'Grid', 'a:24:{s:5:"table";s:9:"order_log";s:4:"mode";s:0:"";s:13:"rows_per_page";s:0:"";s:5:"class";s:0:"";s:12:"show_buttons";s:1:"Y";s:14:"target_elem_id";s:8:"edit_box";s:9:"max_pages";s:0:"";s:16:"pagination_label";s:0:"";s:18:"show_list_captions";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:10:"save_order";s:0:"";s:12:"enable_graph";s:0:"";s:12:"enable_table";s:0:"";s:11:"enable_list";s:0:"";s:17:"enable_graph_line";s:0:"";s:16:"enable_graph_pie";s:0:"";s:15:"button_link_url";s:0:"";s:18:"button_link_is_tab";s:0:"";s:10:"sql_filter";s:0:"";s:16:"alert_condition1";s:0:"";s:16:"alert_condition2";s:0:"";s:8:"group_by";s:0:"";s:11:"no_group_by";s:0:"";}', 0, 'N'),
(255, 89, 0, '', 'CustomPHP', 'a:1:{s:3:"url";s:20:"deposit-withdraw.php";}', 0, 'N'),
(256, 90, 0, 'form', 'Form', 'a:10:{s:4:"name";s:10:"currencies";s:6:"method";s:0:"";s:5:"class";s:0:"";s:5:"table";s:10:"currencies";s:18:"start_on_construct";s:0:"";s:9:"go_to_url";s:0:"";s:12:"go_to_action";s:0:"";s:12:"go_to_is_tab";s:0:"";s:6:"target";s:0:"";s:14:"return_to_self";s:0:"";}', 0, 'N'),
(257, 90, 0, '', 'Grid', 'a:24:{s:5:"table";s:10:"currencies";s:4:"mode";s:0:"";s:13:"rows_per_page";s:0:"";s:5:"class";s:0:"";s:12:"show_buttons";s:1:"Y";s:14:"target_elem_id";s:8:"edit_box";s:9:"max_pages";s:0:"";s:16:"pagination_label";s:0:"";s:18:"show_list_captions";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:10:"save_order";s:0:"";s:12:"enable_graph";s:0:"";s:12:"enable_table";s:0:"";s:11:"enable_list";s:0:"";s:17:"enable_graph_line";s:0:"";s:16:"enable_graph_pie";s:0:"";s:15:"button_link_url";s:0:"";s:18:"button_link_is_tab";s:0:"";s:10:"sql_filter";s:0:"";s:16:"alert_condition1";s:0:"";s:16:"alert_condition2";s:0:"";s:8:"group_by";s:0:"";s:11:"no_group_by";s:0:"";}', 0, 'N'),
(258, 92, 0, 'form', 'Form', 'a:10:{s:4:"name";s:15:"history_actions";s:6:"method";s:0:"";s:5:"class";s:0:"";s:5:"table";s:15:"history_actions";s:18:"start_on_construct";s:0:"";s:9:"go_to_url";s:0:"";s:12:"go_to_action";s:0:"";s:12:"go_to_is_tab";s:0:"";s:6:"target";s:0:"";s:14:"return_to_self";s:0:"";}', 0, 'N'),
(260, 92, 0, '', 'MultiList', 'a:4:{s:5:"class";s:0:"";s:8:"rootname";s:15:"History Actions";s:14:"row_end_button";s:0:"";s:8:"dragdrop";s:0:"";}', 0, 'N'),
(261, 91, 0, 'form', 'Form', 'a:10:{s:4:"name";s:7:"history";s:6:"method";s:0:"";s:5:"class";s:0:"";s:5:"table";s:7:"history";s:18:"start_on_construct";s:0:"";s:9:"go_to_url";s:0:"";s:12:"go_to_action";s:0:"";s:12:"go_to_is_tab";s:0:"";s:6:"target";s:0:"";s:14:"return_to_self";s:0:"";}', 0, 'N'),
(262, 91, 0, 'record', 'Record', 'a:1:{s:5:"table";s:7:"history";}', 0, 'N'),
(263, 91, 0, '', 'Grid', 'a:24:{s:5:"table";s:7:"history";s:4:"mode";s:0:"";s:13:"rows_per_page";s:0:"";s:5:"class";s:0:"";s:12:"show_buttons";s:1:"Y";s:14:"target_elem_id";s:8:"edit_box";s:9:"max_pages";s:0:"";s:16:"pagination_label";s:0:"";s:18:"show_list_captions";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:10:"save_order";s:0:"";s:12:"enable_graph";s:0:"";s:12:"enable_table";s:0:"";s:11:"enable_list";s:0:"";s:17:"enable_graph_line";s:0:"";s:16:"enable_graph_pie";s:0:"";s:15:"button_link_url";s:0:"";s:18:"button_link_is_tab";s:0:"";s:10:"sql_filter";s:0:"";s:16:"alert_condition1";s:0:"";s:16:"alert_condition2";s:0:"";s:8:"group_by";s:0:"";s:11:"no_group_by";s:0:"";}', 0, 'N'),
(264, 0, 30, 'form', 'Tabs', 'a:5:{s:5:"class";s:0:"";s:11:"target_elem";s:8:"edit_box";s:8:"callback";s:0:"";s:8:"is_inset";s:1:"1";s:1:"i";s:0:"";}', 1, 'N'),
(265, 0, 30, 'record', 'Tabs', 'a:5:{s:5:"class";s:0:"";s:11:"target_elem";s:8:"edit_box";s:8:"callback";s:0:"";s:8:"is_inset";s:1:"1";s:1:"i";s:0:"";}', 0, 'N'),
(266, 93, 0, 'form', 'Form', 'a:10:{s:4:"name";s:11:"conversions";s:6:"method";s:0:"";s:5:"class";s:0:"";s:5:"table";s:11:"conversions";s:18:"start_on_construct";s:0:"";s:9:"go_to_url";s:0:"";s:12:"go_to_action";s:0:"";s:12:"go_to_is_tab";s:0:"";s:6:"target";s:0:"";s:14:"return_to_self";s:0:"";}', 0, 'N'),
(267, 93, 0, '', 'Grid', 'a:24:{s:5:"table";s:11:"conversions";s:4:"mode";s:0:"";s:13:"rows_per_page";s:0:"";s:5:"class";s:0:"";s:12:"show_buttons";s:1:"Y";s:14:"target_elem_id";s:8:"edit_box";s:9:"max_pages";s:0:"";s:16:"pagination_label";s:0:"";s:18:"show_list_captions";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:10:"save_order";s:0:"";s:12:"enable_graph";s:0:"";s:12:"enable_table";s:0:"";s:11:"enable_list";s:0:"";s:17:"enable_graph_line";s:0:"";s:16:"enable_graph_pie";s:0:"";s:15:"button_link_url";s:0:"";s:18:"button_link_is_tab";s:0:"";s:10:"sql_filter";s:0:"";s:16:"alert_condition1";s:0:"";s:16:"alert_condition2";s:0:"";s:8:"group_by";s:0:"";s:11:"no_group_by";s:0:"";}', 0, 'N');

-- --------------------------------------------------------

--
-- Table structure for table `admin_controls_methods`
--

CREATE TABLE IF NOT EXISTS `admin_controls_methods` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `method` varchar(100) DEFAULT NULL,
  `arguments` text NOT NULL,
  `order` smallint(3) NOT NULL DEFAULT '0',
  `control_id` int(10) unsigned NOT NULL,
  `p_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `control_id` (`control_id`),
  KEY `p_id` (`p_id`),
  KEY `order` (`order`,`control_id`,`p_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2263 ;

--
-- Dumping data for table `admin_controls_methods`
--

INSERT INTO `admin_controls_methods` (`id`, `method`, `arguments`, `order`, `control_id`, `p_id`) VALUES
(418, 'textInput', 'a:13:{s:4:"name";s:8:"title_en";s:7:"caption";s:10:"Title (EN)";s:8:"required";s:1:"1";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 5, 98, 0),
(419, 'textInput', 'a:13:{s:4:"name";s:3:"url";s:7:"caption";s:19:"URL (do not change)";s:8:"required";s:1:"1";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 7, 98, 0),
(420, 'textEditor', 'a:11:{s:4:"name";s:10:"content_en";s:7:"caption";s:12:"Content (EN)";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:7:"echo_on";s:0:"";s:5:"class";s:0:"";s:8:"is_basic";s:0:"";s:12:"allow_images";s:1:"1";s:6:"height";s:0:"";s:9:"method_id";s:0:"";}', 8, 98, 0),
(421, 'submitButton', 'a:6:{s:4:"name";s:7:"guardar";s:5:"value";s:4:"Save";s:2:"id";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";}', 10, 98, 0),
(422, 'cancelButton', 'a:4:{s:5:"value";s:4:"Back";s:2:"id";s:0:"";s:5:"class";s:0:"";s:5:"style";s:0:"";}', 12, 98, 0),
(423, 'button', 'a:12:{s:3:"url";s:7:"content";s:5:"value";s:5:"Close";s:9:"variables";a:3:{s:6:"is_tab";s:1:"1";s:6:"action";s:6:"record";s:2:"id";s:2:"id";}s:14:"target_elem_id";s:0:"";s:2:"id";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:23:"disable_if_no_record_id";s:1:"1";s:20:"disable_if_cant_edit";s:0:"";s:22:"update_variable_values";s:0:"";s:20:"bypass_create_record";s:0:"";}', 11, 98, 0),
(427, 'submitButton', 'a:6:{s:4:"name";s:7:"guardar";s:5:"value";s:4:"Save";s:2:"id";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";}', 0, 98, 0),
(428, 'button', 'a:12:{s:3:"url";s:7:"content";s:5:"value";s:5:"Close";s:9:"variables";a:3:{s:6:"is_tab";s:1:"1";s:6:"action";s:6:"record";s:2:"id";s:2:"id";}s:14:"target_elem_id";s:0:"";s:2:"id";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:23:"disable_if_no_record_id";s:1:"1";s:20:"disable_if_cant_edit";s:0:"";s:22:"update_variable_values";s:0:"";s:20:"bypass_create_record";s:0:"";}', 1, 98, 0),
(429, 'cancelButton', 'a:4:{s:5:"value";s:4:"Back";s:2:"id";s:0:"";s:5:"class";s:0:"";s:5:"style";s:0:"";}', 2, 98, 0),
(1002, 'endRestricted', '', 4, 22, 0),
(431, 'field', 'a:14:{s:4:"name";s:8:"title_en";s:7:"caption";s:12:"TÃ­tulo (EN)";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 2, 99, 0),
(432, 'field', 'a:14:{s:4:"name";s:3:"url";s:7:"caption";s:3:"URL";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 4, 99, 0),
(433, 'field', 'a:14:{s:4:"name";s:10:"content_en";s:7:"caption";s:14:"Contenido (EN)";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 5, 99, 0),
(434, 'cancelButton', 'a:4:{s:5:"value";s:4:"Back";s:2:"id";s:0:"";s:5:"class";s:0:"";s:5:"style";s:0:"";}', 1, 99, 0),
(435, 'button', 'a:10:{s:3:"url";s:7:"content";s:5:"value";s:4:"Edit";s:9:"variables";a:3:{s:6:"is_tab";s:1:"1";s:6:"action";s:4:"form";s:2:"id";s:2:"id";}s:14:"target_elem_id";s:7:"content";s:2:"id";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:23:"disable_if_no_record_id";s:1:"1";s:20:"disable_if_cant_edit";s:1:"1";}', 0, 99, 0),
(436, 'button', 'a:10:{s:3:"url";s:7:"content";s:5:"value";s:4:"Edit";s:9:"variables";a:3:{s:6:"is_tab";s:1:"1";s:6:"action";s:4:"form";s:2:"id";s:2:"id";}s:14:"target_elem_id";s:7:"content";s:2:"id";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:23:"disable_if_no_record_id";s:1:"1";s:20:"disable_if_cant_edit";s:1:"1";}', 7, 99, 0),
(437, 'cancelButton', 'a:4:{s:5:"value";s:4:"Back";s:2:"id";s:0:"";s:5:"class";s:0:"";s:5:"style";s:0:"";}', 8, 99, 0),
(1001, 'startRestricted', 'a:9:{s:6:"groups";s:0:"";s:10:"only_admin";s:1:"1";s:5:"users";s:0:"";s:20:"user_id_equals_field";s:0:"";s:21:"group_id_equals_field";s:0:"";s:9:"condition";s:0:"";s:14:"exclude_groups";s:0:"";s:13:"exclude_admin";s:0:"";s:13:"exclude_users";s:0:"";}', 2, 22, 0),
(443, 'field', 'a:18:{s:4:"name";s:2:"id";s:8:"subtable";s:0:"";s:14:"header_caption";s:2:"ID";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";s:0:"";s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 0, 100, 0),
(444, 'field', 'a:18:{s:4:"name";s:3:"url";s:8:"subtable";s:0:"";s:14:"header_caption";s:3:"URL";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";s:0:"";s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 1, 100, 0),
(715, 'field', 'a:14:{s:4:"name";s:10:"content_en";s:7:"caption";s:12:"Content (EN)";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 3, 23, 0),
(716, 'field', 'a:14:{s:4:"name";s:8:"title_en";s:7:"caption";s:10:"Title (EN)";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 0, 23, 0),
(721, 'cancelButton', 'a:4:{s:5:"value";s:4:"Back";s:2:"id";s:0:"";s:5:"class";s:0:"";s:5:"style";s:0:"";}', 5, 23, 0),
(719, 'addTable', 'a:8:{s:5:"table";s:6:"emails";s:12:"table_fields";a:1:{s:8:"title_en";s:8:"title_en";}s:3:"url";s:0:"";s:6:"parent";s:0:"";s:5:"class";s:0:"";s:14:"target_elem_id";s:7:"content";s:10:"url_is_tab";s:0:"";s:15:"accept_children";s:0:"";}', 0, 24, 0),
(720, 'cancelButton', 'a:4:{s:5:"value";s:4:"Back";s:2:"id";s:0:"";s:5:"class";s:0:"";s:5:"style";s:0:"";}', 8, 22, 0),
(712, 'textInput', 'a:13:{s:4:"name";s:3:"key";s:7:"caption";s:16:"Key (no cambiar)";s:8:"required";s:1:"1";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 3, 22, 0),
(713, 'textInput', 'a:13:{s:4:"name";s:8:"title_en";s:7:"caption";s:10:"Title (EN)";s:8:"required";s:1:"1";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 0, 22, 0),
(714, 'field', 'a:12:{s:4:"name";s:3:"key";s:7:"caption";s:3:"Key";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:19:"1969-12-31 19:00:00";}', 2, 23, 0),
(710, 'submitButton', 'a:6:{s:4:"name";s:6:"enviar";s:5:"value";s:4:"Save";s:2:"id";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";}', 7, 22, 0),
(711, 'textEditor', 'a:11:{s:4:"name";s:10:"content_en";s:7:"caption";s:12:"Content (EN)";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:7:"echo_on";s:0:"";s:5:"class";s:0:"";s:8:"is_basic";s:0:"";s:12:"allow_images";s:0:"";s:6:"height";s:0:"";s:9:"method_id";s:0:"";}', 5, 22, 0),
(603, 'passwordInput', 'a:9:{s:4:"name";s:4:"pass";s:7:"caption";s:8:"Password";s:8:"required";s:1:"1";s:5:"value";s:0:"";s:2:"id";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:12:"compare_with";s:0:"";}', 2, 130, 0),
(604, 'textInput', 'a:13:{s:4:"name";s:10:"first_name";s:7:"caption";s:10:"First Name";s:8:"required";s:1:"1";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 5, 130, 0),
(605, 'textInput', 'a:13:{s:4:"name";s:9:"last_name";s:7:"caption";s:9:"Last Name";s:8:"required";s:1:"1";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 6, 130, 0),
(606, 'textInput', 'a:13:{s:4:"name";s:5:"email";s:7:"caption";s:5:"Email";s:8:"required";s:1:"1";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 8, 130, 0),
(1249, 'selectInput', 'a:20:{s:4:"name";s:7:"country";s:7:"caption";s:7:"Country";s:8:"required";s:1:"1";s:5:"value";s:0:"";s:13:"options_array";s:0:"";s:8:"subtable";s:13:"iso_countries";s:15:"subtable_fields";a:1:{s:4:"name";s:4:"name";}s:13:"subtable_f_id";s:0:"";s:2:"id";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:10:"f_id_field";s:0:"";s:12:"default_text";s:0:"";s:10:"depends_on";s:0:"";s:20:"function_to_elements";s:0:"";s:16:"first_is_default";s:0:"";s:5:"level";s:0:"";s:11:"concat_char";s:0:"";s:9:"is_catsel";s:0:"";}', 7, 130, 0),
(1882, 'checkBox', 'a:9:{s:4:"name";s:18:"notify_deposit_btc";s:7:"caption";s:18:"Notify Deposit BTC";s:8:"required";s:0:"";s:2:"id";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:11:"label_class";s:0:"";s:7:"checked";s:0:"";}', 23, 130, 0),
(834, 'field', 'a:14:{s:4:"name";s:4:"user";s:7:"caption";s:8:"Username";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 1, 131, 0),
(836, 'field', 'a:14:{s:4:"name";s:10:"first_name";s:7:"caption";s:10:"First Name";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 3, 131, 0),
(837, 'field', 'a:14:{s:4:"name";s:9:"last_name";s:7:"caption";s:9:"Last Name";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 4, 131, 0),
(838, 'field', 'a:7:{s:4:"name";s:5:"email";s:7:"caption";s:5:"Email";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";}', 6, 131, 0),
(839, 'field', 'a:13:{s:4:"name";s:2:"id";s:8:"subtable";s:0:"";s:14:"header_caption";s:2:"ID";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";s:0:"";s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:8:"is_media";s:0:"";}', 0, 132, 0),
(840, 'field', 'a:18:{s:4:"name";s:4:"user";s:8:"subtable";s:0:"";s:14:"header_caption";s:4:"User";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";s:0:"";s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 1, 132, 0),
(841, 'field', 'a:18:{s:4:"name";s:10:"first_name";s:8:"subtable";s:0:"";s:14:"header_caption";s:10:"First Name";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";s:0:"";s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 3, 132, 0),
(842, 'field', 'a:18:{s:4:"name";s:9:"last_name";s:8:"subtable";s:0:"";s:14:"header_caption";s:9:"Last Name";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";s:0:"";s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 4, 132, 0),
(1426, 'field', 'a:18:{s:4:"name";s:7:"country";s:8:"subtable";s:13:"iso_countries";s:14:"header_caption";s:7:"Country";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";a:1:{s:4:"name";s:4:"name";}s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 5, 132, 0),
(849, 'textInput', 'a:13:{s:4:"name";s:3:"tel";s:7:"caption";s:9:"Cellphone";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 10, 130, 0),
(1598, 'textInput', 'a:13:{s:4:"name";s:3:"gbp";s:7:"caption";s:11:"GBP Balance";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 37, 130, 0),
(851, 'field', 'a:14:{s:4:"name";s:4:"date";s:7:"caption";s:9:"Reg. Date";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 2, 131, 0),
(854, 'field', 'a:14:{s:4:"name";s:3:"tel";s:7:"caption";s:9:"Cellphone";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 8, 131, 0),
(1599, 'textInput', 'a:13:{s:4:"name";s:3:"ars";s:7:"caption";s:11:"ARS Balance";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 39, 130, 0),
(858, 'field', 'a:18:{s:4:"name";s:4:"date";s:8:"subtable";s:0:"";s:14:"header_caption";s:9:"Reg. Date";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";s:0:"";s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 2, 132, 0),
(871, 'cancelButton', 'a:4:{s:5:"value";s:4:"BACK";s:2:"id";s:0:"";s:5:"class";s:0:"";s:5:"style";s:0:"";}', 44, 131, 0),
(1019, 'submitButton', 'a:6:{s:4:"name";s:6:"enviar";s:5:"value";s:4:"Save";s:2:"id";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";}', 66, 130, 0),
(1020, 'cancelButton', 'a:4:{s:5:"value";s:6:"Cancel";s:2:"id";s:0:"";s:5:"class";s:0:"";s:5:"style";s:0:"";}', 67, 130, 0),
(667, 'textInput', 'a:13:{s:4:"name";s:3:"esp";s:7:"caption";s:7:"Spanish";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 3, 139, 0),
(668, 'textInput', 'a:13:{s:4:"name";s:3:"eng";s:7:"caption";s:7:"English";s:8:"required";s:1:"1";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 2, 139, 0),
(669, 'textInput', 'a:13:{s:4:"name";s:3:"key";s:7:"caption";s:19:"Key (do not change)";s:8:"required";s:1:"1";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 1, 139, 0),
(670, 'submitButton', 'a:6:{s:4:"name";s:6:"enviar";s:5:"value";s:4:"Save";s:2:"id";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";}', 9, 139, 0),
(1913, 'field', 'a:14:{s:4:"name";s:7:"account";s:7:"caption";s:14:"Crypto Account";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 8, 232, 0),
(1539, 'textInput', 'a:13:{s:4:"name";s:3:"btc";s:7:"caption";s:11:"BTC Balance";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 33, 130, 0),
(1242, 'field', 'a:14:{s:4:"name";s:3:"esp";s:7:"caption";s:7:"Spanish";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 2, 178, 0),
(1241, 'field', 'a:14:{s:4:"name";s:3:"eng";s:7:"caption";s:7:"English";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 1, 178, 0),
(1240, 'field', 'a:14:{s:4:"name";s:3:"key";s:7:"caption";s:3:"Key";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 0, 178, 0),
(678, 'addTable', 'a:8:{s:5:"table";s:4:"lang";s:12:"table_fields";a:1:{s:3:"eng";s:3:"eng";}s:3:"url";s:0:"";s:6:"parent";s:0:"";s:5:"class";s:0:"";s:14:"target_elem_id";s:8:"edit_box";s:15:"accept_children";s:1:"Y";s:10:"url_is_tab";s:0:"";}', 11, 141, 0),
(1115, 'textInput', 'a:13:{s:4:"name";s:8:"title_es";s:7:"caption";s:10:"Title (ES)";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 6, 98, 0),
(1606, 'textInput', 'a:13:{s:4:"name";s:3:"dkk";s:7:"caption";s:11:"DKK Balance";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 44, 130, 0),
(1117, 'textEditor', 'a:11:{s:4:"name";s:10:"content_es";s:7:"caption";s:12:"Content (ES)";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:7:"echo_on";s:0:"";s:5:"class";s:0:"";s:8:"is_basic";s:0:"";s:12:"allow_images";s:1:"1";s:6:"height";s:0:"";s:9:"method_id";s:0:"";}', 9, 98, 0),
(1603, 'textInput', 'a:13:{s:4:"name";s:3:"hkd";s:7:"caption";s:11:"HKD Balance";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 45, 130, 0),
(1119, 'field', 'a:14:{s:4:"name";s:8:"title_es";s:7:"caption";s:12:"TÃ­tulo (ES)";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 3, 99, 0),
(1602, 'textInput', 'a:13:{s:4:"name";s:3:"mxn";s:7:"caption";s:11:"MXN Balance";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 52, 130, 0),
(1121, 'field', 'a:14:{s:4:"name";s:10:"content_es";s:7:"caption";s:14:"Contenido (ES)";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 6, 99, 0),
(1593, 'field', 'a:14:{s:4:"name";s:3:"btc";s:7:"caption";s:11:"BTC Balance";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 12, 131, 0),
(1199, 'textInput', 'a:13:{s:4:"name";s:10:"first_name";s:7:"caption";s:10:"First Name";s:8:"required";s:1:"1";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 0, 173, 0),
(1200, 'textInput', 'a:13:{s:4:"name";s:9:"last_name";s:7:"caption";s:9:"Last Name";s:8:"required";s:1:"1";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 1, 173, 0),
(1201, 'textInput', 'a:13:{s:4:"name";s:5:"email";s:7:"caption";s:5:"Email";s:8:"required";s:5:"email";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 2, 173, 0),
(1202, 'textArea', 'a:9:{s:4:"name";s:3:"bio";s:7:"caption";s:9:"Bio (ENG)";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";}', 3, 173, 0),
(1203, 'textArea', 'a:9:{s:4:"name";s:7:"bio_esp";s:7:"caption";s:9:"Bio (ESP)";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";}', 4, 173, 0),
(1204, 'textArea', 'a:9:{s:4:"name";s:7:"bio_heb";s:7:"caption";s:9:"Bio (HEB)";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";}', 5, 173, 0),
(1205, 'checkBox', 'a:9:{s:4:"name";s:10:"show_email";s:7:"caption";s:10:"Show Email";s:8:"required";s:0:"";s:2:"id";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:11:"label_class";s:0:"";s:7:"checked";s:0:"";}', 6, 173, 0),
(1206, 'submitButton', 'a:6:{s:4:"name";s:4:"save";s:5:"value";s:4:"Save";s:2:"id";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";}', 7, 173, 0),
(1207, 'cancelButton', 'a:4:{s:5:"value";s:6:"Cancel";s:2:"id";s:0:"";s:5:"class";s:0:"";s:5:"style";s:0:"";}', 8, 173, 0),
(1208, 'field', 'a:14:{s:4:"name";s:10:"first_name";s:7:"caption";s:10:"First Name";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 0, 174, 0),
(1209, 'field', 'a:14:{s:4:"name";s:9:"last_name";s:7:"caption";s:9:"Last Name";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 1, 174, 0),
(1210, 'field', 'a:14:{s:4:"name";s:5:"email";s:7:"caption";s:5:"Email";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 2, 174, 0),
(1211, 'field', 'a:14:{s:4:"name";s:3:"bio";s:7:"caption";s:9:"Bio (ENG)";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 3, 174, 0),
(1212, 'field', 'a:14:{s:4:"name";s:3:"bio";s:7:"caption";s:9:"Bio (HEB)";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 4, 174, 0),
(1213, 'field', 'a:14:{s:4:"name";s:7:"bio_esp";s:7:"caption";s:9:"Bio (ESP)";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 5, 174, 0),
(1214, 'field', 'a:14:{s:4:"name";s:10:"show_email";s:7:"caption";s:10:"Show Email";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 6, 174, 0),
(1215, 'cancelButton', 'a:4:{s:5:"value";s:2:"OK";s:2:"id";s:0:"";s:5:"class";s:0:"";s:5:"style";s:0:"";}', 7, 174, 0),
(1216, 'field', 'a:18:{s:4:"name";s:2:"id";s:8:"subtable";s:0:"";s:14:"header_caption";s:2:"ID";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";s:0:"";s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 0, 175, 0),
(1217, 'field', 'a:18:{s:4:"name";s:10:"first_name";s:8:"subtable";s:0:"";s:14:"header_caption";s:10:"First Name";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";s:0:"";s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 1, 175, 0),
(1218, 'field', 'a:18:{s:4:"name";s:9:"last_name";s:8:"subtable";s:0:"";s:14:"header_caption";s:9:"Last Name";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";s:0:"";s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 1, 175, 0),
(1219, 'field', 'a:18:{s:4:"name";s:5:"email";s:8:"subtable";s:0:"";s:14:"header_caption";s:5:"Email";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";s:0:"";s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 1, 175, 0),
(1220, 'field', 'a:18:{s:4:"name";s:10:"show_email";s:8:"subtable";s:0:"";s:14:"header_caption";s:10:"Show Email";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";s:0:"";s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 1, 175, 0),
(1237, 'passiveField', 'a:14:{s:4:"name";s:4:"date";s:7:"caption";s:9:"Reg. Date";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:15:"create_db_field";s:8:"datetime";s:13:"default_value";s:0:"";s:23:"dont_fill_automatically";s:0:"";}', 3, 130, 0),
(1239, 'cancelButton', 'a:4:{s:5:"value";s:6:"Cancel";s:2:"id";s:0:"";s:5:"class";s:0:"";s:5:"style";s:0:"";}', 10, 139, 0),
(1244, 'cancelButton', 'a:4:{s:5:"value";s:2:"OK";s:2:"id";s:0:"";s:5:"class";s:0:"";s:5:"style";s:0:"";}', 7, 178, 0),
(1245, 'textEditor', 'a:11:{s:4:"name";s:10:"content_es";s:7:"caption";s:12:"Content (ES)";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:7:"echo_on";s:0:"";s:5:"class";s:0:"";s:8:"is_basic";s:0:"";s:12:"allow_images";s:0:"";s:6:"height";s:0:"";s:9:"method_id";s:0:"";}', 6, 22, 0),
(1247, 'field', 'a:14:{s:4:"name";s:10:"content_es";s:7:"caption";s:12:"Content (ES)";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 4, 23, 0),
(1917, 'cancelButton', 'a:4:{s:5:"value";s:6:"Cancel";s:2:"id";s:0:"";s:5:"class";s:0:"";s:5:"style";s:0:"";}', 44, 244, 0),
(1918, 'addTable', 'a:8:{s:5:"table";s:6:"status";s:12:"table_fields";a:1:{s:11:"deficit_btc";s:11:"deficit_btc";}s:3:"url";s:0:"";s:6:"parent";s:0:"";s:5:"class";s:0:"";s:14:"target_elem_id";s:7:"content";s:10:"url_is_tab";s:0:"";s:15:"accept_children";s:0:"";}', 0, 245, 0),
(1250, 'field', 'a:14:{s:4:"name";s:7:"country";s:7:"caption";s:7:"Country";s:8:"subtable";s:13:"iso_countries";s:15:"subtable_fields";a:1:{s:4:"name";s:4:"name";}s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 5, 131, 0),
(1264, 'hiddenInput', 'a:7:{s:4:"name";s:5:"order";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:3:"int";s:7:"jscript";s:0:"";s:20:"is_current_timestamp";s:0:"";}', 0, 139, 0),
(1266, 'selectInput', 'a:20:{s:4:"name";s:4:"p_id";s:7:"caption";s:6:"Parent";s:8:"required";s:0:"";s:5:"value";s:0:"";s:13:"options_array";s:0:"";s:8:"subtable";s:4:"lang";s:15:"subtable_fields";a:1:{s:3:"eng";s:3:"eng";}s:13:"subtable_f_id";s:1:"0";s:2:"id";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:10:"f_id_field";s:4:"p_id";s:12:"default_text";s:0:"";s:10:"depends_on";s:0:"";s:20:"function_to_elements";s:0:"";s:16:"first_is_default";s:0:"";s:5:"level";s:0:"";s:11:"concat_char";s:0:"";s:9:"is_catsel";s:0:"";}', 8, 139, 0),
(1912, 'field', 'a:18:{s:4:"name";s:7:"account";s:8:"subtable";s:0:"";s:14:"header_caption";s:7:"Account";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";s:0:"";s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 11, 233, 0),
(1911, 'textInput', 'a:13:{s:4:"name";s:7:"account";s:7:"caption";s:14:"Crypto Account";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:3:"int";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 8, 225, 0),
(1939, 'textInput', 'a:13:{s:4:"name";s:12:"send_address";s:7:"caption";s:15:"Bitcoin Address";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 9, 225, 0),
(1933, 'checkBox', 'a:9:{s:4:"name";s:10:"hot_wallet";s:7:"caption";s:11:"Hot Wallet?";s:8:"required";s:0:"";s:2:"id";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:11:"label_class";s:0:"";s:7:"checked";s:0:"";}', 4, 242, 0),
(1908, 'hiddenInput', 'a:8:{s:4:"name";s:10:"address_id";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:3:"int";s:7:"jscript";s:0:"";s:20:"is_current_timestamp";s:0:"";s:15:"on_every_update";s:0:"";}', 13, 225, 0),
(1907, 'field', 'a:18:{s:4:"name";s:14:"system_address";s:8:"subtable";s:0:"";s:14:"header_caption";s:6:"System";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";s:0:"";s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 3, 243, 0),
(1607, 'textInput', 'a:13:{s:4:"name";s:3:"huf";s:7:"caption";s:11:"HUF Balance";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 47, 130, 0),
(1608, 'textInput', 'a:13:{s:4:"name";s:3:"lvl";s:7:"caption";s:11:"LVL Balance";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 51, 130, 0),
(1609, 'textInput', 'a:13:{s:4:"name";s:3:"ltl";s:7:"caption";s:11:"LTL Balance";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 50, 130, 0),
(1604, 'textInput', 'a:13:{s:4:"name";s:3:"ils";s:7:"caption";s:11:"ILS Balance";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 48, 130, 0),
(1605, 'textInput', 'a:13:{s:4:"name";s:3:"inr";s:7:"caption";s:11:"INR Balance";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 49, 130, 0),
(1601, 'textInput', 'a:13:{s:4:"name";s:3:"rub";s:7:"caption";s:11:"RUB Balance";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 58, 130, 0),
(1600, 'textInput', 'a:13:{s:4:"name";s:3:"jpy";s:7:"caption";s:11:"JPY Balance";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 38, 130, 0),
(1857, 'field', 'a:14:{s:4:"name";s:12:"fee_schedule";s:7:"caption";s:12:"Fee Schedule";s:8:"subtable";s:12:"fee_schedule";s:15:"subtable_fields";a:1:{s:3:"fee";s:3:"fee";}s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 9, 131, 0),
(1597, 'textInput', 'a:13:{s:4:"name";s:3:"cny";s:7:"caption";s:11:"CNY Balance";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 36, 130, 0),
(1594, 'field', 'a:14:{s:4:"name";s:3:"usd";s:7:"caption";s:11:"USD Balance";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 13, 131, 0),
(1595, 'field', 'a:14:{s:4:"name";s:3:"eur";s:7:"caption";s:11:"EUR Balance";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 14, 131, 0),
(1596, 'field', 'a:14:{s:4:"name";s:3:"gbp";s:7:"caption";s:11:"GBP Balance";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 15, 131, 0),
(1858, 'selectInput', 'a:20:{s:4:"name";s:12:"request_type";s:7:"caption";s:12:"Request Type";s:8:"required";s:1:"1";s:5:"value";s:0:"";s:13:"options_array";s:0:"";s:8:"subtable";s:13:"request_types";s:15:"subtable_fields";a:1:{s:7:"name_en";s:7:"name_en";}s:13:"subtable_f_id";s:0:"";s:2:"id";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:10:"f_id_field";s:0:"";s:12:"default_text";s:0:"";s:10:"depends_on";s:0:"";s:20:"function_to_elements";s:0:"";s:16:"first_is_default";s:0:"";s:5:"level";s:0:"";s:11:"concat_char";s:0:"";s:9:"is_catsel";s:0:"";}', 2, 225, 0),
(1859, 'field', 'a:14:{s:4:"name";s:12:"request_type";s:7:"caption";s:12:"Request Type";s:8:"subtable";s:13:"request_types";s:15:"subtable_fields";a:1:{s:7:"name_en";s:7:"name_en";}s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 2, 232, 0),
(1860, 'field', 'a:18:{s:4:"name";s:12:"request_type";s:8:"subtable";s:13:"request_types";s:14:"header_caption";s:4:"Type";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";a:1:{s:7:"name_en";s:7:"name_en";}s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 6, 233, 0),
(1861, 'checkBox', 'a:9:{s:4:"name";s:12:"market_price";s:7:"caption";s:21:"Price at market rate?";s:8:"required";s:0:"";s:2:"id";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:11:"label_class";s:0:"";s:7:"checked";s:0:"";}', 5, 210, 0),
(1862, 'field', 'a:14:{s:4:"name";s:12:"market_price";s:7:"caption";s:21:"Price at market rate?";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 6, 214, 0),
(1863, 'field', 'a:18:{s:4:"name";s:12:"market_price";s:8:"subtable";s:0:"";s:14:"header_caption";s:13:"Market price?";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";s:0:"";s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 8, 215, 0),
(1866, 'textInput', 'a:13:{s:4:"name";s:6:"number";s:7:"caption";s:6:"Number";s:8:"required";s:1:"1";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 0, 239, 0),
(1867, 'textInput', 'a:13:{s:4:"name";s:2:"cc";s:7:"caption";s:12:"Country Code";s:8:"required";s:1:"1";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 0, 239, 0),
(1884, 'textInput', 'a:13:{s:4:"name";s:14:"account_number";s:7:"caption";s:14:"Account Number";s:8:"required";s:1:"1";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:3:"int";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 1, 240, 0),
(1870, 'textInput', 'a:13:{s:4:"name";s:12:"country_code";s:7:"caption";s:12:"Country Code";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:3:"int";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 11, 130, 0),
(1871, 'checkBox', 'a:9:{s:4:"name";s:14:"verified_authy";s:7:"caption";s:18:"Verified by Authy?";s:8:"required";s:0:"";s:2:"id";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:11:"label_class";s:0:"";s:7:"checked";s:0:"";}', 14, 130, 0),
(1872, 'checkBox', 'a:9:{s:4:"name";s:15:"authy_requested";s:7:"caption";s:16:"Authy Requested?";s:8:"required";s:0:"";s:2:"id";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:11:"label_class";s:0:"";s:7:"checked";s:0:"";}', 13, 130, 0),
(1876, 'hiddenInput', 'a:8:{s:4:"name";s:8:"authy_id";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:3:"int";s:7:"jscript";s:0:"";s:20:"is_current_timestamp";s:0:"";s:15:"on_every_update";s:0:"";}', 30, 130, 0),
(1877, 'dateWidget', 'a:19:{s:4:"name";s:13:"dont_ask_date";s:7:"caption";s:13:"Dont ask date";s:8:"required";s:0:"";s:4:"time";s:1:"1";s:4:"ampm";s:1:"1";s:9:"req_start";s:0:"";s:7:"req_end";s:0:"";s:5:"value";s:0:"";s:7:"link_to";s:0:"";s:2:"id";s:0:"";s:5:"class";s:0:"";s:6:"format";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:19:"is_filter_range_end";s:0:"";s:14:"document_ready";s:0:"";s:9:"only_time";s:0:"";s:16:"regular_interval";s:0:"";s:13:"only_interval";s:0:"";}', 18, 130, 0),
(1874, 'checkBox', 'a:9:{s:4:"name";s:9:"using_sms";s:7:"caption";s:10:"Using SMS?";s:8:"required";s:0:"";s:2:"id";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:11:"label_class";s:0:"";s:7:"checked";s:0:"";}', 16, 130, 0),
(1875, 'checkBox', 'a:9:{s:4:"name";s:16:"dont_ask_30_days";s:7:"caption";s:28:"Don''t ask token for 30 days?";s:8:"required";s:0:"";s:2:"id";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:11:"label_class";s:0:"";s:7:"checked";s:0:"";}', 17, 130, 0),
(1883, 'checkBox', 'a:9:{s:4:"name";s:19:"notify_deposit_bank";s:7:"caption";s:19:"Notify Deposit Bank";s:8:"required";s:0:"";s:2:"id";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:11:"label_class";s:0:"";s:7:"checked";s:0:"";}', 24, 130, 0),
(1382, 'textInput', 'a:13:{s:4:"name";s:4:"user";s:7:"caption";s:8:"Username";s:8:"required";s:1:"1";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:1:"1";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 1, 130, 0),
(1878, 'checkBox', 'a:9:{s:4:"name";s:26:"confirm_withdrawal_2fa_btc";s:7:"caption";s:19:"Conf. BTC Withd 2FA";s:8:"required";s:0:"";s:2:"id";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:11:"label_class";s:0:"";s:7:"checked";s:0:"";}', 19, 130, 0),
(1879, 'checkBox', 'a:9:{s:4:"name";s:28:"confirm_withdrawal_email_btc";s:7:"caption";s:22:"Conf. BTC Withd. Email";s:8:"required";s:0:"";s:2:"id";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:11:"label_class";s:0:"";s:7:"checked";s:0:"";}', 20, 130, 0),
(1880, 'checkBox', 'a:9:{s:4:"name";s:27:"confirm_withdrawal_2fa_bank";s:7:"caption";s:21:"Conf. Bank Withd. 2FA";s:8:"required";s:0:"";s:2:"id";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:11:"label_class";s:0:"";s:7:"checked";s:0:"";}', 21, 130, 0),
(1881, 'checkBox', 'a:9:{s:4:"name";s:29:"confirm_withdrawal_email_bank";s:7:"caption";s:23:"Conf. Bank Withd. Email";s:8:"required";s:0:"";s:2:"id";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:11:"label_class";s:0:"";s:7:"checked";s:0:"";}', 22, 130, 0),
(1852, 'submitButton', 'a:6:{s:4:"name";s:4:"Save";s:5:"value";s:4:"Save";s:2:"id";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";}', 6, 237, 0),
(1853, 'cancelButton', 'a:4:{s:5:"value";s:6:"Cancel";s:2:"id";s:0:"";s:5:"class";s:0:"";s:5:"style";s:0:"";}', 7, 237, 0),
(1854, 'hiddenInput', 'a:8:{s:4:"name";s:5:"order";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:3:"int";s:7:"jscript";s:0:"";s:20:"is_current_timestamp";s:0:"";s:15:"on_every_update";s:0:"";}', 5, 237, 0),
(1855, 'addTable', 'a:8:{s:5:"table";s:12:"fee_schedule";s:12:"table_fields";a:4:{s:3:"fee";s:3:"fee";s:4:"fee1";s:4:"fee1";s:8:"from_usd";s:8:"from_usd";s:6:"to_usd";s:6:"to_usd";}s:3:"url";s:0:"";s:6:"parent";s:0:"";s:5:"class";s:0:"";s:14:"target_elem_id";s:8:"edit_box";s:10:"url_is_tab";s:0:"";s:15:"accept_children";s:0:"";}', 0, 238, 0);
INSERT INTO `admin_controls_methods` (`id`, `method`, `arguments`, `order`, `control_id`, `p_id`) VALUES
(1890, 'field', 'a:18:{s:4:"name";s:9:"site_user";s:8:"subtable";s:10:"site_users";s:14:"header_caption";s:4:"User";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";a:1:{s:4:"user";s:4:"user";}s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 1, 241, 0),
(1891, 'field', 'a:18:{s:4:"name";s:14:"account_number";s:8:"subtable";s:0:"";s:14:"header_caption";s:6:"Number";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";s:0:"";s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 2, 241, 0),
(1892, 'field', 'a:18:{s:4:"name";s:11:"description";s:8:"subtable";s:0:"";s:14:"header_caption";s:11:"Description";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";s:0:"";s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 3, 241, 0),
(1893, 'textInput', 'a:13:{s:4:"name";s:7:"address";s:7:"caption";s:7:"Address";s:8:"required";s:1:"1";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 0, 242, 0),
(1894, 'autoComplete', 'a:22:{s:4:"name";s:9:"site_user";s:7:"caption";s:4:"User";s:8:"required";s:0:"";s:5:"value";s:0:"";s:8:"multiple";s:0:"";s:13:"options_array";s:0:"";s:8:"subtable";s:10:"site_users";s:15:"subtable_fields";a:1:{s:4:"user";s:4:"user";}s:13:"subtable_f_id";s:0:"";s:2:"id";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:10:"depends_on";s:0:"";s:10:"depend_url";s:0:"";s:10:"f_id_field";s:0:"";s:17:"list_field_values";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";s:12:"is_tokenizer";s:0:"";s:16:"get_table_fields";s:0:"";s:16:"first_is_default";s:0:"";}', 1, 242, 0),
(1895, 'dateWidget', 'a:19:{s:4:"name";s:4:"date";s:7:"caption";s:11:"Last Update";s:8:"required";s:1:"1";s:4:"time";s:1:"1";s:4:"ampm";s:1:"1";s:9:"req_start";s:0:"";s:7:"req_end";s:0:"";s:5:"value";s:0:"";s:7:"link_to";s:0:"";s:2:"id";s:0:"";s:5:"class";s:0:"";s:6:"format";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:19:"is_filter_range_end";s:0:"";s:14:"document_ready";s:0:"";s:9:"only_time";s:0:"";s:16:"regular_interval";s:0:"";s:13:"only_interval";s:0:"";}', 2, 242, 0),
(1896, 'submitButton', 'a:6:{s:4:"name";s:4:"Save";s:5:"value";s:4:"Save";s:2:"id";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";}', 6, 242, 0),
(1897, 'cancelButton', 'a:4:{s:5:"value";s:6:"Cancel";s:2:"id";s:0:"";s:5:"class";s:0:"";s:5:"style";s:0:"";}', 7, 242, 0),
(1898, 'field', 'a:18:{s:4:"name";s:2:"id";s:8:"subtable";s:0:"";s:14:"header_caption";s:2:"ID";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";s:0:"";s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 0, 243, 0),
(1899, 'field', 'a:18:{s:4:"name";s:7:"address";s:8:"subtable";s:0:"";s:14:"header_caption";s:7:"Address";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";s:0:"";s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 1, 243, 0),
(1936, 'field', 'a:18:{s:4:"name";s:11:"warm_wallet";s:8:"subtable";s:0:"";s:14:"header_caption";s:11:"Warm Wallet";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";s:0:"";s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 5, 243, 0),
(1856, 'selectInput', 'a:20:{s:4:"name";s:12:"fee_schedule";s:7:"caption";s:12:"Fee Schedule";s:8:"required";s:1:"1";s:5:"value";s:0:"";s:13:"options_array";s:0:"";s:8:"subtable";s:12:"fee_schedule";s:15:"subtable_fields";a:1:{s:3:"fee";s:3:"fee";}s:13:"subtable_f_id";s:0:"";s:2:"id";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:10:"f_id_field";s:0:"";s:12:"default_text";s:0:"";s:10:"depends_on";s:0:"";s:20:"function_to_elements";s:0:"";s:16:"first_is_default";s:0:"";s:5:"level";s:0:"";s:11:"concat_char";s:0:"";s:9:"is_catsel";s:0:"";}', 4, 130, 0),
(1592, 'textInput', 'a:13:{s:4:"name";s:3:"eur";s:7:"caption";s:11:"EUR Balance";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 35, 130, 0),
(1591, 'textInput', 'a:13:{s:4:"name";s:3:"usd";s:7:"caption";s:11:"USD Balance";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 34, 130, 0),
(1849, 'textInput', 'a:13:{s:4:"name";s:3:"fee";s:7:"caption";s:13:"Fee % (Taker)";s:8:"required";s:1:"1";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 0, 237, 0),
(1850, 'textInput', 'a:13:{s:4:"name";s:8:"from_usd";s:7:"caption";s:15:"From USD (mon.)";s:8:"required";s:1:"1";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 2, 237, 0),
(1851, 'textInput', 'a:13:{s:4:"name";s:6:"to_usd";s:7:"caption";s:13:"To USD (mon.)";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 3, 237, 0),
(1901, 'field', 'a:18:{s:4:"name";s:9:"site_user";s:8:"subtable";s:10:"site_users";s:14:"header_caption";s:4:"User";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";a:1:{s:4:"user";s:4:"user";}s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 2, 243, 0),
(1902, 'selectInput', 'a:20:{s:4:"name";s:8:"currency";s:7:"caption";s:8:"Currency";s:8:"required";s:1:"1";s:5:"value";s:0:"";s:13:"options_array";s:0:"";s:8:"subtable";s:10:"currencies";s:15:"subtable_fields";a:1:{s:8:"currency";s:8:"currency";}s:13:"subtable_f_id";s:0:"";s:2:"id";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:10:"f_id_field";s:0:"";s:12:"default_text";s:0:"";s:10:"depends_on";s:0:"";s:20:"function_to_elements";s:0:"";s:16:"first_is_default";s:0:"";s:5:"level";s:0:"";s:11:"concat_char";s:0:"";s:9:"is_catsel";s:0:"";}', 3, 240, 0),
(1903, 'field', 'a:18:{s:4:"name";s:8:"currency";s:8:"subtable";s:10:"currencies";s:14:"header_caption";s:8:"Currency";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";a:1:{s:8:"currency";s:8:"currency";}s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 4, 241, 0),
(1934, 'checkBox', 'a:9:{s:4:"name";s:11:"warm_wallet";s:7:"caption";s:12:"Warm Wallet?";s:8:"required";s:0:"";s:2:"id";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:11:"label_class";s:0:"";s:7:"checked";s:0:"";}', 5, 242, 0),
(1935, 'field', 'a:18:{s:4:"name";s:10:"hot_wallet";s:8:"subtable";s:0:"";s:14:"header_caption";s:10:"Hot Wallet";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";s:0:"";s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 4, 243, 0),
(1905, 'checkBox', 'a:9:{s:4:"name";s:14:"system_address";s:7:"caption";s:15:"System Address?";s:8:"required";s:0:"";s:2:"id";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:11:"label_class";s:0:"";s:7:"checked";s:0:"";}', 3, 242, 0),
(1937, 'textInput', 'a:13:{s:4:"name";s:19:"pending_withdrawals";s:7:"caption";s:22:"Pending Withdrawal BTC";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 7, 244, 0),
(1469, 'textInput', 'a:13:{s:4:"name";s:8:"title_es";s:7:"caption";s:10:"Title (ES)";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 1, 22, 0),
(1914, 'dateWidget', 'a:19:{s:4:"name";s:10:"last_sweep";s:7:"caption";s:10:"Last Sweep";s:8:"required";s:0:"";s:4:"time";s:1:"1";s:4:"ampm";s:1:"1";s:9:"req_start";s:0:"";s:7:"req_end";s:0:"";s:5:"value";s:0:"";s:7:"link_to";s:0:"";s:2:"id";s:0:"";s:5:"class";s:0:"";s:6:"format";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:19:"is_filter_range_end";s:0:"";s:14:"document_ready";s:0:"";s:9:"only_time";s:0:"";s:16:"regular_interval";s:0:"";s:13:"only_interval";s:0:"";}', 1, 244, 0),
(1915, 'textInput', 'a:13:{s:4:"name";s:11:"deficit_btc";s:7:"caption";s:13:"Deficit (BTC)";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 5, 244, 0),
(1916, 'submitButton', 'a:6:{s:4:"name";s:4:"Save";s:5:"value";s:4:"Save";s:2:"id";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";}', 43, 244, 0),
(1474, 'field', 'a:14:{s:4:"name";s:8:"title_es";s:7:"caption";s:10:"Title (ES)";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 1, 23, 0),
(1919, 'dateWidget', 'a:19:{s:4:"name";s:11:"last_update";s:7:"caption";s:19:"Last Balance Update";s:8:"required";s:0:"";s:4:"time";s:1:"1";s:4:"ampm";s:1:"1";s:9:"req_start";s:0:"";s:7:"req_end";s:0:"";s:5:"value";s:0:"";s:7:"link_to";s:0:"";s:2:"id";s:0:"";s:5:"class";s:0:"";s:6:"format";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:19:"is_filter_range_end";s:0:"";s:14:"document_ready";s:0:"";s:9:"only_time";s:0:"";s:16:"regular_interval";s:0:"";s:13:"only_interval";s:0:"";}', 26, 130, 0),
(1920, 'hiddenInput', 'a:8:{s:4:"name";s:9:"increment";s:8:"required";s:1:"1";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:7:"jscript";s:0:"";s:20:"is_current_timestamp";s:0:"";s:15:"on_every_update";s:0:"";}', 14, 225, 0),
(1921, 'textInput', 'a:13:{s:4:"name";s:3:"fee";s:7:"caption";s:3:"Fee";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 0, 246, 0),
(1922, 'submitButton', 'a:6:{s:4:"name";s:4:"Save";s:5:"value";s:4:"Save";s:2:"id";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";}', 2, 246, 0),
(1923, 'cancelButton', 'a:4:{s:5:"value";s:6:"Cancel";s:2:"id";s:0:"";s:5:"class";s:0:"";s:5:"style";s:0:"";}', 3, 246, 0),
(1924, 'field', 'a:18:{s:4:"name";s:2:"id";s:8:"subtable";s:0:"";s:14:"header_caption";s:2:"ID";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";s:0:"";s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 0, 247, 0),
(1610, 'textInput', 'a:13:{s:4:"name";s:3:"nzd";s:7:"caption";s:11:"NZD Balance";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 55, 130, 0),
(1611, 'textInput', 'a:13:{s:4:"name";s:3:"nok";s:7:"caption";s:11:"NOK Balance";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 54, 130, 0),
(1612, 'textInput', 'a:13:{s:4:"name";s:3:"pln";s:7:"caption";s:11:"PLN Balance";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 56, 130, 0),
(1613, 'textInput', 'a:13:{s:4:"name";s:3:"ron";s:7:"caption";s:11:"RON Balance";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 57, 130, 0),
(1614, 'textInput', 'a:13:{s:4:"name";s:3:"sgd";s:7:"caption";s:11:"SGD Balance";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 60, 130, 0),
(1615, 'textInput', 'a:13:{s:4:"name";s:3:"zar";s:7:"caption";s:11:"ZAR Balance";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 64, 130, 0),
(1686, 'field', 'a:14:{s:4:"name";s:3:"zar";s:7:"caption";s:11:"ZAR Balance";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 42, 131, 0),
(1685, 'field', 'a:14:{s:4:"name";s:3:"try";s:7:"caption";s:11:"TRY Balance";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 40, 131, 0),
(1684, 'field', 'a:14:{s:4:"name";s:3:"thb";s:7:"caption";s:11:"THB Balance";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 39, 131, 0),
(1683, 'field', 'a:14:{s:4:"name";s:3:"sgd";s:7:"caption";s:11:"SGD Balance";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 38, 131, 0),
(1681, 'field', 'a:14:{s:4:"name";s:3:"rub";s:7:"caption";s:11:"RUB Balance";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 36, 131, 0),
(1682, 'field', 'a:14:{s:4:"name";s:3:"sek";s:7:"caption";s:11:"SEK Balance";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 37, 131, 0),
(1680, 'field', 'a:14:{s:4:"name";s:3:"ron";s:7:"caption";s:11:"RON Balance";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 35, 131, 0),
(1679, 'field', 'a:14:{s:4:"name";s:3:"pln";s:7:"caption";s:11:"PLN Balance";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 34, 131, 0),
(1678, 'field', 'a:14:{s:4:"name";s:3:"nzd";s:7:"caption";s:11:"NZD Balance";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 33, 131, 0),
(1677, 'field', 'a:14:{s:4:"name";s:3:"nok";s:7:"caption";s:11:"NOK Balance";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 32, 131, 0),
(1676, 'field', 'a:14:{s:4:"name";s:3:"mxn";s:7:"caption";s:11:"MXN Balance";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 30, 131, 0),
(1675, 'field', 'a:14:{s:4:"name";s:3:"lvl";s:7:"caption";s:11:"LVL Balance";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 29, 131, 0),
(1674, 'field', 'a:14:{s:4:"name";s:3:"ltl";s:7:"caption";s:11:"LTL Balance";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 28, 131, 0),
(1673, 'field', 'a:14:{s:4:"name";s:3:"inr";s:7:"caption";s:11:"INR Balance";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 27, 131, 0),
(1672, 'field', 'a:14:{s:4:"name";s:3:"ils";s:7:"caption";s:11:"ILS Balance";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 26, 131, 0),
(1671, 'field', 'a:14:{s:4:"name";s:3:"huf";s:7:"caption";s:11:"HUF Balance";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 25, 131, 0),
(1670, 'field', 'a:14:{s:4:"name";s:3:"hrk";s:7:"caption";s:11:"HRK Balance";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 24, 131, 0),
(1669, 'field', 'a:14:{s:4:"name";s:3:"hkd";s:7:"caption";s:11:"HKD Balance";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 23, 131, 0),
(1668, 'field', 'a:14:{s:4:"name";s:3:"dkk";s:7:"caption";s:11:"DKK Balance";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 22, 131, 0),
(1667, 'field', 'a:14:{s:4:"name";s:3:"czk";s:7:"caption";s:11:"CZK Balance";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 21, 131, 0),
(1666, 'field', 'a:14:{s:4:"name";s:3:"bgn";s:7:"caption";s:11:"BGN Balance";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 20, 131, 0),
(1665, 'field', 'a:14:{s:4:"name";s:3:"ars";s:7:"caption";s:11:"ARS Balance";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 17, 131, 0),
(1662, 'startArea', 'a:3:{s:6:"legend";s:9:"User Info";s:5:"class";s:8:"box_left";s:6:"height";s:0:"";}', 0, 131, 0),
(1688, 'endArea', '', 10, 131, 0),
(1664, 'field', 'a:14:{s:4:"name";s:3:"jpy";s:7:"caption";s:11:"JPY Balance";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 16, 131, 0),
(1658, 'startArea', 'a:3:{s:6:"legend";s:9:"User Info";s:5:"class";s:8:"box_left";s:6:"height";s:0:"";}', 0, 130, 0),
(1659, 'endArea', '', 31, 130, 0),
(1660, 'startArea', 'a:3:{s:6:"legend";s:8:"Balances";s:5:"class";s:9:"box_right";s:6:"height";s:0:"";}', 32, 130, 0),
(1661, 'endArea', '', 65, 130, 0),
(1656, 'textInput', 'a:13:{s:4:"name";s:3:"hrk";s:7:"caption";s:11:"HRK Balance";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 46, 130, 0),
(1655, 'textInput', 'a:13:{s:4:"name";s:3:"bgn";s:7:"caption";s:11:"BGN Balance";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 42, 130, 0),
(1654, 'textInput', 'a:13:{s:4:"name";s:3:"czk";s:7:"caption";s:11:"CZK Balance";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 43, 130, 0),
(1653, 'textInput', 'a:13:{s:4:"name";s:3:"try";s:7:"caption";s:11:"TRY Balance";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 62, 130, 0),
(1652, 'textInput', 'a:13:{s:4:"name";s:3:"thb";s:7:"caption";s:11:"THB Balance";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 61, 130, 0),
(1651, 'textInput', 'a:13:{s:4:"name";s:3:"sek";s:7:"caption";s:11:"SEK Balance";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 59, 130, 0),
(1687, 'startArea', 'a:3:{s:6:"legend";s:8:"Balances";s:5:"class";s:9:"box_right";s:6:"height";s:0:"";}', 11, 131, 0),
(1689, 'endArea', '', 43, 131, 0),
(1788, 'autoComplete', 'a:22:{s:4:"name";s:9:"site_user";s:7:"caption";s:4:"User";s:8:"required";s:1:"1";s:5:"value";s:0:"";s:8:"multiple";s:0:"";s:13:"options_array";s:0:"";s:8:"subtable";s:10:"site_users";s:15:"subtable_fields";a:1:{s:4:"user";s:4:"user";}s:13:"subtable_f_id";s:0:"";s:2:"id";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:10:"depends_on";s:0:"";s:10:"depend_url";s:0:"";s:10:"f_id_field";s:0:"";s:17:"list_field_values";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";s:12:"is_tokenizer";s:0:"";s:16:"get_table_fields";s:0:"";s:16:"first_is_default";s:0:"";}', 3, 225, 0),
(1691, 'submitButton', 'a:6:{s:4:"name";s:4:"Save";s:5:"value";s:4:"Save";s:2:"id";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";}', 3, 211, 0),
(1692, 'cancelButton', 'a:4:{s:5:"value";s:6:"Cancel";s:2:"id";s:0:"";s:5:"class";s:0:"";s:5:"style";s:0:"";}', 4, 211, 0),
(1694, 'cancelButton', 'a:4:{s:5:"value";s:2:"OK";s:2:"id";s:0:"";s:5:"class";s:0:"";s:5:"style";s:0:"";}', 3, 212, 0),
(1695, 'addTable', 'a:8:{s:5:"table";s:11:"order_types";s:12:"table_fields";a:1:{s:7:"name_en";s:7:"name_en";}s:3:"url";s:0:"";s:6:"parent";s:0:"";s:5:"class";s:0:"";s:14:"target_elem_id";s:8:"edit_box";s:10:"url_is_tab";s:0:"";s:15:"accept_children";s:0:"";}', 0, 213, 0),
(1696, 'dateWidget', 'a:19:{s:4:"name";s:4:"date";s:7:"caption";s:4:"Date";s:8:"required";s:1:"1";s:4:"time";s:1:"1";s:4:"ampm";s:1:"1";s:9:"req_start";s:0:"";s:7:"req_end";s:0:"";s:5:"value";s:0:"";s:7:"link_to";s:0:"";s:2:"id";s:0:"";s:5:"class";s:0:"";s:6:"format";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:19:"is_filter_range_end";s:0:"";s:14:"document_ready";s:0:"";s:9:"only_time";s:0:"";s:16:"regular_interval";s:0:"";s:13:"only_interval";s:0:"";}', 1, 210, 0),
(1697, 'selectInput', 'a:20:{s:4:"name";s:10:"order_type";s:7:"caption";s:10:"Order Type";s:8:"required";s:1:"1";s:5:"value";s:0:"";s:13:"options_array";s:0:"";s:8:"subtable";s:11:"order_types";s:15:"subtable_fields";a:1:{s:7:"name_en";s:7:"name_en";}s:13:"subtable_f_id";s:0:"";s:2:"id";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:10:"f_id_field";s:0:"";s:12:"default_text";s:0:"";s:10:"depends_on";s:0:"";s:20:"function_to_elements";s:0:"";s:16:"first_is_default";s:0:"";s:5:"level";s:0:"";s:11:"concat_char";s:0:"";s:9:"is_catsel";s:0:"";}', 3, 210, 0),
(1698, 'autoComplete', 'a:22:{s:4:"name";s:9:"site_user";s:7:"caption";s:4:"User";s:8:"required";s:1:"1";s:5:"value";s:0:"";s:8:"multiple";s:0:"";s:13:"options_array";s:0:"";s:8:"subtable";s:10:"site_users";s:15:"subtable_fields";a:1:{s:4:"user";s:4:"user";}s:13:"subtable_f_id";s:0:"";s:2:"id";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:10:"depends_on";s:0:"";s:10:"depend_url";s:0:"";s:10:"f_id_field";s:0:"";s:17:"list_field_values";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";s:12:"is_tokenizer";s:0:"";s:16:"get_table_fields";s:0:"";s:16:"first_is_default";s:0:"";}', 2, 210, 0),
(1699, 'textInput', 'a:13:{s:4:"name";s:3:"btc";s:7:"caption";s:10:"BTC Amount";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 4, 210, 0),
(1700, 'textInput', 'a:13:{s:4:"name";s:4:"fiat";s:7:"caption";s:11:"Fiat Amount";s:8:"required";s:1:"1";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 7, 210, 0),
(1703, 'textInput', 'a:13:{s:4:"name";s:9:"btc_price";s:7:"caption";s:9:"BTC Price";s:8:"required";s:1:"1";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 6, 210, 0),
(1701, 'selectInput', 'a:20:{s:4:"name";s:8:"currency";s:7:"caption";s:13:"Fiat Currency";s:8:"required";s:1:"1";s:5:"value";s:0:"";s:13:"options_array";s:0:"";s:8:"subtable";s:10:"currencies";s:15:"subtable_fields";a:1:{s:8:"currency";s:8:"currency";}s:13:"subtable_f_id";s:0:"";s:2:"id";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:10:"f_id_field";s:0:"";s:12:"default_text";s:0:"";s:10:"depends_on";s:0:"";s:20:"function_to_elements";s:0:"";s:16:"first_is_default";s:0:"";s:5:"level";s:0:"";s:11:"concat_char";s:0:"";s:9:"is_catsel";s:0:"";}', 8, 210, 0),
(1885, 'textInput', 'a:13:{s:4:"name";s:11:"description";s:7:"caption";s:11:"Description";s:8:"required";s:1:"1";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 2, 240, 0),
(1705, 'submitButton', 'a:6:{s:4:"name";s:4:"Save";s:5:"value";s:4:"Save";s:2:"id";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";}', 11, 210, 0),
(1706, 'cancelButton', 'a:4:{s:5:"value";s:6:"Cancel";s:2:"id";s:0:"";s:5:"class";s:0:"";s:5:"style";s:0:"";}', 12, 210, 0),
(1707, 'field', 'a:14:{s:4:"name";s:9:"site_user";s:7:"caption";s:4:"User";s:8:"subtable";s:10:"site_users";s:15:"subtable_fields";a:1:{s:4:"user";s:4:"user";}s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 1, 214, 0),
(1708, 'field', 'a:14:{s:4:"name";s:10:"order_type";s:7:"caption";s:10:"Order Type";s:8:"subtable";s:11:"order_types";s:15:"subtable_fields";a:1:{s:7:"name_en";s:7:"name_en";}s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 2, 214, 0),
(1709, 'field', 'a:14:{s:4:"name";s:4:"date";s:7:"caption";s:4:"Date";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 3, 214, 0),
(1710, 'field', 'a:14:{s:4:"name";s:3:"btc";s:7:"caption";s:10:"BTC Amount";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 4, 214, 0),
(1711, 'field', 'a:14:{s:4:"name";s:9:"btc_price";s:7:"caption";s:9:"BTC Price";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 5, 214, 0),
(1712, 'field', 'a:14:{s:4:"name";s:4:"fiat";s:7:"caption";s:11:"Fiat Amount";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 7, 214, 0),
(1713, 'field', 'a:14:{s:4:"name";s:8:"currency";s:7:"caption";s:13:"Fiat Currency";s:8:"subtable";s:10:"currencies";s:15:"subtable_fields";a:1:{s:8:"currency";s:8:"currency";}s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 8, 214, 0),
(1865, 'textInput', 'a:13:{s:4:"name";s:8:"btc_net1";s:7:"caption";s:9:"Net BTC 2";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 34, 216, 0),
(1715, 'cancelButton', 'a:4:{s:5:"value";s:2:"OK";s:2:"id";s:0:"";s:5:"class";s:0:"";s:5:"style";s:0:"";}', 10, 214, 0),
(1716, 'field', 'a:18:{s:4:"name";s:2:"id";s:8:"subtable";s:0:"";s:14:"header_caption";s:2:"ID";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";s:0:"";s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 0, 215, 0),
(1717, 'passiveField', 'a:14:{s:4:"name";s:2:"id";s:7:"caption";s:2:"ID";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:15:"create_db_field";s:0:"";s:13:"default_value";s:0:"";s:23:"dont_fill_automatically";s:0:"";}', 0, 210, 0),
(1718, 'field', 'a:14:{s:4:"name";s:2:"id";s:7:"caption";s:2:"ID";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 0, 214, 0),
(1719, 'field', 'a:18:{s:4:"name";s:9:"site_user";s:8:"subtable";s:10:"site_users";s:14:"header_caption";s:4:"User";s:6:"filter";s:1:"Y";s:8:"link_url";s:19:"registered-visitors";s:15:"subtable_fields";a:1:{s:4:"user";s:4:"user";}s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:1:"1";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 2, 215, 0),
(1720, 'field', 'a:18:{s:4:"name";s:10:"order_type";s:8:"subtable";s:11:"order_types";s:14:"header_caption";s:10:"Order Type";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";a:1:{s:7:"name_en";s:7:"name_en";}s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 3, 215, 0),
(1721, 'field', 'a:18:{s:4:"name";s:4:"date";s:8:"subtable";s:0:"";s:14:"header_caption";s:4:"Date";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";s:0:"";s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 1, 215, 0),
(1722, 'field', 'a:18:{s:4:"name";s:3:"btc";s:8:"subtable";s:0:"";s:14:"header_caption";s:3:"BTC";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";s:0:"";s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 4, 215, 0),
(1723, 'field', 'a:18:{s:4:"name";s:9:"btc_price";s:8:"subtable";s:0:"";s:14:"header_caption";s:5:"Price";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";s:0:"";s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 5, 215, 0),
(1724, 'field', 'a:18:{s:4:"name";s:4:"fiat";s:8:"subtable";s:0:"";s:14:"header_caption";s:4:"Fiat";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";s:0:"";s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 6, 215, 0),
(1725, 'field', 'a:18:{s:4:"name";s:8:"currency";s:8:"subtable";s:10:"currencies";s:14:"header_caption";s:8:"Currency";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";a:1:{s:8:"currency";s:8:"currency";}s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 7, 215, 0),
(1889, 'field', 'a:18:{s:4:"name";s:2:"id";s:8:"subtable";s:0:"";s:14:"header_caption";s:2:"ID";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";s:0:"";s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 0, 241, 0),
(1727, 'dateWidget', 'a:19:{s:4:"name";s:4:"date";s:7:"caption";s:4:"Date";s:8:"required";s:1:"1";s:4:"time";s:1:"1";s:4:"ampm";s:1:"1";s:9:"req_start";s:0:"";s:7:"req_end";s:0:"";s:5:"value";s:0:"";s:7:"link_to";s:0:"";s:2:"id";s:0:"";s:5:"class";s:0:"";s:6:"format";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:19:"is_filter_range_end";s:0:"";s:14:"document_ready";s:0:"";s:9:"only_time";s:0:"";s:16:"regular_interval";s:0:"";s:13:"only_interval";s:0:"";}', 2, 216, 0),
(1728, 'autoComplete', 'a:22:{s:4:"name";s:9:"site_user";s:7:"caption";s:6:"User 1";s:8:"required";s:1:"1";s:5:"value";s:0:"";s:8:"multiple";s:0:"";s:13:"options_array";s:0:"";s:8:"subtable";s:10:"site_users";s:15:"subtable_fields";a:1:{s:4:"user";s:4:"user";}s:13:"subtable_f_id";s:0:"";s:2:"id";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:10:"depends_on";s:0:"";s:10:"depend_url";s:0:"";s:10:"f_id_field";s:0:"";s:17:"list_field_values";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";s:12:"is_tokenizer";s:0:"";s:16:"get_table_fields";s:0:"";s:16:"first_is_default";s:0:"";}', 17, 216, 0),
(1767, 'textInput', 'a:13:{s:4:"name";s:7:"name_en";s:7:"caption";s:9:"Name (EN)";s:8:"required";s:1:"1";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 0, 222, 0),
(1768, 'textInput', 'a:13:{s:4:"name";s:7:"name_es";s:7:"caption";s:9:"Name (ES)";s:8:"required";s:1:"1";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 1, 222, 0),
(1730, 'textInput', 'a:13:{s:4:"name";s:3:"btc";s:7:"caption";s:20:"BTC Amount (Curr. 1)";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 3, 216, 0),
(1731, 'textInput', 'a:13:{s:4:"name";s:9:"btc_price";s:7:"caption";s:19:"BTC Price (Curr. 1)";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 4, 216, 0),
(1732, 'textInput', 'a:13:{s:4:"name";s:4:"fiat";s:7:"caption";s:21:"Fiat Amount (Curr. 1)";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 6, 216, 0),
(1757, 'selectInput', 'a:20:{s:4:"name";s:8:"currency";s:7:"caption";s:15:"Fiat Currency 1";s:8:"required";s:0:"";s:5:"value";s:0:"";s:13:"options_array";s:0:"";s:8:"subtable";s:10:"currencies";s:15:"subtable_fields";a:1:{s:8:"currency";s:8:"currency";}s:13:"subtable_f_id";s:0:"";s:2:"id";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:10:"f_id_field";s:0:"";s:12:"default_text";s:0:"";s:10:"depends_on";s:0:"";s:20:"function_to_elements";s:0:"";s:16:"first_is_default";s:0:"";s:5:"level";s:0:"";s:11:"concat_char";s:0:"";s:9:"is_catsel";s:0:"";}', 19, 216, 0),
(1734, 'textInput', 'a:13:{s:4:"name";s:3:"fee";s:7:"caption";s:5:"Fee 1";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 21, 216, 0),
(1735, 'submitButton', 'a:6:{s:4:"name";s:4:"Save";s:5:"value";s:4:"Save";s:2:"id";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";}', 43, 216, 0),
(1736, 'cancelButton', 'a:4:{s:5:"value";s:6:"Cancel";s:2:"id";s:0:"";s:5:"class";s:0:"";s:5:"style";s:0:"";}', 44, 216, 0),
(1737, 'passiveField', 'a:14:{s:4:"name";s:2:"id";s:7:"caption";s:2:"ID";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:15:"create_db_field";s:0:"";s:13:"default_value";s:0:"";s:23:"dont_fill_automatically";s:0:"";}', 1, 216, 0),
(1738, 'field', 'a:14:{s:4:"name";s:2:"id";s:7:"caption";s:2:"ID";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 1, 217, 0),
(1739, 'field', 'a:14:{s:4:"name";s:4:"date";s:7:"caption";s:4:"Date";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 2, 217, 0),
(1740, 'field', 'a:14:{s:4:"name";s:9:"site_user";s:7:"caption";s:6:"User 1";s:8:"subtable";s:10:"site_users";s:15:"subtable_fields";a:1:{s:4:"user";s:4:"user";}s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 17, 217, 0),
(1741, 'field', 'a:14:{s:4:"name";s:16:"transaction_type";s:7:"caption";s:18:"Transaction Type 1";s:8:"subtable";s:17:"transaction_types";s:15:"subtable_fields";a:1:{s:7:"name_en";s:7:"name_en";}s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 18, 217, 0),
(1742, 'field', 'a:14:{s:4:"name";s:3:"btc";s:7:"caption";s:20:"BTC Amount (Curr. 1)";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 3, 217, 0),
(1743, 'field', 'a:14:{s:4:"name";s:9:"btc_price";s:7:"caption";s:19:"BTC Price (Curr. 1)";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 4, 217, 0),
(1744, 'field', 'a:14:{s:4:"name";s:4:"fiat";s:7:"caption";s:21:"Fiat Amount (Curr. 1)";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 6, 217, 0);
INSERT INTO `admin_controls_methods` (`id`, `method`, `arguments`, `order`, `control_id`, `p_id`) VALUES
(1745, 'field', 'a:14:{s:4:"name";s:8:"currency";s:7:"caption";s:15:"Fiat Currency 1";s:8:"subtable";s:10:"currencies";s:15:"subtable_fields";a:1:{s:8:"currency";s:8:"currency";}s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 19, 217, 0),
(1746, 'field', 'a:14:{s:4:"name";s:3:"fee";s:7:"caption";s:5:"Fee 1";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 20, 217, 0),
(1747, 'cancelButton', 'a:4:{s:5:"value";s:2:"OK";s:2:"id";s:0:"";s:5:"class";s:0:"";s:5:"style";s:0:"";}', 41, 217, 0),
(1748, 'field', 'a:18:{s:4:"name";s:2:"id";s:8:"subtable";s:0:"";s:14:"header_caption";s:2:"ID";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";s:0:"";s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 1, 218, 0),
(1749, 'field', 'a:18:{s:4:"name";s:4:"date";s:8:"subtable";s:0:"";s:14:"header_caption";s:4:"Date";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";s:0:"";s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 2, 218, 0),
(1750, 'field', 'a:18:{s:4:"name";s:9:"site_user";s:8:"subtable";s:10:"site_users";s:14:"header_caption";s:6:"User 1";s:6:"filter";s:1:"Y";s:8:"link_url";s:19:"registered-visitors";s:15:"subtable_fields";a:1:{s:4:"user";s:4:"user";}s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:1:"1";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 3, 218, 0),
(1751, 'field', 'a:18:{s:4:"name";s:16:"transaction_type";s:8:"subtable";s:17:"transaction_types";s:14:"header_caption";s:18:"Transaction Type 1";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";a:1:{s:7:"name_en";s:7:"name_en";}s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 4, 218, 0),
(1752, 'field', 'a:18:{s:4:"name";s:3:"btc";s:8:"subtable";s:0:"";s:14:"header_caption";s:3:"BTC";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";s:0:"";s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 9, 218, 0),
(1753, 'field', 'a:18:{s:4:"name";s:9:"btc_price";s:8:"subtable";s:0:"";s:14:"header_caption";s:5:"Price";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";s:0:"";s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 10, 218, 0),
(1754, 'field', 'a:18:{s:4:"name";s:4:"fiat";s:8:"subtable";s:0:"";s:14:"header_caption";s:4:"Fiat";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";s:0:"";s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 11, 218, 0),
(1755, 'field', 'a:18:{s:4:"name";s:8:"currency";s:8:"subtable";s:10:"currencies";s:14:"header_caption";s:10:"Currency 1";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";a:1:{s:8:"currency";s:8:"currency";}s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 5, 218, 0),
(1756, 'field', 'a:18:{s:4:"name";s:3:"fee";s:8:"subtable";s:0:"";s:14:"header_caption";s:5:"Fee 1";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";s:0:"";s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 12, 218, 0),
(1758, 'textInput', 'a:13:{s:4:"name";s:7:"name_en";s:7:"caption";s:9:"Name (EN)";s:8:"required";s:1:"1";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 0, 219, 0),
(1759, 'textInput', 'a:13:{s:4:"name";s:7:"name_es";s:7:"caption";s:9:"Name (ES)";s:8:"required";s:1:"1";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 1, 219, 0),
(1760, 'submitButton', 'a:6:{s:4:"name";s:4:"Save";s:5:"value";s:4:"Save";s:2:"id";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";}', 2, 219, 0),
(1761, 'cancelButton', 'a:4:{s:5:"value";s:6:"Cancel";s:2:"id";s:0:"";s:5:"class";s:0:"";s:5:"style";s:0:"";}', 3, 219, 0),
(1762, 'field', 'a:14:{s:4:"name";s:7:"name_en";s:7:"caption";s:9:"Name (EN)";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 0, 220, 0),
(1763, 'field', 'a:14:{s:4:"name";s:7:"name_es";s:7:"caption";s:9:"Name (ES)";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 1, 220, 0),
(1764, 'cancelButton', 'a:4:{s:5:"value";s:2:"OK";s:2:"id";s:0:"";s:5:"class";s:0:"";s:5:"style";s:0:"";}', 2, 220, 0),
(1765, 'addTable', 'a:8:{s:5:"table";s:17:"transaction_types";s:12:"table_fields";a:1:{s:7:"name_en";s:7:"name_en";}s:3:"url";s:0:"";s:6:"parent";s:0:"";s:5:"class";s:0:"";s:14:"target_elem_id";s:8:"edit_box";s:10:"url_is_tab";s:0:"";s:15:"accept_children";s:0:"";}', 0, 221, 0),
(1766, 'selectInput', 'a:20:{s:4:"name";s:17:"transaction_type1";s:7:"caption";s:18:"Transaction Type 2";s:8:"required";s:0:"";s:5:"value";s:0:"";s:13:"options_array";s:0:"";s:8:"subtable";s:17:"transaction_types";s:15:"subtable_fields";a:1:{s:7:"name_en";s:7:"name_en";}s:13:"subtable_f_id";s:0:"";s:2:"id";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:10:"f_id_field";s:0:"";s:12:"default_text";s:0:"";s:10:"depends_on";s:0:"";s:20:"function_to_elements";s:0:"";s:16:"first_is_default";s:0:"";s:5:"level";s:0:"";s:11:"concat_char";s:0:"";s:9:"is_catsel";s:0:"";}', 32, 216, 0),
(1769, 'submitButton', 'a:6:{s:4:"name";s:4:"Save";s:5:"value";s:4:"Save";s:2:"id";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";}', 2, 222, 0),
(1770, 'cancelButton', 'a:4:{s:5:"value";s:6:"Cancel";s:2:"id";s:0:"";s:5:"class";s:0:"";s:5:"style";s:0:"";}', 3, 222, 0),
(1771, 'field', 'a:14:{s:4:"name";s:7:"name_en";s:7:"caption";s:9:"Name (EN)";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 0, 223, 0),
(1772, 'field', 'a:14:{s:4:"name";s:7:"name_es";s:7:"caption";s:9:"Name (ES)";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 1, 223, 0),
(1773, 'cancelButton', 'a:4:{s:5:"value";s:2:"OK";s:2:"id";s:0:"";s:5:"class";s:0:"";s:5:"style";s:0:"";}', 2, 223, 0),
(1774, 'addTable', 'a:8:{s:5:"table";s:13:"request_types";s:12:"table_fields";a:1:{s:7:"name_en";s:7:"name_en";}s:3:"url";s:0:"";s:6:"parent";s:0:"";s:5:"class";s:0:"";s:14:"target_elem_id";s:8:"edit_box";s:10:"url_is_tab";s:0:"";s:15:"accept_children";s:0:"";}', 0, 224, 0),
(1775, 'textInput', 'a:13:{s:4:"name";s:7:"name_en";s:7:"caption";s:9:"Name (EN)";s:8:"required";s:1:"1";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 0, 226, 0),
(1776, 'textInput', 'a:13:{s:4:"name";s:7:"name_es";s:7:"caption";s:9:"Name (ES)";s:8:"required";s:1:"1";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 1, 226, 0),
(1777, 'submitButton', 'a:6:{s:4:"name";s:4:"Save";s:5:"value";s:4:"Save";s:2:"id";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";}', 2, 226, 0),
(1778, 'cancelButton', 'a:4:{s:5:"value";s:6:"Cancel";s:2:"id";s:0:"";s:5:"class";s:0:"";s:5:"style";s:0:"";}', 3, 226, 0),
(1779, 'field', 'a:14:{s:4:"name";s:7:"name_en";s:7:"caption";s:9:"Name (EN)";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 0, 227, 0),
(1780, 'field', 'a:14:{s:4:"name";s:7:"name_es";s:7:"caption";s:9:"Name (ES)";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 1, 227, 0),
(1781, 'cancelButton', 'a:4:{s:5:"value";s:2:"OK";s:2:"id";s:0:"";s:5:"class";s:0:"";s:5:"style";s:0:"";}', 2, 227, 0),
(1782, 'addTable', 'a:8:{s:5:"table";s:14:"request_status";s:12:"table_fields";a:1:{s:7:"name_en";s:7:"name_en";}s:3:"url";s:0:"";s:6:"parent";s:0:"";s:5:"class";s:0:"";s:14:"target_elem_id";s:8:"edit_box";s:10:"url_is_tab";s:0:"";s:15:"accept_children";s:0:"";}', 0, 228, 0),
(1783, 'dateWidget', 'a:19:{s:4:"name";s:4:"date";s:7:"caption";s:4:"Date";s:8:"required";s:1:"1";s:4:"time";s:1:"1";s:4:"ampm";s:1:"1";s:9:"req_start";s:0:"";s:7:"req_end";s:0:"";s:5:"value";s:0:"";s:7:"link_to";s:0:"";s:2:"id";s:0:"";s:5:"class";s:0:"";s:6:"format";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:19:"is_filter_range_end";s:0:"";s:14:"document_ready";s:0:"";s:9:"only_time";s:0:"";s:16:"regular_interval";s:0:"";s:13:"only_interval";s:0:"";}', 1, 225, 0),
(1784, 'textInput', 'a:13:{s:4:"name";s:7:"name_en";s:7:"caption";s:9:"Name (EN)";s:8:"required";s:1:"1";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 1, 211, 0),
(1785, 'textInput', 'a:13:{s:4:"name";s:7:"name_es";s:7:"caption";s:9:"Name (ES)";s:8:"required";s:1:"1";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 2, 211, 0),
(1786, 'field', 'a:14:{s:4:"name";s:7:"name_en";s:7:"caption";s:9:"Name (EN)";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 1, 212, 0),
(1787, 'field', 'a:14:{s:4:"name";s:7:"name_es";s:7:"caption";s:9:"Name (ES)";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 2, 212, 0),
(1789, 'textInput', 'a:13:{s:4:"name";s:7:"name_en";s:7:"caption";s:16:"Description (EN)";s:8:"required";s:1:"1";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 0, 229, 0),
(1790, 'textInput', 'a:13:{s:4:"name";s:7:"name_es";s:7:"caption";s:16:"Description (ES)";s:8:"required";s:1:"1";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 1, 229, 0),
(1791, 'submitButton', 'a:6:{s:4:"name";s:4:"Save";s:5:"value";s:4:"Save";s:2:"id";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";}', 2, 229, 0),
(1792, 'cancelButton', 'a:4:{s:5:"value";s:6:"Cancel";s:2:"id";s:0:"";s:5:"class";s:0:"";s:5:"style";s:0:"";}', 3, 229, 0),
(1793, 'field', 'a:14:{s:4:"name";s:7:"name_en";s:7:"caption";s:16:"Description (EN)";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 0, 230, 0),
(1794, 'field', 'a:14:{s:4:"name";s:7:"name_es";s:7:"caption";s:16:"Description (ES)";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 1, 230, 0),
(1795, 'cancelButton', 'a:4:{s:5:"value";s:2:"OK";s:2:"id";s:0:"";s:5:"class";s:0:"";s:5:"style";s:0:"";}', 2, 230, 0),
(1796, 'addTable', 'a:8:{s:5:"table";s:20:"request_descriptions";s:12:"table_fields";a:1:{s:7:"name_en";s:7:"name_en";}s:3:"url";s:0:"";s:6:"parent";s:0:"";s:5:"class";s:0:"";s:14:"target_elem_id";s:8:"edit_box";s:10:"url_is_tab";s:0:"";s:15:"accept_children";s:0:"";}', 0, 231, 0),
(1797, 'selectInput', 'a:20:{s:4:"name";s:8:"currency";s:7:"caption";s:8:"Currency";s:8:"required";s:1:"1";s:5:"value";s:0:"";s:13:"options_array";s:0:"";s:8:"subtable";s:10:"currencies";s:15:"subtable_fields";a:1:{s:8:"currency";s:8:"currency";}s:13:"subtable_f_id";s:0:"";s:2:"id";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:10:"f_id_field";s:0:"";s:12:"default_text";s:0:"";s:10:"depends_on";s:0:"";s:20:"function_to_elements";s:0:"";s:16:"first_is_default";s:0:"";s:5:"level";s:0:"";s:11:"concat_char";s:0:"";s:9:"is_catsel";s:0:"";}', 4, 225, 0),
(1798, 'textInput', 'a:13:{s:4:"name";s:6:"amount";s:7:"caption";s:6:"Amount";s:8:"required";s:1:"1";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 5, 225, 0),
(1799, 'selectInput', 'a:20:{s:4:"name";s:11:"description";s:7:"caption";s:11:"Description";s:8:"required";s:1:"1";s:5:"value";s:0:"";s:13:"options_array";s:0:"";s:8:"subtable";s:20:"request_descriptions";s:15:"subtable_fields";a:1:{s:7:"name_en";s:7:"name_en";}s:13:"subtable_f_id";s:0:"";s:2:"id";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:10:"f_id_field";s:0:"";s:12:"default_text";s:0:"";s:10:"depends_on";s:0:"";s:20:"function_to_elements";s:0:"";s:16:"first_is_default";s:0:"";s:5:"level";s:0:"";s:11:"concat_char";s:0:"";s:9:"is_catsel";s:0:"";}', 6, 225, 0),
(1800, 'selectInput', 'a:20:{s:4:"name";s:14:"request_status";s:7:"caption";s:14:"Request Status";s:8:"required";s:1:"1";s:5:"value";s:0:"";s:13:"options_array";s:0:"";s:8:"subtable";s:14:"request_status";s:15:"subtable_fields";a:1:{s:7:"name_en";s:7:"name_en";}s:13:"subtable_f_id";s:0:"";s:2:"id";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:10:"f_id_field";s:0:"";s:12:"default_text";s:0:"";s:10:"depends_on";s:0:"";s:20:"function_to_elements";s:0:"";s:16:"first_is_default";s:0:"";s:5:"level";s:0:"";s:11:"concat_char";s:0:"";s:9:"is_catsel";s:0:"";}', 7, 225, 0),
(1801, 'submitButton', 'a:6:{s:4:"name";s:4:"Save";s:5:"value";s:4:"Save";s:2:"id";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";}', 16, 225, 0),
(1802, 'cancelButton', 'a:4:{s:5:"value";s:6:"Cancel";s:2:"id";s:0:"";s:5:"class";s:0:"";s:5:"style";s:0:"";}', 17, 225, 0),
(1803, 'field', 'a:14:{s:4:"name";s:2:"id";s:7:"caption";s:2:"ID";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 0, 232, 0),
(1804, 'field', 'a:14:{s:4:"name";s:4:"date";s:7:"caption";s:4:"Date";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 1, 232, 0),
(1805, 'field', 'a:14:{s:4:"name";s:9:"site_user";s:7:"caption";s:4:"User";s:8:"subtable";s:10:"site_users";s:15:"subtable_fields";a:1:{s:4:"user";s:4:"user";}s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 3, 232, 0),
(1806, 'field', 'a:14:{s:4:"name";s:8:"currency";s:7:"caption";s:8:"Currency";s:8:"subtable";s:10:"currencies";s:15:"subtable_fields";a:1:{s:8:"currency";s:8:"currency";}s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 4, 232, 0),
(1807, 'field', 'a:14:{s:4:"name";s:6:"amount";s:7:"caption";s:6:"Amount";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 5, 232, 0),
(1808, 'field', 'a:14:{s:4:"name";s:11:"description";s:7:"caption";s:11:"Description";s:8:"subtable";s:20:"request_descriptions";s:15:"subtable_fields";a:1:{s:7:"name_en";s:7:"name_en";}s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 6, 232, 0),
(1809, 'field', 'a:14:{s:4:"name";s:14:"request_status";s:7:"caption";s:6:"Status";s:8:"subtable";s:14:"request_status";s:15:"subtable_fields";a:1:{s:7:"name_en";s:7:"name_en";}s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 7, 232, 0),
(1810, 'cancelButton', 'a:4:{s:5:"value";s:2:"OK";s:2:"id";s:0:"";s:5:"class";s:0:"";s:5:"style";s:0:"";}', 10, 232, 0),
(1811, 'passiveField', 'a:14:{s:4:"name";s:2:"id";s:7:"caption";s:2:"ID";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:15:"create_db_field";s:0:"";s:13:"default_value";s:0:"";s:23:"dont_fill_automatically";s:0:"";}', 0, 225, 0),
(1812, 'field', 'a:18:{s:4:"name";s:2:"id";s:8:"subtable";s:0:"";s:14:"header_caption";s:2:"ID";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";s:0:"";s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 5, 233, 0),
(1813, 'field', 'a:18:{s:4:"name";s:4:"date";s:8:"subtable";s:0:"";s:14:"header_caption";s:4:"Date";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";s:0:"";s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 7, 233, 0),
(1814, 'field', 'a:18:{s:4:"name";s:9:"site_user";s:8:"subtable";s:10:"site_users";s:14:"header_caption";s:4:"User";s:6:"filter";s:1:"Y";s:8:"link_url";s:19:"registered-visitors";s:15:"subtable_fields";a:1:{s:4:"user";s:4:"user";}s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:1:"1";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 8, 233, 0),
(1815, 'field', 'a:18:{s:4:"name";s:8:"currency";s:8:"subtable";s:10:"currencies";s:14:"header_caption";s:8:"Currency";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";a:1:{s:8:"currency";s:8:"currency";}s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 9, 233, 0),
(1816, 'field', 'a:18:{s:4:"name";s:6:"amount";s:8:"subtable";s:0:"";s:14:"header_caption";s:6:"Amount";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";s:0:"";s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 10, 233, 0),
(1817, 'field', 'a:18:{s:4:"name";s:11:"description";s:8:"subtable";s:20:"request_descriptions";s:14:"header_caption";s:11:"Description";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";a:1:{s:7:"name_en";s:7:"name_en";}s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 12, 233, 0),
(1818, 'field', 'a:18:{s:4:"name";s:14:"request_status";s:8:"subtable";s:14:"request_status";s:14:"header_caption";s:6:"Status";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";a:1:{s:7:"name_en";s:7:"name_en";}s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 13, 233, 0),
(1820, 'autoComplete', 'a:22:{s:4:"name";s:10:"site_user1";s:7:"caption";s:6:"User 2";s:8:"required";s:0:"";s:5:"value";s:0:"";s:8:"multiple";s:0:"";s:13:"options_array";s:0:"";s:8:"subtable";s:10:"site_users";s:15:"subtable_fields";a:1:{s:4:"user";s:4:"user";}s:13:"subtable_f_id";s:0:"";s:2:"id";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:10:"depends_on";s:0:"";s:10:"depend_url";s:0:"";s:10:"f_id_field";s:0:"";s:17:"list_field_values";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";s:12:"is_tokenizer";s:0:"";s:16:"get_table_fields";s:0:"";s:16:"first_is_default";s:0:"";}', 31, 216, 0),
(1821, 'selectInput', 'a:20:{s:4:"name";s:16:"transaction_type";s:7:"caption";s:18:"Transaction Type 1";s:8:"required";s:1:"1";s:5:"value";s:0:"";s:13:"options_array";s:0:"";s:8:"subtable";s:17:"transaction_types";s:15:"subtable_fields";a:1:{s:7:"name_en";s:7:"name_en";}s:13:"subtable_f_id";s:0:"";s:2:"id";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:10:"f_id_field";s:0:"";s:12:"default_text";s:0:"";s:10:"depends_on";s:0:"";s:20:"function_to_elements";s:0:"";s:16:"first_is_default";s:0:"";s:5:"level";s:0:"";s:11:"concat_char";s:0:"";s:9:"is_catsel";s:0:"";}', 18, 216, 0),
(1822, 'field', 'a:14:{s:4:"name";s:10:"site_user1";s:7:"caption";s:6:"User 2";s:8:"subtable";s:10:"site_users";s:15:"subtable_fields";a:1:{s:4:"user";s:4:"user";}s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 30, 217, 0),
(1823, 'field', 'a:14:{s:4:"name";s:17:"transaction_type1";s:7:"caption";s:18:"Transaction Type 2";s:8:"subtable";s:17:"transaction_types";s:15:"subtable_fields";a:1:{s:7:"name_en";s:7:"name_en";}s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 31, 217, 0),
(1824, 'field', 'a:18:{s:4:"name";s:10:"site_user1";s:8:"subtable";s:10:"site_users";s:14:"header_caption";s:6:"User 2";s:6:"filter";s:1:"Y";s:8:"link_url";s:19:"registered-visitors";s:15:"subtable_fields";a:1:{s:4:"user";s:4:"user";}s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:1:"1";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 6, 218, 0),
(1825, 'field', 'a:18:{s:4:"name";s:17:"transaction_type1";s:8:"subtable";s:17:"transaction_types";s:14:"header_caption";s:18:"Transaction Type 2";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";a:1:{s:7:"name_en";s:7:"name_en";}s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 7, 218, 0),
(1826, 'textInput', 'a:13:{s:4:"name";s:4:"fee1";s:7:"caption";s:5:"Fee 2";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 35, 216, 0),
(1827, 'field', 'a:14:{s:4:"name";s:4:"fee1";s:7:"caption";s:5:"Fee 2";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 33, 217, 0),
(1828, 'field', 'a:18:{s:4:"name";s:4:"fee1";s:8:"subtable";s:0:"";s:14:"header_caption";s:5:"Fee 2";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";s:0:"";s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 13, 218, 0),
(1864, 'textInput', 'a:13:{s:4:"name";s:7:"btc_net";s:7:"caption";s:9:"Net BTC 1";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 20, 216, 0),
(1886, 'submitButton', 'a:6:{s:4:"name";s:4:"Save";s:5:"value";s:4:"Save";s:2:"id";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";}', 4, 240, 0),
(1887, 'cancelButton', 'a:4:{s:5:"value";s:6:"Cancel";s:2:"id";s:0:"";s:5:"class";s:0:"";s:5:"style";s:0:"";}', 5, 240, 0),
(1888, 'autoComplete', 'a:22:{s:4:"name";s:9:"site_user";s:7:"caption";s:4:"User";s:8:"required";s:1:"1";s:5:"value";s:0:"";s:8:"multiple";s:0:"";s:13:"options_array";s:0:"";s:8:"subtable";s:10:"site_users";s:15:"subtable_fields";a:1:{s:4:"user";s:4:"user";}s:13:"subtable_f_id";s:0:"";s:2:"id";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:10:"depends_on";s:0:"";s:10:"depend_url";s:0:"";s:10:"f_id_field";s:0:"";s:17:"list_field_values";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";s:12:"is_tokenizer";s:0:"";s:16:"get_table_fields";s:0:"";s:16:"first_is_default";s:0:"";}', 0, 240, 0),
(1832, 'textInput', 'a:13:{s:4:"name";s:8:"title_en";s:7:"caption";s:10:"Title (EN)";s:8:"required";s:1:"1";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 0, 234, 0),
(1833, 'textInput', 'a:13:{s:4:"name";s:8:"title_es";s:7:"caption";s:10:"Title (ES)";s:8:"required";s:1:"1";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 1, 234, 0),
(1834, 'dateWidget', 'a:19:{s:4:"name";s:4:"date";s:7:"caption";s:4:"Date";s:8:"required";s:1:"1";s:4:"time";s:1:"1";s:4:"ampm";s:1:"1";s:9:"req_start";s:0:"";s:7:"req_end";s:0:"";s:5:"value";s:0:"";s:7:"link_to";s:0:"";s:2:"id";s:0:"";s:5:"class";s:0:"";s:6:"format";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:19:"is_filter_range_end";s:0:"";s:14:"document_ready";s:0:"";s:9:"only_time";s:0:"";s:16:"regular_interval";s:0:"";s:13:"only_interval";s:0:"";}', 2, 234, 0),
(1835, 'textEditor', 'a:11:{s:4:"name";s:10:"content_en";s:7:"caption";s:12:"Content (EN)";s:8:"required";s:1:"1";s:5:"value";s:0:"";s:2:"id";s:0:"";s:7:"echo_on";s:0:"";s:5:"class";s:0:"";s:8:"is_basic";s:0:"";s:12:"allow_images";s:0:"";s:6:"height";s:0:"";s:9:"method_id";s:0:"";}', 3, 234, 0),
(1836, 'textEditor', 'a:11:{s:4:"name";s:10:"content_es";s:7:"caption";s:12:"Content (ES)";s:8:"required";s:1:"1";s:5:"value";s:0:"";s:2:"id";s:0:"";s:7:"echo_on";s:0:"";s:5:"class";s:0:"";s:8:"is_basic";s:0:"";s:12:"allow_images";s:0:"";s:6:"height";s:0:"";s:9:"method_id";s:0:"";}', 4, 234, 0),
(1837, 'submitButton', 'a:6:{s:4:"name";s:4:"Save";s:5:"value";s:4:"Save";s:2:"id";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";}', 5, 234, 0),
(1838, 'cancelButton', 'a:4:{s:5:"value";s:4:"Back";s:2:"id";s:0:"";s:5:"class";s:0:"";s:5:"style";s:0:"";}', 6, 234, 0),
(1839, 'field', 'a:14:{s:4:"name";s:8:"title_en";s:7:"caption";s:10:"Title (EN)";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 0, 235, 0),
(1840, 'field', 'a:14:{s:4:"name";s:8:"title_es";s:7:"caption";s:10:"Title (ES)";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 1, 235, 0),
(1841, 'field', 'a:14:{s:4:"name";s:4:"date";s:7:"caption";s:4:"Date";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 2, 235, 0),
(1842, 'field', 'a:14:{s:4:"name";s:10:"content_en";s:7:"caption";s:12:"Content (EN)";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 3, 235, 0),
(1843, 'field', 'a:14:{s:4:"name";s:10:"content_es";s:7:"caption";s:12:"Content (ES)";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 4, 235, 0),
(1844, 'cancelButton', 'a:4:{s:5:"value";s:4:"BACK";s:2:"id";s:0:"";s:5:"class";s:0:"";s:5:"style";s:0:"";}', 5, 235, 0),
(1845, 'field', 'a:18:{s:4:"name";s:2:"id";s:8:"subtable";s:0:"";s:14:"header_caption";s:2:"ID";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";s:0:"";s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 0, 236, 0),
(1846, 'field', 'a:18:{s:4:"name";s:8:"title_en";s:8:"subtable";s:0:"";s:14:"header_caption";s:5:"Title";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";s:0:"";s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 1, 236, 0),
(1847, 'field', 'a:18:{s:4:"name";s:4:"date";s:8:"subtable";s:0:"";s:14:"header_caption";s:4:"Date";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";s:0:"";s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 2, 236, 0),
(1925, 'dateWidget', 'a:19:{s:4:"name";s:4:"date";s:7:"caption";s:4:"Date";s:8:"required";s:0:"";s:4:"time";s:1:"1";s:4:"ampm";s:1:"1";s:9:"req_start";s:0:"";s:7:"req_end";s:0:"";s:5:"value";s:0:"";s:7:"link_to";s:0:"";s:2:"id";s:0:"";s:5:"class";s:0:"";s:6:"format";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:19:"is_filter_range_end";s:0:"";s:14:"document_ready";s:0:"";s:9:"only_time";s:0:"";s:16:"regular_interval";s:0:"";s:13:"only_interval";s:0:"";}', 1, 246, 0),
(1926, 'field', 'a:18:{s:4:"name";s:4:"date";s:8:"subtable";s:0:"";s:14:"header_caption";s:4:"Date";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";s:0:"";s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 1, 247, 0),
(1927, 'field', 'a:18:{s:4:"name";s:3:"fee";s:8:"subtable";s:0:"";s:14:"header_caption";s:3:"Fee";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";s:0:"";s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 2, 247, 0),
(1928, 'hiddenInput', 'a:8:{s:4:"name";s:14:"transaction_id";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:5:"vchar";s:7:"jscript";s:0:"";s:20:"is_current_timestamp";s:0:"";s:15:"on_every_update";s:0:"";}', 15, 225, 0),
(1929, 'textInput', 'a:13:{s:4:"name";s:14:"hot_wallet_btc";s:7:"caption";s:14:"Hot Wallet BTC";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 3, 244, 0),
(1930, 'textInput', 'a:13:{s:4:"name";s:15:"warm_wallet_btc";s:7:"caption";s:15:"Warm Wallet BTC";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 4, 244, 0),
(1931, 'textInput', 'a:13:{s:4:"name";s:9:"total_btc";s:7:"caption";s:9:"Total BTC";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 2, 244, 0),
(1932, 'textInput', 'a:13:{s:4:"name";s:20:"received_btc_pending";s:7:"caption";s:26:"BTC Received Pending Sweep";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 6, 244, 0),
(1940, 'filterSelect', 'a:10:{s:10:"field_name";s:20:"requests.description";s:7:"caption";s:11:"Description";s:13:"options_array";s:0:"";s:8:"subtable";s:20:"request_descriptions";s:15:"subtable_fields";a:1:{s:7:"name_en";s:7:"name_en";}s:5:"class";s:0:"";s:10:"f_id_field";s:0:"";s:10:"depends_on";s:0:"";s:5:"level";s:0:"";s:4:"f_id";s:0:"";}', 3, 233, 0),
(1941, 'filterAutocomplete', 'a:6:{s:10:"field_name";s:9:"site_user";s:7:"caption";s:4:"User";s:13:"options_array";s:0:"";s:8:"subtable";s:10:"site_users";s:15:"subtable_fields";a:3:{s:4:"user";s:4:"user";s:10:"first_name";s:10:"first_name";s:9:"last_name";s:9:"last_name";}s:5:"class";s:0:"";}', 0, 233, 0),
(1942, 'dateWidget', 'a:19:{s:4:"name";s:4:"date";s:7:"caption";s:4:"Date";s:8:"required";s:0:"";s:4:"time";s:0:"";s:4:"ampm";s:0:"";s:9:"req_start";s:0:"";s:7:"req_end";s:0:"";s:5:"value";s:0:"";s:7:"link_to";s:0:"";s:2:"id";s:0:"";s:5:"class";s:0:"";s:6:"format";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:19:"is_filter_range_end";s:0:"";s:14:"document_ready";s:0:"";s:9:"only_time";s:0:"";s:16:"regular_interval";s:0:"";s:13:"only_interval";s:0:"";}', 0, 248, 0),
(1943, 'textInput', 'a:13:{s:4:"name";s:15:"open_orders_btc";s:7:"caption";s:15:"Open Orders BTC";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 5, 248, 0),
(1944, 'textInput', 'a:13:{s:4:"name";s:9:"total_btc";s:7:"caption";s:9:"Total BTC";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 1, 248, 0),
(1945, 'textInput', 'a:13:{s:4:"name";s:14:"total_fiat_usd";s:7:"caption";s:14:"Total Fiat USD";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 2, 248, 0),
(1946, 'textInput', 'a:13:{s:4:"name";s:12:"btc_per_user";s:7:"caption";s:12:"BTC per User";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 3, 248, 0),
(1947, 'textInput', 'a:13:{s:4:"name";s:16:"transactions_btc";s:7:"caption";s:16:"Transactions BTC";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 6, 248, 0),
(1948, 'textInput', 'a:13:{s:4:"name";s:24:"avg_transaction_size_btc";s:7:"caption";s:28:"Average Transaction Size BTC";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 7, 248, 0),
(1949, 'textInput', 'a:13:{s:4:"name";s:27:"transaction_volume_per_user";s:7:"caption";s:31:"Transaction Volume per User BTC";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 8, 248, 0),
(1950, 'textInput', 'a:13:{s:4:"name";s:14:"total_fees_btc";s:7:"caption";s:14:"Total Fees BTC";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 9, 248, 0),
(1951, 'textInput', 'a:13:{s:4:"name";s:17:"fees_per_user_btc";s:7:"caption";s:17:"Fees per User BTC";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 10, 248, 0),
(1952, 'submitButton', 'a:6:{s:4:"name";s:4:"Save";s:5:"value";s:4:"Save";s:2:"id";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";}', 12, 248, 0),
(1953, 'cancelButton', 'a:4:{s:5:"value";s:6:"Cancel";s:2:"id";s:0:"";s:5:"class";s:0:"";s:5:"style";s:0:"";}', 13, 248, 0),
(1954, 'field', 'a:18:{s:4:"name";s:4:"date";s:8:"subtable";s:0:"";s:14:"header_caption";s:4:"Date";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";s:0:"";s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 0, 249, 0),
(1955, 'field', 'a:18:{s:4:"name";s:9:"total_btc";s:8:"subtable";s:0:"";s:14:"header_caption";s:9:"Total BTC";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";s:0:"";s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 1, 249, 0),
(1956, 'field', 'a:18:{s:4:"name";s:14:"total_fiat_usd";s:8:"subtable";s:0:"";s:14:"header_caption";s:8:"T Fiat $";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";s:0:"";s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 2, 249, 0),
(1957, 'field', 'a:18:{s:4:"name";s:12:"btc_per_user";s:8:"subtable";s:0:"";s:14:"header_caption";s:8:"BTC/User";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";s:0:"";s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 3, 249, 0),
(1958, 'field', 'a:18:{s:4:"name";s:15:"open_orders_btc";s:8:"subtable";s:0:"";s:14:"header_caption";s:15:"Open Orders BTC";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";s:0:"";s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 5, 249, 0),
(1959, 'field', 'a:18:{s:4:"name";s:16:"transactions_btc";s:8:"subtable";s:0:"";s:14:"header_caption";s:10:"Trans. BTC";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";s:0:"";s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 6, 249, 0),
(1960, 'field', 'a:18:{s:4:"name";s:24:"avg_transaction_size_btc";s:8:"subtable";s:0:"";s:14:"header_caption";s:14:"AVG Trans. BTC";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";s:0:"";s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 7, 249, 0),
(1961, 'field', 'a:18:{s:4:"name";s:27:"transaction_volume_per_user";s:8:"subtable";s:0:"";s:14:"header_caption";s:15:"Trans./User BTC";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";s:0:"";s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 8, 249, 0);
INSERT INTO `admin_controls_methods` (`id`, `method`, `arguments`, `order`, `control_id`, `p_id`) VALUES
(1962, 'field', 'a:18:{s:4:"name";s:14:"total_fees_btc";s:8:"subtable";s:0:"";s:14:"header_caption";s:8:"Fees USD";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";s:0:"";s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 9, 249, 0),
(1963, 'field', 'a:18:{s:4:"name";s:17:"fees_per_user_btc";s:8:"subtable";s:0:"";s:14:"header_caption";s:13:"Fees/User USD";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";s:0:"";s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 10, 249, 0),
(1964, 'textInput', 'a:13:{s:4:"name";s:12:"usd_per_user";s:7:"caption";s:12:"USD per User";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 4, 248, 0),
(1965, 'field', 'a:18:{s:4:"name";s:12:"usd_per_user";s:8:"subtable";s:0:"";s:14:"header_caption";s:8:"USD/User";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";s:0:"";s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 4, 249, 0),
(1966, 'startArea', 'a:3:{s:6:"legend";s:6:"Status";s:5:"class";s:8:"box_left";s:6:"height";s:0:"";}', 0, 244, 0),
(1967, 'endArea', '', 8, 244, 0),
(1998, 'textInput', 'a:13:{s:4:"name";s:16:"gross_profit_btc";s:7:"caption";s:16:"Gross Profit BTC";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 11, 248, 0),
(1968, 'startArea', 'a:3:{s:6:"legend";s:14:"Escrow Profits";s:5:"class";s:9:"box_right";s:6:"height";s:0:"";}', 9, 244, 0),
(1969, 'endArea', '', 42, 244, 0),
(1970, 'textInput', 'a:13:{s:4:"name";s:10:"btc_escrow";s:7:"caption";s:3:"BTC";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 10, 244, 0),
(1971, 'textInput', 'a:13:{s:4:"name";s:10:"usd_escrow";s:7:"caption";s:3:"USD";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 11, 244, 0),
(1972, 'textInput', 'a:13:{s:4:"name";s:10:"eur_escrow";s:7:"caption";s:3:"EUR";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 12, 244, 0),
(1973, 'textInput', 'a:13:{s:4:"name";s:10:"cny_escrow";s:7:"caption";s:3:"CNY";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 13, 244, 0),
(1974, 'textInput', 'a:13:{s:4:"name";s:10:"gbp_escrow";s:7:"caption";s:3:"GBP";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 14, 244, 0),
(1975, 'textInput', 'a:13:{s:4:"name";s:10:"ars_escrow";s:7:"caption";s:3:"ARS";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 15, 244, 0),
(1976, 'textInput', 'a:13:{s:4:"name";s:10:"jpy_escrow";s:7:"caption";s:3:"JPY";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 18, 244, 0),
(1977, 'textInput', 'a:13:{s:4:"name";s:10:"rub_escrow";s:7:"caption";s:3:"RUB";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 19, 244, 0),
(1978, 'textInput', 'a:13:{s:4:"name";s:10:"mxn_escrow";s:7:"caption";s:3:"MXN";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 20, 244, 0),
(1979, 'textInput', 'a:13:{s:4:"name";s:10:"hkd_escrow";s:7:"caption";s:3:"HKD";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 22, 244, 0),
(1980, 'textInput', 'a:13:{s:4:"name";s:10:"ils_escrow";s:7:"caption";s:3:"ILS";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 23, 244, 0),
(1981, 'textInput', 'a:13:{s:4:"name";s:10:"inr_escrow";s:7:"caption";s:3:"INR";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 24, 244, 0),
(1982, 'textInput', 'a:13:{s:4:"name";s:10:"dkk_escrow";s:7:"caption";s:3:"DKK";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 25, 244, 0),
(1983, 'textInput', 'a:13:{s:4:"name";s:10:"huf_escrow";s:7:"caption";s:3:"HUF";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 26, 244, 0),
(1984, 'textInput', 'a:13:{s:4:"name";s:10:"lvl_escrow";s:7:"caption";s:3:"LVL";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 27, 244, 0),
(1985, 'textInput', 'a:13:{s:4:"name";s:10:"ltl_escrow";s:7:"caption";s:3:"LTL";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 28, 244, 0),
(1986, 'textInput', 'a:13:{s:4:"name";s:10:"nzd_escrow";s:7:"caption";s:3:"NZD";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 29, 244, 0),
(1987, 'textInput', 'a:13:{s:4:"name";s:10:"nok_escrow";s:7:"caption";s:3:"NOK";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 30, 244, 0),
(1988, 'textInput', 'a:13:{s:4:"name";s:10:"pln_escrow";s:7:"caption";s:3:"PLN";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 31, 244, 0),
(1989, 'textInput', 'a:13:{s:4:"name";s:10:"ron_escrow";s:7:"caption";s:3:"RON";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 32, 244, 0),
(1990, 'textInput', 'a:13:{s:4:"name";s:10:"sgd_escrow";s:7:"caption";s:3:"SGD";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 33, 244, 0),
(1991, 'textInput', 'a:13:{s:4:"name";s:10:"zar_escrow";s:7:"caption";s:3:"ZAR";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 34, 244, 0),
(1992, 'textInput', 'a:13:{s:4:"name";s:10:"sek_escrow";s:7:"caption";s:3:"SEK";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 35, 244, 0),
(1993, 'textInput', 'a:13:{s:4:"name";s:10:"thb_escrow";s:7:"caption";s:3:"THB";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 36, 244, 0),
(1994, 'textInput', 'a:13:{s:4:"name";s:10:"try_escrow";s:7:"caption";s:3:"TRY";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 37, 244, 0),
(1995, 'textInput', 'a:13:{s:4:"name";s:10:"czk_escrow";s:7:"caption";s:3:"CZK";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 39, 244, 0),
(1996, 'textInput', 'a:13:{s:4:"name";s:10:"hrk_escrow";s:7:"caption";s:3:"HRK";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 40, 244, 0),
(1997, 'textInput', 'a:13:{s:4:"name";s:10:"bgn_escrow";s:7:"caption";s:3:"BGN";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 41, 244, 0),
(1999, 'field', 'a:18:{s:4:"name";s:16:"gross_profit_btc";s:8:"subtable";s:0:"";s:14:"header_caption";s:16:"Gross Profit USD";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";s:0:"";s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 11, 249, 0),
(2000, 'dateWidget', 'a:19:{s:4:"name";s:4:"date";s:7:"caption";s:4:"Date";s:8:"required";s:0:"";s:4:"time";s:0:"";s:4:"ampm";s:0:"";s:9:"req_start";s:0:"";s:7:"req_end";s:0:"";s:5:"value";s:0:"";s:7:"link_to";s:0:"";s:2:"id";s:0:"";s:5:"class";s:0:"";s:6:"format";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:19:"is_filter_range_end";s:0:"";s:14:"document_ready";s:0:"";s:9:"only_time";s:0:"";s:16:"regular_interval";s:0:"";s:13:"only_interval";s:0:"";}', 0, 250, 0),
(2001, 'textInput', 'a:13:{s:4:"name";s:16:"transactions_btc";s:7:"caption";s:16:"Transactions BTC";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 1, 250, 0),
(2002, 'textInput', 'a:13:{s:4:"name";s:24:"avg_transaction_size_btc";s:7:"caption";s:25:"Avg. Transaction Size BTC";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 2, 250, 0),
(2003, 'textInput', 'a:13:{s:4:"name";s:27:"transaction_volume_per_user";s:7:"caption";s:31:"Transaction Volume per User BTC";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 3, 250, 0),
(2004, 'textInput', 'a:13:{s:4:"name";s:14:"total_fees_btc";s:7:"caption";s:14:"Total Fees BTC";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 4, 250, 0),
(2005, 'textInput', 'a:13:{s:4:"name";s:17:"fees_per_user_btc";s:7:"caption";s:17:"Fees per User BTC";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 5, 250, 0),
(2006, 'textInput', 'a:13:{s:4:"name";s:16:"gross_profit_btc";s:7:"caption";s:16:"Gross Profit BTC";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 6, 250, 0),
(2007, 'submitButton', 'a:6:{s:4:"name";s:4:"Save";s:5:"value";s:4:"Save";s:2:"id";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";}', 7, 250, 0),
(2008, 'cancelButton', 'a:4:{s:5:"value";s:6:"Cancel";s:2:"id";s:0:"";s:5:"class";s:0:"";s:5:"style";s:0:"";}', 8, 250, 0),
(2009, 'field', 'a:18:{s:4:"name";s:4:"date";s:8:"subtable";s:0:"";s:14:"header_caption";s:4:"Date";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";s:0:"";s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 0, 251, 0),
(2010, 'field', 'a:18:{s:4:"name";s:16:"transactions_btc";s:8:"subtable";s:0:"";s:14:"header_caption";s:16:"Total Trans. USD";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";s:0:"";s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 1, 251, 0),
(2011, 'field', 'a:18:{s:4:"name";s:24:"avg_transaction_size_btc";s:8:"subtable";s:0:"";s:14:"header_caption";s:15:"Avg. Trans. USD";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";s:0:"";s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 2, 251, 0),
(2012, 'field', 'a:18:{s:4:"name";s:27:"transaction_volume_per_user";s:8:"subtable";s:0:"";s:14:"header_caption";s:20:"Trans. Vol. per User";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";s:0:"";s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 3, 251, 0),
(2013, 'field', 'a:18:{s:4:"name";s:14:"total_fees_btc";s:8:"subtable";s:0:"";s:14:"header_caption";s:14:"Total Fees USD";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";s:0:"";s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 4, 251, 0),
(2014, 'field', 'a:18:{s:4:"name";s:17:"fees_per_user_btc";s:8:"subtable";s:0:"";s:14:"header_caption";s:17:"Fees per User USD";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";s:0:"";s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 5, 251, 0),
(2015, 'field', 'a:18:{s:4:"name";s:16:"gross_profit_btc";s:8:"subtable";s:0:"";s:14:"header_caption";s:16:"Gross Profit USD";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";s:0:"";s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 6, 251, 0),
(2016, 'checkBox', 'a:9:{s:4:"name";s:9:"no_logins";s:7:"caption";s:14:"No Logins Yet?";s:8:"required";s:0:"";s:2:"id";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:11:"label_class";s:0:"";s:7:"checked";s:0:"";}', 27, 130, 0),
(2017, 'checkBox', 'a:9:{s:4:"name";s:12:"notify_login";s:7:"caption";s:13:"Notify Login?";s:8:"required";s:0:"";s:2:"id";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:11:"label_class";s:0:"";s:7:"checked";s:0:"";}', 25, 130, 0),
(2018, 'checkBox', 'a:9:{s:4:"name";s:11:"deactivated";s:7:"caption";s:12:"Deactivated?";s:8:"required";s:0:"";s:2:"id";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:11:"label_class";s:0:"";s:7:"checked";s:0:"";}', 28, 130, 0),
(2019, 'checkBox', 'a:9:{s:4:"name";s:6:"locked";s:7:"caption";s:10:"Is Locked?";s:8:"required";s:0:"";s:2:"id";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:11:"label_class";s:0:"";s:7:"checked";s:0:"";}', 29, 130, 0),
(2023, 'filterSelect', 'a:10:{s:10:"field_name";s:21:"requests.request_type";s:7:"caption";s:4:"Type";s:13:"options_array";s:0:"";s:8:"subtable";s:13:"request_types";s:15:"subtable_fields";a:1:{s:7:"name_en";s:7:"name_en";}s:5:"class";s:0:"";s:10:"f_id_field";s:0:"";s:10:"depends_on";s:0:"";s:5:"level";s:0:"";s:4:"f_id";s:0:"";}', 1, 233, 0),
(2024, 'filterSelect', 'a:10:{s:10:"field_name";s:23:"requests.request_status";s:7:"caption";s:6:"Status";s:13:"options_array";s:0:"";s:8:"subtable";s:14:"request_status";s:15:"subtable_fields";a:1:{s:7:"name_en";s:7:"name_en";}s:5:"class";s:0:"";s:10:"f_id_field";s:0:"";s:10:"depends_on";s:0:"";s:5:"level";s:0:"";s:4:"f_id";s:0:"";}', 2, 233, 0),
(2025, 'textInput', 'a:13:{s:4:"name";s:10:"btc_before";s:7:"caption";s:12:"BTC Before 1";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 23, 216, 0),
(2026, 'textInput', 'a:13:{s:4:"name";s:11:"btc_before1";s:7:"caption";s:12:"BTC Before 2";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 36, 216, 0),
(2027, 'textInput', 'a:13:{s:4:"name";s:9:"btc_after";s:7:"caption";s:11:"BTC After 1";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 24, 216, 0),
(2028, 'textInput', 'a:13:{s:4:"name";s:10:"btc_after1";s:7:"caption";s:11:"BTC After 2";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 37, 216, 0),
(2029, 'textInput', 'a:13:{s:4:"name";s:11:"fiat_before";s:7:"caption";s:13:"Fiat Before 1";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 25, 216, 0),
(2030, 'textInput', 'a:13:{s:4:"name";s:12:"fiat_before1";s:7:"caption";s:13:"Fiat Before 2";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 38, 216, 0),
(2031, 'textInput', 'a:13:{s:4:"name";s:10:"fiat_after";s:7:"caption";s:12:"Fiat After 1";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 26, 216, 0),
(2032, 'textInput', 'a:13:{s:4:"name";s:11:"fiat_after1";s:7:"caption";s:12:"Fiat After 2";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 39, 216, 0),
(2033, 'dateWidget', 'a:19:{s:4:"name";s:4:"date";s:7:"caption";s:4:"Date";s:8:"required";s:1:"1";s:4:"time";s:1:"1";s:4:"ampm";s:1:"1";s:9:"req_start";s:0:"";s:7:"req_end";s:0:"";s:5:"value";s:0:"";s:7:"link_to";s:0:"";s:2:"id";s:0:"";s:5:"class";s:0:"";s:6:"format";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:19:"is_filter_range_end";s:0:"";s:14:"document_ready";s:0:"";s:9:"only_time";s:0:"";s:16:"regular_interval";s:0:"";s:13:"only_interval";s:0:"";}', 1, 252, 0),
(2034, 'autoComplete', 'a:22:{s:4:"name";s:9:"site_user";s:7:"caption";s:4:"User";s:8:"required";s:0:"";s:5:"value";s:0:"";s:8:"multiple";s:0:"";s:13:"options_array";s:0:"";s:8:"subtable";s:10:"site_users";s:15:"subtable_fields";a:1:{s:4:"user";s:4:"user";}s:13:"subtable_f_id";s:0:"";s:2:"id";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:10:"depends_on";s:0:"";s:10:"depend_url";s:0:"";s:10:"f_id_field";s:0:"";s:17:"list_field_values";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";s:12:"is_tokenizer";s:0:"";s:16:"get_table_fields";s:0:"";s:16:"first_is_default";s:0:"";}', 2, 252, 0),
(2035, 'selectInput', 'a:20:{s:4:"name";s:10:"order_type";s:7:"caption";s:10:"Order Type";s:8:"required";s:0:"";s:5:"value";s:0:"";s:13:"options_array";s:0:"";s:8:"subtable";s:11:"order_types";s:15:"subtable_fields";a:1:{s:7:"name_en";s:7:"name_en";}s:13:"subtable_f_id";s:0:"";s:2:"id";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:10:"f_id_field";s:0:"";s:12:"default_text";s:0:"";s:10:"depends_on";s:0:"";s:20:"function_to_elements";s:0:"";s:16:"first_is_default";s:0:"";s:5:"level";s:0:"";s:11:"concat_char";s:0:"";s:9:"is_catsel";s:0:"";}', 3, 252, 0),
(2036, 'textInput', 'a:13:{s:4:"name";s:3:"btc";s:7:"caption";s:16:"Orig. BTC Amount";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 4, 252, 0),
(2037, 'checkBox', 'a:9:{s:4:"name";s:12:"market_price";s:7:"caption";s:21:"Price at market rate?";s:8:"required";s:0:"";s:2:"id";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:11:"label_class";s:0:"";s:7:"checked";s:0:"";}', 5, 252, 0),
(2038, 'textInput', 'a:13:{s:4:"name";s:9:"btc_price";s:7:"caption";s:9:"BTC Price";s:8:"required";s:1:"1";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 6, 252, 0),
(2039, 'textInput', 'a:13:{s:4:"name";s:4:"fiat";s:7:"caption";s:11:"Fiat Amount";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 7, 252, 0),
(2040, 'selectInput', 'a:20:{s:4:"name";s:8:"currency";s:7:"caption";s:13:"Fiat Currency";s:8:"required";s:0:"";s:5:"value";s:0:"";s:13:"options_array";s:0:"";s:8:"subtable";s:10:"currencies";s:15:"subtable_fields";a:1:{s:8:"currency";s:8:"currency";}s:13:"subtable_f_id";s:0:"";s:2:"id";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:10:"f_id_field";s:0:"";s:12:"default_text";s:0:"";s:10:"depends_on";s:0:"";s:20:"function_to_elements";s:0:"";s:16:"first_is_default";s:0:"";s:5:"level";s:0:"";s:11:"concat_char";s:0:"";s:9:"is_catsel";s:0:"";}', 8, 252, 0),
(2041, 'passiveField', 'a:14:{s:4:"name";s:4:"p_id";s:7:"caption";s:11:"Edited From";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:19:"order-log&id=[p_id]";s:11:"concat_char";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:15:"create_db_field";s:3:"int";s:13:"default_value";s:0:"";s:23:"dont_fill_automatically";s:0:"";}', 10, 252, 0),
(2042, 'passiveField', 'a:14:{s:4:"name";s:2:"id";s:7:"caption";s:2:"ID";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:15:"create_db_field";s:0:"";s:13:"default_value";s:0:"";s:23:"dont_fill_automatically";s:0:"";}', 0, 252, 0),
(2043, 'submitButton', 'a:6:{s:4:"name";s:4:"Save";s:5:"value";s:4:"Save";s:2:"id";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";}', 11, 252, 0),
(2044, 'cancelButton', 'a:4:{s:5:"value";s:6:"Cancel";s:2:"id";s:0:"";s:5:"class";s:0:"";s:5:"style";s:0:"";}', 12, 252, 0),
(2045, 'hiddenInput', 'a:8:{s:4:"name";s:6:"log_id";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:3:"int";s:7:"jscript";s:0:"";s:20:"is_current_timestamp";s:0:"";s:15:"on_every_update";s:0:"";}', 10, 210, 0),
(2046, 'field', 'a:14:{s:4:"name";s:2:"id";s:7:"caption";s:2:"ID";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 0, 253, 0),
(2047, 'field', 'a:14:{s:4:"name";s:4:"date";s:7:"caption";s:4:"Date";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 1, 253, 0),
(2048, 'field', 'a:14:{s:4:"name";s:9:"site_user";s:7:"caption";s:4:"User";s:8:"subtable";s:10:"site_users";s:15:"subtable_fields";a:1:{s:4:"user";s:4:"user";}s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 2, 253, 0),
(2049, 'field', 'a:14:{s:4:"name";s:10:"order_type";s:7:"caption";s:10:"Order Type";s:8:"subtable";s:11:"order_types";s:15:"subtable_fields";a:1:{s:7:"name_en";s:7:"name_en";}s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 3, 253, 0),
(2050, 'field', 'a:14:{s:4:"name";s:3:"btc";s:7:"caption";s:16:"Orig. BTC Amount";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 4, 253, 0),
(2051, 'field', 'a:14:{s:4:"name";s:12:"market_price";s:7:"caption";s:21:"Price at market rate?";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 5, 253, 0),
(2052, 'field', 'a:14:{s:4:"name";s:9:"btc_price";s:7:"caption";s:9:"BTC Price";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 6, 253, 0),
(2053, 'field', 'a:14:{s:4:"name";s:4:"fiat";s:7:"caption";s:11:"Fiat Amount";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 7, 253, 0),
(2054, 'field', 'a:14:{s:4:"name";s:8:"currency";s:7:"caption";s:13:"Fiat Currency";s:8:"subtable";s:10:"currencies";s:15:"subtable_fields";a:1:{s:8:"currency";s:8:"currency";}s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 8, 253, 0),
(2055, 'field', 'a:14:{s:4:"name";s:4:"p_id";s:7:"caption";s:11:"Edited From";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:9:"order-log";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:4:"p_id";}', 10, 253, 0),
(2056, 'cancelButton', 'a:4:{s:5:"value";s:2:"OK";s:2:"id";s:0:"";s:5:"class";s:0:"";s:5:"style";s:0:"";}', 11, 253, 0),
(2057, 'field', 'a:18:{s:4:"name";s:2:"id";s:8:"subtable";s:0:"";s:14:"header_caption";s:2:"ID";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";s:0:"";s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 1, 254, 0),
(2058, 'field', 'a:18:{s:4:"name";s:4:"date";s:8:"subtable";s:0:"";s:14:"header_caption";s:4:"Date";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";s:0:"";s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 2, 254, 0),
(2059, 'field', 'a:18:{s:4:"name";s:10:"order_type";s:8:"subtable";s:11:"order_types";s:14:"header_caption";s:10:"Order Type";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";a:1:{s:7:"name_en";s:7:"name_en";}s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 4, 254, 0),
(2060, 'field', 'a:18:{s:4:"name";s:3:"btc";s:8:"subtable";s:0:"";s:14:"header_caption";s:9:"Orig. BTC";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";s:0:"";s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 5, 254, 0),
(2061, 'field', 'a:18:{s:4:"name";s:9:"btc_price";s:8:"subtable";s:0:"";s:14:"header_caption";s:5:"Price";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";s:0:"";s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 6, 254, 0),
(2062, 'field', 'a:18:{s:4:"name";s:4:"fiat";s:8:"subtable";s:0:"";s:14:"header_caption";s:4:"Fiat";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";s:0:"";s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 7, 254, 0),
(2063, 'field', 'a:18:{s:4:"name";s:8:"currency";s:8:"subtable";s:10:"currencies";s:14:"header_caption";s:8:"Currency";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";a:1:{s:8:"currency";s:8:"currency";}s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 8, 254, 0),
(2064, 'field', 'a:18:{s:4:"name";s:9:"site_user";s:8:"subtable";s:10:"site_users";s:14:"header_caption";s:4:"User";s:6:"filter";s:1:"Y";s:8:"link_url";s:19:"registered-visitors";s:15:"subtable_fields";a:1:{s:4:"user";s:4:"user";}s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:1:"1";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 3, 254, 0),
(2065, 'field', 'a:18:{s:4:"name";s:12:"market_price";s:8:"subtable";s:0:"";s:14:"header_caption";s:13:"Market Price?";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";s:0:"";s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 9, 254, 0),
(2067, 'field', 'a:18:{s:4:"name";s:4:"p_id";s:8:"subtable";s:0:"";s:14:"header_caption";s:11:"Edited From";s:6:"filter";s:1:"Y";s:8:"link_url";s:9:"order-log";s:15:"subtable_fields";s:0:"";s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 11, 254, 0),
(2068, 'passiveField', 'a:14:{s:4:"name";s:7:"log_id1";s:7:"caption";s:7:"Order 2";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:9:"order-log";s:11:"concat_char";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:15:"create_db_field";s:3:"int";s:13:"default_value";s:0:"";s:23:"dont_fill_automatically";s:0:"";}', 40, 216, 0),
(2069, 'passiveField', 'a:14:{s:4:"name";s:6:"log_id";s:7:"caption";s:7:"Order 1";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:9:"order-log";s:11:"concat_char";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:15:"create_db_field";s:3:"int";s:13:"default_value";s:0:"";s:23:"dont_fill_automatically";s:0:"";}', 27, 216, 0),
(2070, 'field', 'a:14:{s:4:"name";s:10:"btc_before";s:7:"caption";s:12:"BTC Before 1";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 22, 217, 0),
(2071, 'field', 'a:14:{s:4:"name";s:11:"btc_before1";s:7:"caption";s:12:"BTC Before 2";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 34, 217, 0),
(2072, 'field', 'a:14:{s:4:"name";s:9:"btc_after";s:7:"caption";s:11:"BTC After 1";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 23, 217, 0),
(2073, 'field', 'a:14:{s:4:"name";s:10:"btc_after1";s:7:"caption";s:11:"BTC After 2";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 35, 217, 0),
(2074, 'field', 'a:14:{s:4:"name";s:11:"fiat_before";s:7:"caption";s:13:"Fiat Before 1";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 24, 217, 0),
(2075, 'field', 'a:14:{s:4:"name";s:12:"fiat_before1";s:7:"caption";s:13:"Fiat Before 2";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 36, 217, 0),
(2076, 'field', 'a:14:{s:4:"name";s:10:"fiat_after";s:7:"caption";s:12:"Fiat After 1";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 25, 217, 0),
(2077, 'field', 'a:14:{s:4:"name";s:11:"fiat_after1";s:7:"caption";s:12:"Fiat After 2";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 37, 217, 0),
(2078, 'field', 'a:14:{s:4:"name";s:6:"log_id";s:7:"caption";s:7:"Order 1";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:9:"order-log";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 26, 217, 0),
(2079, 'field', 'a:14:{s:4:"name";s:7:"log_id1";s:7:"caption";s:7:"Order 2";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:9:"order-log";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 38, 217, 0),
(2080, 'startArea', 'a:3:{s:6:"legend";s:16:"Transaction Info";s:5:"class";s:8:"box_left";s:6:"height";s:0:"";}', 0, 216, 0),
(2081, 'endArea', '', 7, 216, 0),
(2082, 'startArea', 'a:3:{s:6:"legend";s:6:"User 1";s:5:"class";s:8:"box_left";s:6:"height";s:0:"";}', 16, 216, 0),
(2083, 'startArea', 'a:3:{s:6:"legend";s:6:"User 2";s:5:"class";s:9:"box_right";s:6:"height";s:0:"";}', 30, 216, 0),
(2084, 'endArea', '', 29, 216, 0),
(2085, 'endArea', '', 15, 216, 0),
(2086, 'startArea', 'a:3:{s:6:"legend";s:16:"Transaction Info";s:5:"class";s:8:"box_left";s:6:"height";s:0:"";}', 0, 217, 0),
(2087, 'endArea', '', 7, 217, 0),
(2088, 'startArea', 'a:3:{s:6:"legend";s:6:"User 1";s:5:"class";s:8:"box_left";s:6:"height";s:0:"";}', 16, 217, 0),
(2089, 'endArea', '', 28, 217, 0),
(2090, 'startArea', 'a:3:{s:6:"legend";s:6:"User 2";s:5:"class";s:9:"box_right";s:6:"height";s:0:"";}', 29, 217, 0),
(2091, 'endArea', '', 40, 217, 0),
(2097, 'filterAutocomplete', 'a:6:{s:10:"field_name";s:19:"order_log.site_user";s:7:"caption";s:4:"User";s:13:"options_array";s:0:"";s:8:"subtable";s:10:"site_users";s:15:"subtable_fields";a:2:{s:10:"first_name";s:10:"first_name";s:9:"last_name";s:9:"last_name";}s:5:"class";s:0:"";}', 0, 254, 0),
(2095, 'filterAutocomplete', 'a:6:{s:10:"field_name";s:46:"transactions.site_user1,transactions.site_user";s:7:"caption";s:4:"User";s:13:"options_array";s:0:"";s:8:"subtable";s:10:"site_users";s:15:"subtable_fields";a:3:{s:4:"user";s:4:"user";s:10:"first_name";s:10:"first_name";s:9:"last_name";s:9:"last_name";}s:5:"class";s:0:"";}', 0, 218, 0),
(2098, 'textInput', 'a:13:{s:4:"name";s:3:"cop";s:7:"caption";s:11:"COP Balance";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 40, 130, 0),
(2099, 'textInput', 'a:13:{s:4:"name";s:3:"cad";s:7:"caption";s:11:"CAD Balance";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 41, 130, 0),
(2100, 'textInput', 'a:13:{s:4:"name";s:3:"mur";s:7:"caption";s:11:"MUR Balance";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 53, 130, 0),
(2101, 'textInput', 'a:13:{s:4:"name";s:3:"twd";s:7:"caption";s:11:"TWD Balance";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 63, 130, 0),
(2102, 'field', 'a:14:{s:4:"name";s:3:"cad";s:7:"caption";s:11:"CAD Balance";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 18, 131, 0),
(2103, 'field', 'a:14:{s:4:"name";s:3:"cop";s:7:"caption";s:11:"COP Balance";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 19, 131, 0),
(2104, 'field', 'a:14:{s:4:"name";s:3:"mur";s:7:"caption";s:11:"MUR Balance";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 31, 131, 0),
(2105, 'field', 'a:14:{s:4:"name";s:3:"twd";s:7:"caption";s:11:"TWD Balance";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 41, 131, 0),
(2106, 'textInput', 'a:13:{s:4:"name";s:10:"cad_escrow";s:7:"caption";s:3:"CAD";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 16, 244, 0),
(2107, 'textInput', 'a:13:{s:4:"name";s:10:"cop_escrow";s:7:"caption";s:3:"COP";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 17, 244, 0),
(2108, 'textInput', 'a:13:{s:4:"name";s:10:"mur_escrow";s:7:"caption";s:3:"MUR";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 21, 244, 0);
INSERT INTO `admin_controls_methods` (`id`, `method`, `arguments`, `order`, `control_id`, `p_id`) VALUES
(2109, 'textInput', 'a:13:{s:4:"name";s:10:"twd_escrow";s:7:"caption";s:3:"TWD";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 38, 244, 0),
(2110, 'textInput', 'a:13:{s:4:"name";s:9:"fee_level";s:7:"caption";s:19:"Fee Level at Trans.";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 28, 216, 0),
(2111, 'textInput', 'a:13:{s:4:"name";s:10:"fee_level1";s:7:"caption";s:19:"Fee Level at Trans.";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 41, 216, 0),
(2112, 'field', 'a:14:{s:4:"name";s:9:"fee_level";s:7:"caption";s:19:"Fee Level at Trans.";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 27, 217, 0),
(2113, 'field', 'a:14:{s:4:"name";s:10:"fee_level1";s:7:"caption";s:19:"Fee Level at Trans.";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 39, 217, 0),
(2114, 'checkBox', 'a:9:{s:4:"name";s:4:"done";s:7:"caption";s:5:"Done?";s:8:"required";s:0:"";s:2:"id";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:11:"label_class";s:0:"";s:7:"checked";s:0:"";}', 11, 225, 0),
(2115, 'field', 'a:14:{s:4:"name";s:4:"done";s:7:"caption";s:5:"Done?";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 9, 232, 0),
(2116, 'field', 'a:18:{s:4:"name";s:4:"done";s:8:"subtable";s:0:"";s:14:"header_caption";s:5:"Done?";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";s:0:"";s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 14, 233, 0),
(2118, 'filterSelect', 'a:10:{s:10:"field_name";s:17:"requests.currency";s:7:"caption";s:8:"Currency";s:13:"options_array";s:0:"";s:8:"subtable";s:10:"currencies";s:15:"subtable_fields";a:1:{s:8:"currency";s:8:"currency";}s:5:"class";s:0:"";s:10:"f_id_field";s:0:"";s:10:"depends_on";s:0:"";s:5:"level";s:0:"";s:4:"f_id";s:0:"";}', 4, 233, 0),
(2119, 'field', 'a:18:{s:4:"name";s:14:"verified_authy";s:8:"subtable";s:0:"";s:14:"header_caption";s:6:"Authy?";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";s:0:"";s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 6, 132, 0),
(2120, 'textInput', 'a:13:{s:4:"name";s:8:"currency";s:7:"caption";s:8:"Currency";s:8:"required";s:1:"1";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 0, 256, 0),
(2121, 'textInput', 'a:13:{s:4:"name";s:7:"usd_bid";s:7:"caption";s:9:"Bid (USD)";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 1, 256, 0),
(2122, 'textInput', 'a:13:{s:4:"name";s:14:"account_number";s:7:"caption";s:16:"Escrow Account #";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:3:"int";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 3, 256, 0),
(2123, 'textInput', 'a:13:{s:4:"name";s:12:"account_name";s:7:"caption";s:19:"Escrow Account Name";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 4, 256, 0),
(2124, 'checkBox', 'a:9:{s:4:"name";s:9:"is_active";s:7:"caption";s:7:"Active?";s:8:"required";s:0:"";s:2:"id";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:11:"label_class";s:0:"";s:7:"checked";s:0:"";}', 6, 256, 0),
(2125, 'submitButton', 'a:6:{s:4:"name";s:7:"Guardar";s:5:"value";s:7:"Guardar";s:2:"id";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";}', 7, 256, 0),
(2126, 'cancelButton', 'a:4:{s:5:"value";s:6:"Cancel";s:2:"id";s:0:"";s:5:"class";s:0:"";s:5:"style";s:0:"";}', 8, 256, 0),
(2128, 'field', 'a:18:{s:4:"name";s:2:"id";s:8:"subtable";s:0:"";s:14:"header_caption";s:2:"ID";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";s:0:"";s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 0, 257, 0),
(2129, 'field', 'a:18:{s:4:"name";s:8:"currency";s:8:"subtable";s:0:"";s:14:"header_caption";s:8:"Currency";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";s:0:"";s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 1, 257, 0),
(2130, 'field', 'a:18:{s:4:"name";s:14:"account_number";s:8:"subtable";s:0:"";s:14:"header_caption";s:11:"Acc. Number";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";s:0:"";s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 2, 257, 0),
(2131, 'field', 'a:18:{s:4:"name";s:12:"account_name";s:8:"subtable";s:0:"";s:14:"header_caption";s:9:"Acc. Name";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";s:0:"";s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 3, 257, 0),
(2132, 'field', 'a:18:{s:4:"name";s:9:"fa_symbol";s:8:"subtable";s:0:"";s:14:"header_caption";s:9:"FA Symbol";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";s:0:"";s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 4, 257, 0),
(2133, 'textInput', 'a:13:{s:4:"name";s:9:"fa_symbol";s:7:"caption";s:6:"Symbol";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 5, 256, 0),
(2134, 'textInput', 'a:13:{s:4:"name";s:15:"google_2fa_code";s:7:"caption";s:15:"Google 2FA Code";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 12, 130, 0),
(2135, 'checkBox', 'a:9:{s:4:"name";s:15:"verified_google";s:7:"caption";s:20:"Verified Google 2FA?";s:8:"required";s:0:"";s:2:"id";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:11:"label_class";s:0:"";s:7:"checked";s:0:"";}', 15, 130, 0),
(2136, 'textInput', 'a:13:{s:4:"name";s:9:"last_lang";s:7:"caption";s:8:"Language";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 9, 130, 0),
(2137, 'field', 'a:14:{s:4:"name";s:9:"last_lang";s:7:"caption";s:8:"Language";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 7, 131, 0),
(2138, 'textInput', 'a:13:{s:4:"name";s:7:"name_en";s:7:"caption";s:9:"Name (EN)";s:8:"required";s:1:"1";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 0, 258, 0),
(2139, 'submitButton', 'a:6:{s:4:"name";s:4:"Save";s:5:"value";s:4:"Save";s:2:"id";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";}', 3, 258, 0),
(2140, 'cancelButton', 'a:4:{s:5:"value";s:6:"Cancel";s:2:"id";s:0:"";s:5:"class";s:0:"";s:5:"style";s:0:"";}', 2, 258, 0),
(2143, 'addTable', 'a:8:{s:5:"table";s:15:"history_actions";s:12:"table_fields";a:1:{s:7:"name_en";s:7:"name_en";}s:3:"url";s:0:"";s:6:"parent";s:0:"";s:5:"class";s:0:"";s:14:"target_elem_id";s:8:"edit_box";s:10:"url_is_tab";s:0:"";s:15:"accept_children";s:0:"";}', 0, 260, 0),
(2142, 'textInput', 'a:13:{s:4:"name";s:7:"name_es";s:7:"caption";s:9:"Name (ES)";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 1, 258, 0),
(2144, 'dateWidget', 'a:19:{s:4:"name";s:4:"date";s:7:"caption";s:4:"Date";s:8:"required";s:0:"";s:4:"time";s:1:"1";s:4:"ampm";s:1:"1";s:9:"req_start";s:0:"";s:7:"req_end";s:0:"";s:5:"value";s:0:"";s:7:"link_to";s:0:"";s:2:"id";s:0:"";s:5:"class";s:0:"";s:6:"format";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:19:"is_filter_range_end";s:0:"";s:14:"document_ready";s:0:"";s:9:"only_time";s:0:"";s:16:"regular_interval";s:0:"";s:13:"only_interval";s:0:"";}', 1, 261, 0),
(2145, 'selectInput', 'a:20:{s:4:"name";s:14:"history_action";s:7:"caption";s:6:"Action";s:8:"required";s:0:"";s:5:"value";s:0:"";s:13:"options_array";s:0:"";s:8:"subtable";s:15:"history_actions";s:15:"subtable_fields";a:1:{s:7:"name_en";s:7:"name_en";}s:13:"subtable_f_id";s:0:"";s:2:"id";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:10:"f_id_field";s:0:"";s:12:"default_text";s:0:"";s:10:"depends_on";s:0:"";s:20:"function_to_elements";s:0:"";s:16:"first_is_default";s:0:"";s:5:"level";s:0:"";s:11:"concat_char";s:0:"";s:9:"is_catsel";s:0:"";}', 3, 261, 0),
(2146, 'textInput', 'a:13:{s:4:"name";s:2:"ip";s:7:"caption";s:10:"IP Address";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 2, 261, 0),
(2147, 'passiveField', 'a:14:{s:4:"name";s:8:"order_id";s:7:"caption";s:8:"Order ID";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:9:"order-log";s:11:"concat_char";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:15:"create_db_field";s:3:"int";s:13:"default_value";s:0:"";s:23:"dont_fill_automatically";s:0:"";}', 9, 261, 0),
(2148, 'textInput', 'a:13:{s:4:"name";s:15:"bitcoin_address";s:7:"caption";s:15:"Bitcoin Address";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 4, 261, 0),
(2149, 'passiveField', 'a:14:{s:4:"name";s:9:"order_btc";s:7:"caption";s:9:"Order BTC";s:8:"subtable";s:9:"order_log";s:15:"subtable_fields";a:1:{s:3:"btc";s:3:"btc";}s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:10:"f_id_field";s:29:"history.order_id,order_log.id";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:15:"create_db_field";s:0:"";s:13:"default_value";s:0:"";s:23:"dont_fill_automatically";s:0:"";}', 10, 261, 0),
(2150, 'passiveField', 'a:14:{s:4:"name";s:15:"order_btc_price";s:7:"caption";s:15:"Order BTC Price";s:8:"subtable";s:9:"order_log";s:15:"subtable_fields";a:1:{s:9:"btc_price";s:9:"btc_price";}s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:10:"f_id_field";s:29:"history.order_id,order_log.id";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:15:"create_db_field";s:0:"";s:13:"default_value";s:0:"";s:23:"dont_fill_automatically";s:0:"";}', 11, 261, 0),
(2151, 'passiveField', 'a:14:{s:4:"name";s:14:"order_currency";s:7:"caption";s:14:"Order Currency";s:8:"subtable";s:10:"currencies";s:15:"subtable_fields";a:1:{s:8:"currency";s:8:"currency";}s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:10:"f_id_field";s:62:"history.order_id,order_log.id,order_log.currency,currencies.id";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:15:"create_db_field";s:0:"";s:13:"default_value";s:0:"";s:23:"dont_fill_automatically";s:0:"";}', 12, 261, 0),
(2152, 'submitButton', 'a:6:{s:4:"name";s:4:"Save";s:5:"value";s:4:"Save";s:2:"id";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";}', 13, 261, 0),
(2153, 'cancelButton', 'a:4:{s:5:"value";s:6:"Cancel";s:2:"id";s:0:"";s:5:"class";s:0:"";s:5:"style";s:0:"";}', 14, 261, 0),
(2154, 'field', 'a:14:{s:4:"name";s:4:"date";s:7:"caption";s:4:"Date";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 0, 262, 0),
(2155, 'field', 'a:14:{s:4:"name";s:2:"ip";s:7:"caption";s:10:"IP Address";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 2, 262, 0),
(2156, 'field', 'a:14:{s:4:"name";s:15:"bitcoin_address";s:7:"caption";s:15:"Bitcoin Address";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 4, 262, 0),
(2157, 'field', 'a:14:{s:4:"name";s:14:"history_action";s:7:"caption";s:6:"Action";s:8:"subtable";s:15:"history_actions";s:15:"subtable_fields";a:1:{s:7:"name_en";s:7:"name_en";}s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 3, 262, 0),
(2158, 'field', 'a:14:{s:4:"name";s:8:"order_id";s:7:"caption";s:8:"Order ID";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:9:"order-log";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 9, 262, 0),
(2159, 'field', 'a:14:{s:4:"name";s:9:"order_btc";s:7:"caption";s:9:"Order BTC";s:8:"subtable";s:9:"order_log";s:15:"subtable_fields";a:1:{s:3:"btc";s:3:"btc";}s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:29:"history.order_id,order_log.id";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 10, 262, 0),
(2160, 'field', 'a:14:{s:4:"name";s:15:"order_btc_price";s:7:"caption";s:15:"Order BTC Price";s:8:"subtable";s:9:"order_log";s:15:"subtable_fields";a:2:{s:3:"btc";s:3:"btc";s:9:"btc_price";s:9:"btc_price";}s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:29:"history.order_id,order_log.id";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 11, 262, 0),
(2161, 'field', 'a:14:{s:4:"name";s:14:"order_currency";s:7:"caption";s:14:"Order Currency";s:8:"subtable";s:10:"currencies";s:15:"subtable_fields";a:1:{s:8:"currency";s:8:"currency";}s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:62:"history.order_id,order_log.id,order_log.currency,currencies.id";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 12, 262, 0),
(2162, 'cancelButton', 'a:4:{s:5:"value";s:2:"OK";s:2:"id";s:0:"";s:5:"class";s:0:"";s:5:"style";s:0:"";}', 13, 262, 0),
(2163, 'passiveField', 'a:14:{s:4:"name";s:10:"request_id";s:7:"caption";s:10:"Request ID";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:8:"requests";s:11:"concat_char";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:1:"1";s:16:"limit_is_curdate";s:0:"";s:15:"create_db_field";s:3:"int";s:13:"default_value";s:0:"";s:23:"dont_fill_automatically";s:0:"";}', 5, 261, 0),
(2164, 'passiveField', 'a:14:{s:4:"name";s:14:"request_amount";s:7:"caption";s:14:"Request Amount";s:8:"subtable";s:8:"requests";s:15:"subtable_fields";a:1:{s:6:"amount";s:6:"amount";}s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:10:"f_id_field";s:30:"history.request_id,requests.id";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:15:"create_db_field";s:0:"";s:13:"default_value";s:0:"";s:23:"dont_fill_automatically";s:0:"";}', 6, 261, 0),
(2165, 'passiveField', 'a:14:{s:4:"name";s:16:"request_currency";s:7:"caption";s:16:"Request Currency";s:8:"subtable";s:10:"currencies";s:15:"subtable_fields";a:1:{s:8:"currency";s:8:"currency";}s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:10:"f_id_field";s:62:"history.request_id,requests.id,requests.currency,currencies.id";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:15:"create_db_field";s:0:"";s:13:"default_value";s:0:"";s:23:"dont_fill_automatically";s:0:"";}', 7, 261, 0),
(2166, 'passiveField', 'a:14:{s:4:"name";s:15:"request_account";s:7:"caption";s:20:"Request Bank Account";s:8:"subtable";s:8:"requests";s:15:"subtable_fields";a:1:{s:7:"account";s:7:"account";}s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:10:"f_id_field";s:30:"history.request_id,requests.id";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:15:"create_db_field";s:0:"";s:13:"default_value";s:0:"";s:23:"dont_fill_automatically";s:0:"";}', 8, 261, 0),
(2167, 'field', 'a:14:{s:4:"name";s:10:"request_id";s:7:"caption";s:10:"Request ID";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:8:"requests";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:1:"1";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 5, 262, 0),
(2168, 'field', 'a:14:{s:4:"name";s:14:"request_amount";s:7:"caption";s:14:"Request Amount";s:8:"subtable";s:8:"requests";s:15:"subtable_fields";a:1:{s:6:"amount";s:6:"amount";}s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:30:"history.request_id,requests.id";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 6, 262, 0),
(2169, 'field', 'a:14:{s:4:"name";s:15:"request_account";s:7:"caption";s:20:"Request Bank Account";s:8:"subtable";s:8:"requests";s:15:"subtable_fields";a:1:{s:7:"account";s:7:"account";}s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:30:"history.request_id,requests.id";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 7, 262, 0),
(2170, 'field', 'a:14:{s:4:"name";s:16:"request_currency";s:7:"caption";s:16:"Request Currency";s:8:"subtable";s:10:"currencies";s:15:"subtable_fields";a:1:{s:8:"currency";s:8:"currency";}s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:62:"history.request_id,requests.id,requests.currency,currencies.id";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 8, 262, 0),
(2171, 'field', 'a:18:{s:4:"name";s:4:"date";s:8:"subtable";s:0:"";s:14:"header_caption";s:4:"Date";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";s:0:"";s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 69, 263, 0),
(2172, 'field', 'a:18:{s:4:"name";s:2:"ip";s:8:"subtable";s:0:"";s:14:"header_caption";s:2:"IP";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";s:0:"";s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 70, 263, 0),
(2173, 'autoComplete', 'a:22:{s:4:"name";s:9:"site_user";s:7:"caption";s:4:"User";s:8:"required";s:0:"";s:5:"value";s:0:"";s:8:"multiple";s:0:"";s:13:"options_array";s:0:"";s:8:"subtable";s:10:"site_users";s:15:"subtable_fields";a:2:{s:10:"first_name";s:10:"first_name";s:9:"last_name";s:9:"last_name";}s:13:"subtable_f_id";s:0:"";s:2:"id";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:10:"depends_on";s:0:"";s:10:"depend_url";s:0:"";s:10:"f_id_field";s:0:"";s:17:"list_field_values";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";s:12:"is_tokenizer";s:0:"";s:16:"get_table_fields";s:0:"";s:16:"first_is_default";s:0:"";}', 0, 261, 0),
(2174, 'field', 'a:14:{s:4:"name";s:9:"site_user";s:7:"caption";s:4:"User";s:8:"subtable";s:10:"site_users";s:15:"subtable_fields";a:3:{s:4:"user";s:4:"user";s:10:"first_name";s:10:"first_name";s:9:"last_name";s:9:"last_name";}s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 1, 262, 0),
(2175, 'field', 'a:18:{s:4:"name";s:9:"site_user";s:8:"subtable";s:10:"site_users";s:14:"header_caption";s:4:"User";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";a:3:{s:4:"user";s:4:"user";s:10:"first_name";s:10:"first_name";s:9:"last_name";s:9:"last_name";}s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 1, 263, 0),
(2176, 'field', 'a:18:{s:4:"name";s:14:"history_action";s:8:"subtable";s:15:"history_actions";s:14:"header_caption";s:6:"Action";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";a:1:{s:7:"name_en";s:7:"name_en";}s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 71, 263, 0),
(2177, 'field', 'a:18:{s:4:"name";s:15:"bitcoin_address";s:8:"subtable";s:0:"";s:14:"header_caption";s:9:"BTC Addr.";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";s:0:"";s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 72, 263, 0),
(2178, 'field', 'a:18:{s:4:"name";s:10:"request_id";s:8:"subtable";s:0:"";s:14:"header_caption";s:7:"Req. ID";s:6:"filter";s:1:"Y";s:8:"link_url";s:8:"requests";s:15:"subtable_fields";s:0:"";s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:1:"1";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 73, 263, 0),
(2179, 'field', 'a:18:{s:4:"name";s:8:"order_id";s:8:"subtable";s:0:"";s:14:"header_caption";s:8:"Order ID";s:6:"filter";s:1:"Y";s:8:"link_url";s:9:"order-log";s:15:"subtable_fields";s:0:"";s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 77, 263, 0),
(2180, 'field', 'a:18:{s:4:"name";s:14:"request_amount";s:8:"subtable";s:8:"requests";s:14:"header_caption";s:11:"Req. Amount";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";a:1:{s:6:"amount";s:6:"amount";}s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:30:"history.request_id,requests.id";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 74, 263, 0),
(2181, 'field', 'a:18:{s:4:"name";s:15:"request_account";s:8:"subtable";s:8:"requests";s:14:"header_caption";s:9:"Bank Acc.";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";a:1:{s:7:"account";s:7:"account";}s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:30:"history.request_id,requests.id";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 76, 263, 0),
(2182, 'field', 'a:18:{s:4:"name";s:16:"request_currency";s:8:"subtable";s:10:"currencies";s:14:"header_caption";s:10:"Req. Curr.";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";a:1:{s:8:"currency";s:8:"currency";}s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:62:"history.request_id,requests.id,requests.currency,currencies.id";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 75, 263, 0),
(2183, 'field', 'a:18:{s:4:"name";s:9:"order_btc";s:8:"subtable";s:9:"order_log";s:14:"header_caption";s:8:"Ord. BTC";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";a:1:{s:3:"btc";s:3:"btc";}s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:29:"history.order_id,order_log.id";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 78, 263, 0),
(2184, 'field', 'a:18:{s:4:"name";s:14:"order_currency";s:8:"subtable";s:10:"currencies";s:14:"header_caption";s:10:"Ord. Curr.";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";a:1:{s:8:"currency";s:8:"currency";}s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:62:"history.order_id,order_log.id,order_log.currency,currencies.id";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 80, 263, 0),
(2185, 'field', 'a:18:{s:4:"name";s:11:"order_price";s:8:"subtable";s:9:"order_log";s:14:"header_caption";s:14:"Ord. BTC Price";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";a:1:{s:9:"btc_price";s:9:"btc_price";}s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:29:"history.order_id,order_log.id";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 79, 263, 0),
(2186, 'filterAutocomplete', 'a:6:{s:10:"field_name";s:17:"history.site_user";s:7:"caption";s:4:"User";s:13:"options_array";s:0:"";s:8:"subtable";s:10:"site_users";s:15:"subtable_fields";a:3:{s:4:"user";s:4:"user";s:10:"first_name";s:10:"first_name";s:9:"last_name";s:9:"last_name";}s:5:"class";s:0:"";}', 0, 263, 0),
(2187, 'makeTab', 'a:7:{s:4:"name";s:7:"History";s:3:"url";s:7:"history";s:9:"variables";s:0:"";s:10:"identifier";s:0:"";s:6:"is_tab";s:0:"";s:14:"inset_id_field";s:9:"site_user";s:8:"selected";s:0:"";}', 68, 264, 0),
(2188, 'makeTab', 'a:7:{s:4:"name";s:7:"History";s:3:"url";s:7:"history";s:9:"variables";s:0:"";s:10:"identifier";s:0:"";s:6:"is_tab";s:0:"";s:14:"inset_id_field";s:9:"site_user";s:8:"selected";s:0:"";}', 0, 265, 0),
(2189, 'textInput', 'a:13:{s:4:"name";s:9:"crypto_id";s:7:"caption";s:9:"Crypto ID";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:3:"int";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 10, 225, 0),
(2190, 'textInput', 'a:13:{s:4:"name";s:10:"stop_price";s:7:"caption";s:10:"Stop Price";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 9, 210, 0),
(2191, 'field', 'a:14:{s:4:"name";s:10:"stop_price";s:7:"caption";s:10:"Stop Price";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 9, 214, 0),
(2192, 'field', 'a:18:{s:4:"name";s:10:"stop_price";s:8:"subtable";s:0:"";s:14:"header_caption";s:4:"Stop";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";s:0:"";s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 9, 215, 0),
(2193, 'textInput', 'a:13:{s:4:"name";s:10:"stop_price";s:7:"caption";s:10:"Stop Price";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 9, 252, 0),
(2194, 'field', 'a:14:{s:4:"name";s:10:"stop_price";s:7:"caption";s:10:"Stop Price";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 9, 253, 0),
(2195, 'field', 'a:18:{s:4:"name";s:10:"stop_price";s:8:"subtable";s:0:"";s:14:"header_caption";s:4:"Stop";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";s:0:"";s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 10, 254, 0),
(2198, 'selectInput', 'a:20:{s:4:"name";s:9:"currency1";s:7:"caption";s:15:"Fiat Currency 2";s:8:"required";s:0:"";s:5:"value";s:0:"";s:13:"options_array";s:0:"";s:8:"subtable";s:10:"currencies";s:15:"subtable_fields";a:1:{s:8:"currency";s:8:"currency";}s:13:"subtable_f_id";s:0:"";s:2:"id";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:10:"f_id_field";s:0:"";s:12:"default_text";s:0:"";s:10:"depends_on";s:0:"";s:20:"function_to_elements";s:0:"";s:16:"first_is_default";s:0:"";s:5:"level";s:0:"";s:11:"concat_char";s:0:"";s:9:"is_catsel";s:0:"";}', 33, 216, 0),
(2200, 'field', 'a:14:{s:4:"name";s:9:"currency1";s:7:"caption";s:15:"Fiat Currency 2";s:8:"subtable";s:10:"currencies";s:15:"subtable_fields";a:1:{s:8:"currency";s:8:"currency";}s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 32, 217, 0),
(2201, 'textInput', 'a:13:{s:4:"name";s:6:"amount";s:7:"caption";s:17:"Amount To Convert";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 3, 266, 0),
(2202, 'selectInput', 'a:20:{s:4:"name";s:8:"currency";s:7:"caption";s:13:"From Currency";s:8:"required";s:0:"";s:5:"value";s:0:"";s:13:"options_array";s:0:"";s:8:"subtable";s:10:"currencies";s:15:"subtable_fields";a:1:{s:8:"currency";s:8:"currency";}s:13:"subtable_f_id";s:0:"";s:2:"id";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:10:"f_id_field";s:0:"";s:12:"default_text";s:0:"";s:10:"depends_on";s:0:"";s:20:"function_to_elements";s:0:"";s:16:"first_is_default";s:0:"";s:5:"level";s:0:"";s:11:"concat_char";s:0:"";s:9:"is_catsel";s:0:"";}', 4, 266, 0),
(2204, 'selectInput', 'a:20:{s:4:"name";s:9:"currency1";s:7:"caption";s:11:"To Currency";s:8:"required";s:0:"";s:5:"value";s:0:"";s:13:"options_array";s:0:"";s:8:"subtable";s:10:"currencies";s:15:"subtable_fields";a:1:{s:8:"currency";s:8:"currency";}s:13:"subtable_f_id";s:0:"";s:2:"id";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:10:"f_id_field";s:0:"";s:12:"default_text";s:0:"";s:10:"depends_on";s:0:"";s:20:"function_to_elements";s:0:"";s:16:"first_is_default";s:0:"";s:5:"level";s:0:"";s:11:"concat_char";s:0:"";s:9:"is_catsel";s:0:"";}', 5, 266, 0),
(2207, 'dateWidget', 'a:19:{s:4:"name";s:4:"date";s:7:"caption";s:4:"Date";s:8:"required";s:0:"";s:4:"time";s:1:"1";s:4:"ampm";s:1:"1";s:9:"req_start";s:0:"";s:7:"req_end";s:0:"";s:5:"value";s:0:"";s:7:"link_to";s:0:"";s:2:"id";s:0:"";s:5:"class";s:0:"";s:6:"format";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:19:"is_filter_range_end";s:0:"";s:14:"document_ready";s:0:"";s:9:"only_time";s:0:"";s:16:"regular_interval";s:0:"";s:13:"only_interval";s:0:"";}', 0, 266, 0),
(2205, 'submitButton', 'a:6:{s:4:"name";s:4:"Save";s:5:"value";s:4:"Save";s:2:"id";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";}', 9, 266, 0),
(2206, 'cancelButton', 'a:4:{s:5:"value";s:6:"Cancel";s:2:"id";s:0:"";s:5:"class";s:0:"";s:5:"style";s:0:"";}', 10, 266, 0),
(2208, 'field', 'a:18:{s:4:"name";s:4:"date";s:8:"subtable";s:0:"";s:14:"header_caption";s:4:"Date";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";s:0:"";s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 2, 267, 0),
(2209, 'field', 'a:18:{s:4:"name";s:6:"amount";s:8:"subtable";s:0:"";s:14:"header_caption";s:6:"Amount";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";s:0:"";s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 3, 267, 0),
(2210, 'field', 'a:18:{s:4:"name";s:8:"currency";s:8:"subtable";s:10:"currencies";s:14:"header_caption";s:13:"From Currency";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";a:1:{s:8:"currency";s:8:"currency";}s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 4, 267, 0),
(2211, 'field', 'a:18:{s:4:"name";s:9:"currency1";s:8:"subtable";s:10:"currencies";s:14:"header_caption";s:11:"To Currency";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";a:1:{s:8:"currency";s:8:"currency";}s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 5, 267, 0),
(2214, 'field', 'a:18:{s:4:"name";s:9:"is_active";s:8:"subtable";s:0:"";s:14:"header_caption";s:4:"Done";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";s:0:"";s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 8, 267, 0),
(2213, 'checkBox', 'a:9:{s:4:"name";s:9:"is_active";s:7:"caption";s:5:"Done?";s:8:"required";s:0:"";s:2:"id";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:11:"label_class";s:0:"";s:7:"checked";s:0:"";}', 8, 266, 0),
(2215, 'filterDateStart', 'a:9:{s:10:"field_name";s:16:"conversions.date";s:7:"caption";s:10:"Start Date";s:5:"value";s:0:"";s:4:"time";s:0:"";s:4:"ampm";s:0:"";s:9:"req_start";s:0:"";s:7:"req_end";s:0:"";s:7:"link_to";s:0:"";s:6:"format";s:0:"";}', 0, 267, 0),
(2216, 'field', 'a:18:{s:4:"name";s:9:"currency1";s:8:"subtable";s:10:"currencies";s:14:"header_caption";s:10:"Currency 2";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";a:1:{s:8:"currency";s:8:"currency";}s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 8, 218, 0),
(2217, 'textInput', 'a:13:{s:4:"name";s:15:"amount_received";s:7:"caption";s:15:"Amount Received";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 7, 266, 0),
(2218, 'field', 'a:18:{s:4:"name";s:13:"amount_needed";s:8:"subtable";s:0:"";s:14:"header_caption";s:12:"Amnt. Needed";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";s:0:"";s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 6, 267, 0),
(2219, 'textInput', 'a:13:{s:4:"name";s:14:"conversion_fee";s:7:"caption";s:30:"Conversion Fee ( in Currency1)";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 22, 216, 0),
(2252, 'checkBox', 'a:9:{s:4:"name";s:10:"conversion";s:7:"caption";s:11:"Conversion?";s:8:"required";s:0:"";s:2:"id";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:11:"label_class";s:0:"";s:7:"checked";s:0:"";}', 9, 216, 0),
(2253, 'field', 'a:14:{s:4:"name";s:10:"conversion";s:7:"caption";s:10:"Conversion";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 9, 217, 0),
(2222, 'textInput', 'a:13:{s:4:"name";s:14:"orig_btc_price";s:7:"caption";s:28:"Original BTC Price (Curr. 2)";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 5, 216, 0),
(2225, 'textInput', 'a:13:{s:4:"name";s:13:"amount_needed";s:7:"caption";s:13:"Amount Needed";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 6, 266, 0),
(2226, 'field', 'a:18:{s:4:"name";s:15:"amount_received";s:8:"subtable";s:0:"";s:14:"header_caption";s:14:"Amnt. Received";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";s:0:"";s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 7, 267, 0),
(2227, 'aggregate', 'a:7:{s:4:"name";s:9:"comission";s:7:"formula";s:93:"IF(conversions.amount_received > 0,conversions.amount_received - conversions.amount_needed,0)";s:14:"header_caption";s:10:"Commission";s:19:"cumulative_function";s:0:"";s:10:"run_in_sql";s:1:"1";s:9:"join_path";s:0:"";s:6:"filter";s:0:"";}', 9, 267, 0),
(2230, 'field', 'a:14:{s:4:"name";s:14:"orig_btc_price";s:7:"caption";s:28:"Original BTC Price (Curr. 2)";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 5, 217, 0),
(2231, 'field', 'a:14:{s:4:"name";s:14:"conversion_fee";s:7:"caption";s:24:"Conversion Fee (Curr. 1)";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 21, 217, 0),
(2232, 'textInput', 'a:13:{s:4:"name";s:7:"usd_ask";s:7:"caption";s:9:"Ask (USD)";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 2, 256, 0),
(2233, 'startArea', 'a:3:{s:6:"legend";s:19:"Currency Conversion";s:5:"class";s:9:"box_right";s:6:"height";s:0:"";}', 8, 216, 0),
(2234, 'endArea', '', 42, 216, 0),
(2235, 'textInput', 'a:13:{s:4:"name";s:14:"convert_amount";s:7:"caption";s:17:"Amount to Convert";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 10, 216, 0),
(2236, 'textInput', 'a:13:{s:4:"name";s:18:"convert_rate_given";s:7:"caption";s:25:"Conversion rate given (%)";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 11, 216, 0),
(2237, 'textInput', 'a:13:{s:4:"name";s:19:"convert_system_rate";s:7:"caption";s:29:"System Rate @ Transaction (%)";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 12, 216, 0),
(2239, 'selectInput', 'a:20:{s:4:"name";s:21:"convert_from_currency";s:7:"caption";s:13:"From Currency";s:8:"required";s:0:"";s:5:"value";s:0:"";s:13:"options_array";s:0:"";s:8:"subtable";s:10:"currencies";s:15:"subtable_fields";a:1:{s:8:"currency";s:8:"currency";}s:13:"subtable_f_id";s:0:"";s:2:"id";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:10:"f_id_field";s:0:"";s:12:"default_text";s:0:"";s:10:"depends_on";s:0:"";s:20:"function_to_elements";s:0:"";s:16:"first_is_default";s:0:"";s:5:"level";s:0:"";s:11:"concat_char";s:0:"";s:9:"is_catsel";s:0:"";}', 13, 216, 0),
(2240, 'selectInput', 'a:20:{s:4:"name";s:19:"convert_to_currency";s:7:"caption";s:11:"To Currency";s:8:"required";s:0:"";s:5:"value";s:0:"";s:13:"options_array";s:0:"";s:8:"subtable";s:10:"currencies";s:15:"subtable_fields";a:1:{s:8:"currency";s:8:"currency";}s:13:"subtable_f_id";s:0:"";s:2:"id";s:0:"";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:10:"f_id_field";s:0:"";s:12:"default_text";s:0:"";s:10:"depends_on";s:0:"";s:20:"function_to_elements";s:0:"";s:16:"first_is_default";s:0:"";s:5:"level";s:0:"";s:11:"concat_char";s:0:"";s:9:"is_catsel";s:0:"";}', 14, 216, 0),
(2243, 'startArea', 'a:3:{s:6:"legend";s:19:"Currency Conversion";s:5:"class";s:9:"box_right";s:6:"height";s:0:"";}', 8, 217, 0),
(2244, 'endArea', '', 15, 217, 0);
INSERT INTO `admin_controls_methods` (`id`, `method`, `arguments`, `order`, `control_id`, `p_id`) VALUES
(2245, 'field', 'a:14:{s:4:"name";s:14:"convert_amount";s:7:"caption";s:17:"Amount to Convert";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 10, 217, 0),
(2246, 'field', 'a:14:{s:4:"name";s:18:"convert_rate_given";s:7:"caption";s:25:"Conversion Rate Given (%)";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 11, 217, 0),
(2247, 'field', 'a:14:{s:4:"name";s:19:"convert_system_rate";s:7:"caption";s:29:"System Rate @ Transaction (%)";s:8:"subtable";s:0:"";s:15:"subtable_fields";s:0:"";s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 12, 217, 0),
(2248, 'field', 'a:14:{s:4:"name";s:21:"convert_from_currency";s:7:"caption";s:13:"From Currency";s:8:"subtable";s:10:"currencies";s:15:"subtable_fields";a:1:{s:8:"currency";s:8:"currency";}s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 13, 217, 0),
(2249, 'field', 'a:14:{s:4:"name";s:19:"convert_to_currency";s:7:"caption";s:11:"To Currency";s:8:"subtable";s:10:"currencies";s:15:"subtable_fields";a:1:{s:8:"currency";s:8:"currency";}s:8:"link_url";s:0:"";s:11:"concat_char";s:0:"";s:7:"in_form";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:14:"override_value";s:0:"";s:13:"link_id_field";s:0:"";}', 14, 217, 0),
(2254, 'hiddenInput', 'a:8:{s:4:"name";s:8:"factored";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:3:"int";s:7:"jscript";s:0:"";s:20:"is_current_timestamp";s:0:"";s:15:"on_every_update";s:0:"";}', 1, 266, 0),
(2255, 'hiddenInput', 'a:8:{s:4:"name";s:9:"factored1";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:3:"int";s:7:"jscript";s:0:"";s:20:"is_current_timestamp";s:0:"";s:15:"on_every_update";s:0:"";}', 2, 266, 0),
(2256, 'textInput', 'a:13:{s:4:"name";s:4:"fee1";s:7:"caption";s:13:"Fee % (Maker)";s:8:"required";s:1:"1";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 1, 237, 0),
(2257, 'textInput', 'a:13:{s:4:"name";s:10:"global_btc";s:7:"caption";s:16:"Global BTC (24h)";s:8:"required";s:0:"";s:5:"value";s:0:"";s:2:"id";s:0:"";s:13:"db_field_type";s:7:"decimal";s:5:"class";s:0:"";s:7:"jscript";s:0:"";s:5:"style";s:0:"";s:15:"is_manual_array";s:0:"";s:9:"is_unique";s:0:"";s:12:"default_text";s:0:"";s:17:"delete_whitespace";s:0:"";}', 4, 237, 0),
(2258, 'field', 'a:18:{s:4:"name";s:4:"fee1";s:8:"subtable";s:0:"";s:14:"header_caption";s:13:"Maker Fee (%)";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";s:0:"";s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 0, 268, 0),
(2259, 'field', 'a:18:{s:4:"name";s:3:"fee";s:8:"subtable";s:0:"";s:14:"header_caption";s:13:"Taker Fee (%)";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";s:0:"";s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 1, 268, 0),
(2260, 'field', 'a:18:{s:4:"name";s:8:"from_usd";s:8:"subtable";s:0:"";s:14:"header_caption";s:15:"From USD (mon.)";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";s:0:"";s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 2, 268, 0),
(2261, 'field', 'a:18:{s:4:"name";s:6:"to_usd";s:8:"subtable";s:0:"";s:14:"header_caption";s:13:"To USD (mon.)";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";s:0:"";s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 3, 268, 0),
(2262, 'field', 'a:18:{s:4:"name";s:10:"global_btc";s:8:"subtable";s:0:"";s:14:"header_caption";s:16:"Global BTC (24h)";s:6:"filter";s:1:"Y";s:8:"link_url";s:0:"";s:15:"subtable_fields";s:0:"";s:22:"subtable_fields_concat";s:0:"";s:5:"class";s:0:"";s:18:"aggregate_function";s:0:"";s:12:"thumb_amount";s:0:"";s:12:"media_amount";s:0:"";s:10:"media_size";s:0:"";s:10:"f_id_field";s:0:"";s:8:"order_by";s:0:"";s:9:"order_asc";s:0:"";s:11:"link_is_tab";s:0:"";s:16:"limit_is_curdate";s:0:"";s:8:"is_media";s:0:"";}', 4, 268, 0);

-- --------------------------------------------------------

--
-- Table structure for table `admin_cron`
--

CREATE TABLE IF NOT EXISTS `admin_cron` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `method_id` int(10) unsigned NOT NULL,
  `control_id` int(10) unsigned NOT NULL,
  `day` varchar(30) NOT NULL,
  `month` varchar(30) NOT NULL,
  `year` varchar(30) NOT NULL,
  `send_condition` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `method_id` (`method_id`),
  KEY `control_id` (`control_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

-- --------------------------------------------------------

--
-- Table structure for table `admin_groups`
--

CREATE TABLE IF NOT EXISTS `admin_groups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `admin_groups`
--

INSERT INTO `admin_groups` (`id`, `name`, `order`) VALUES
(11, 'Admin', 0);

-- --------------------------------------------------------

--
-- Table structure for table `admin_groups_pages`
--

CREATE TABLE IF NOT EXISTS `admin_groups_pages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `group_id` int(10) unsigned NOT NULL,
  `page_id` int(10) unsigned NOT NULL,
  `permission` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `group_id` (`group_id`,`page_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=122 ;

-- --------------------------------------------------------

--
-- Table structure for table `admin_groups_tabs`
--

CREATE TABLE IF NOT EXISTS `admin_groups_tabs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `group_id` int(10) unsigned NOT NULL,
  `tab_id` int(10) unsigned NOT NULL,
  `permission` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `group_id` (`group_id`,`tab_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=52 ;

-- --------------------------------------------------------

--
-- Table structure for table `admin_image_sizes`
--

CREATE TABLE IF NOT EXISTS `admin_image_sizes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `field_name` varchar(100) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `field_name` (`field_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `admin_image_sizes`
--

INSERT INTO `admin_image_sizes` (`id`, `field_name`, `value`) VALUES
(3, 'banner', 'a:2:{s:5:"small";a:2:{s:6:"height";s:2:"50";s:5:"width";s:3:"100";}s:6:"banner";a:2:{s:6:"height";s:3:"428";s:5:"width";s:4:"1265";}}'),
(4, 'org_pic', 'a:3:{s:5:"small";a:2:{s:5:"width";s:2:"50";s:6:"height";s:2:"30";}s:6:"medium";a:2:{s:5:"width";s:3:"174";s:6:"height";s:3:"106";}s:5:"large";a:2:{s:5:"width";s:3:"248";s:6:"height";s:3:"148";}}'),
(5, 'prayer_pic', 'a:3:{s:5:"small";a:2:{s:5:"width";s:2:"50";s:6:"height";s:2:"30";}s:6:"medium";a:2:{s:5:"width";s:3:"174";s:6:"height";s:3:"106";}s:5:"large";a:2:{s:5:"width";s:3:"248";s:6:"height";s:3:"148";}}');

-- --------------------------------------------------------

--
-- Table structure for table `admin_order`
--

CREATE TABLE IF NOT EXISTS `admin_order` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `control_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `order_by` varchar(50) NOT NULL,
  `order_asc` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `control_id` (`control_id`,`user_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

-- --------------------------------------------------------

--
-- Table structure for table `admin_pages`
--

CREATE TABLE IF NOT EXISTS `admin_pages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `f_id` int(10) NOT NULL,
  `name` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `icon` varchar(255) NOT NULL,
  `order` smallint(3) unsigned NOT NULL,
  `page_map_reorders` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `f_id` (`f_id`,`order`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=94 ;

--
-- Dumping data for table `admin_pages`
--

INSERT INTO `admin_pages` (`id`, `f_id`, `name`, `url`, `icon`, `order`, `page_map_reorders`) VALUES
(81, 30, 'Fee Schedule', 'fee_schedule', '', 9, 0),
(64, 60, 'Authors', 'authors', '', 8, 0),
(82, 30, 'Phones', 'phones', '', 10, 0),
(83, 30, 'Bank Accounts', 'bank-accounts', '', 11, 0),
(84, 30, 'Bitcoin Addresses', 'bitcoin-addresses', '', 12, 0),
(74, 62, 'Order Types', 'order_types', '', 3, 0),
(75, 62, 'Transactions', 'transactions', '', 1, 0),
(76, 62, 'Transaction Types', 'transaction_types', '', 4, 0),
(77, 63, 'Request Types', 'request_types', '', 5, 0),
(78, 63, 'Request Status', 'request_status', '', 6, 0),
(79, 63, 'Request Descriptions', 'request_descriptions', '', 7, 0),
(80, 1, 'News', 'news', '', 0, 0),
(85, 64, 'Fees', 'fees', '', 13, 0),
(86, 65, 'Daily Reports', 'daily-reports', '', 14, 0),
(87, 65, 'Monthly Reports', 'monthly-reports', '', 15, 0),
(88, 62, 'Order Log', 'order-log', '', 2, 0),
(89, 63, 'Deposit / Withdraw', 'deposit-withdraw', '', 0, 0),
(90, 64, 'Currencies / Escrow Accounts', 'currencies', '', 0, 0),
(91, 30, 'User History', 'user-history', '', 0, 0),
(92, 30, 'History Actions', 'history-actions', '', 15, 0),
(93, 64, 'Currency Conversion Ledger', 'conversion-ledger', '', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `admin_sessions`
--

CREATE TABLE IF NOT EXISTS `admin_sessions` (
  `session_id` varchar(32) NOT NULL DEFAULT '',
  `session_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `session_start` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `session_value` text NOT NULL,
  `ip_address` varchar(16) NOT NULL DEFAULT '',
  `user_agent` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`session_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `admin_tabs`
--

CREATE TABLE IF NOT EXISTS `admin_tabs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `order` smallint(3) unsigned NOT NULL,
  `icon` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `hidden` enum('Y','N') NOT NULL DEFAULT 'N',
  `is_ctrl_panel` enum('Y','N') NOT NULL DEFAULT 'N',
  `for_group` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `order` (`order`,`is_ctrl_panel`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=66 ;

--
-- Dumping data for table `admin_tabs`
--

INSERT INTO `admin_tabs` (`id`, `name`, `order`, `icon`, `url`, `hidden`, `is_ctrl_panel`, `for_group`) VALUES
(1, 'Content', 0, '', 'content', '', '', 0),
(4, 'Emails', 6, '', 'emails', '', '', 0),
(30, 'Registered Visitors', 4, '', 'registered-visitors', '', '', 0),
(32, 'Language Table', 5, '', 'lang-table', '', '', 0),
(60, 'Divrei Torah', 3, '', 'divrei-torah', 'Y', '', 0),
(62, 'Orders', 1, '', 'orders', '', '', 0),
(63, 'Requests', 2, '', 'requests', '', '', 0),
(64, 'Status', 7, '', 'status', '', '', 0),
(65, 'Reports', 8, '', 'reports', '', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `admin_users`
--

CREATE TABLE IF NOT EXISTS `admin_users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user` varchar(50) NOT NULL,
  `pass` varchar(50) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `company` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `city` varchar(50) NOT NULL,
  `country_id` int(10) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `website` varchar(255) NOT NULL,
  `f_id` int(10) unsigned NOT NULL,
  `order` int(10) unsigned NOT NULL DEFAULT '0',
  `is_admin` enum('N','Y') NOT NULL DEFAULT 'N',
  `country_code` int(4) NOT NULL,
  `verified_authy` enum('N','Y') NOT NULL DEFAULT 'N',
  `authy_id` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=31 ;

--
-- Dumping data for table `admin_users`
--

INSERT INTO `admin_users` (`id`, `user`, `pass`, `first_name`, `last_name`, `company`, `address`, `city`, `country_id`, `phone`, `email`, `website`, `f_id`, `order`, `is_admin`, `country_code`, `verified_authy`, `authy_id`) VALUES
(30, 'admin', 'admin', 'Admin', '', '', '', '', 0, '', '', '', 0, 0, 'Y', 0, 'N', '');

-- --------------------------------------------------------

--
-- Table structure for table `api_keys`
--

CREATE TABLE IF NOT EXISTS `api_keys` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(255) NOT NULL,
  `secret` varchar(255) NOT NULL,
  `view` enum('Y','N') NOT NULL DEFAULT 'Y',
  `orders` enum('Y','N') NOT NULL DEFAULT 'N',
  `withdraw` enum('Y','N') NOT NULL DEFAULT 'N',
  `site_user` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key` (`key`),
  KEY `site_user` (`site_user`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `bank_accounts`
--

CREATE TABLE IF NOT EXISTS `bank_accounts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `account_number` bigint(20) NOT NULL,
  `site_user` int(10) NOT NULL,
  `description` varchar(255) NOT NULL,
  `currency` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `site_user` (`site_user`),
  KEY `account_number` (`account_number`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `bitcoin_addresses`
--

CREATE TABLE IF NOT EXISTS `bitcoin_addresses` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `address` varchar(255) NOT NULL,
  `site_user` int(10) NOT NULL,
  `date` datetime NOT NULL,
  `system_address` enum('Y','N') NOT NULL DEFAULT 'N',
  `hot_wallet` enum('Y','N') NOT NULL DEFAULT 'N',
  `warm_wallet` enum('Y','N') NOT NULL DEFAULT 'N',
  PRIMARY KEY (`id`),
  KEY `site_user` (`site_user`),
  KEY `system_address` (`system_address`),
  KEY `hot_wallet` (`hot_wallet`),
  KEY `warm_wallet` (`warm_wallet`),
  KEY `address` (`address`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `change_settings`
--

CREATE TABLE IF NOT EXISTS `change_settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `request` blob NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `date` (`date`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `content`
--

CREATE TABLE IF NOT EXISTS `content` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `url` varchar(255) NOT NULL,
  `title_en` varchar(255) NOT NULL,
  `title_es` varchar(255) NOT NULL,
  `content_en` blob NOT NULL,
  `content_es` blob NOT NULL,
  PRIMARY KEY (`id`),
  KEY `url` (`url`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=55 ;

--
-- Dumping data for table `content`
--

INSERT INTO `content` (`id`, `url`, `title_en`, `title_es`, `content_en`, `content_es`) VALUES
(25, 'home', 'Log Into Our Demo!', 'Haga Login Al Demo!', 0x3c703e596f752063616e206c6f6720696e746f2074686973205b65786368616e67655f6e616d655d2064656d6f2077697468206f6e65206f662074686520666f6c6c6f77696e673a2028312920557365722f506173732031323334353637382f3132333435363738206f722028322920557365722f506173732038373635343332312f38373635343332312e20476f2061686561642c20676976652069742061207370696e2e3c2f703e0d0a, 0x3c703e5075656465206861636572206c6f67696e2061206e75657374726f2064656d6f206465205b65786368616e67655f6e616d655d20636f6e206c6173207369677569656e74657320646f73206375656e7461733a202831292055737572696f2f436f6e7472732031323334353637382f3132333435363738206f202832292055737572696f2f436f6e7472732038373635343332312f38373635343332312e20496e74266561637574653b6e74656c6f213c2f703e0d0a),
(26, 'home-feature1', 'Simple Use', 'Uso Simple', 0x3c703e5374726169676874666f727761726420696e74657266616365206d616b65732074726164696e67206561737920666f72206576657279626f64792e3c2f703e0d0a, 0x3c703e496e746572666163652073696d706c6966696361646f20666163696c69746120636f6d70726176656e7461207061726120746f646f732e3c2f703e0d0a),
(27, 'home-feature2', 'Easy Funding', 'Fácil carga', 0x3c703e46756e64696e6720616e64207769746864726177696e672066726f6d20796f7572206163636f756e7420696e20426974636f696e73206f7220466961742063757272656e63792c207375636820617320555344206f722045555220686173206e65766572206265656e206561736965722e3c2f703e0d0a, 0x3c703e436172676172206f207265746972617220666f6e646f73206465736465207375206375656e746120646520426974636f696e73206f2064696e65726f206669647563696172696f2c2074616c20636f6d6f20555344206f20455552206e756e6361206675266561637574653b206d266161637574653b732066266161637574653b63696c2e3c2f703e0d0a),
(28, 'home-feature3', 'More Secure', 'Más seguro', 0x3c703e57652061726520636f6e73697374656e746c7920766967696c616e7420746f20656e73757265207468617420796f7572206d6f6e657920616e6420706572736f6e616c20696e666f726d6174696f6e20617265207365637572652e3c6272202f3e0d0a266e6273703b3c2f703e0d0a, 0x3c703e56656c616d6f7320636f6e7374616e74656d656e746520706f72206c61207365677572696461642064652073752064696e65726f206520696e666f726d616369266f61637574653b6e20706572736f6e616c2e3c2f703e0d0a),
(29, 'home-feature4', 'Low Fees', 'Cuotas Bajas', 0x3c703e4f7572206c6f77206665657320656e73757265207468617420796f757220426974636f696e207472616465732077696c6c2062652061732070726f66697461626c6520617320706f737369626c652e3c2f703e0d0a, 0x3c703e4e756573747261732062616a61732063756f74617320617365677572616e207175652073757320636f6d70726176656e7461732072656e646972266161637574653b6e206c6f206d266161637574653b7320706f7369626c652e3c2f703e0d0a),
(30, 'security-explain', 'Two-Factor Authentication', 'Autenticación de dos factores', 0x3c703e456e61626c696e672074776f2d666163746f722061757468656e7469636174696f6e206164647320616e206578747261206c61796572206f6620736563757269747920746f20796f7572206163636f756e742e20496e206164646974696f6e20746f20796f757220726567756c61722070617373776f72642c20796f7572206163636f756e742077696c6c207265717569726520796f7520746f20696e707574206120746f6b656e2066726f6d20796f75722063656c6c2070686f6e6520746f207369676e20696e2e3c2f703e0d0a0d0a3c703e5468657265206172652074776f207761797320746f20646f20746869733a3c2f703e0d0a0d0a3c6f6c3e0d0a093c6c693e446f776e6c6f616420746865206170702063616c6c6564203c7374726f6e673e41757468793c2f7374726f6e673e206f6e20796f757220736d61727470686f6e653c656d3e20287265636f6d6d656e646564293c2f656d3e2e3c2f6c693e0d0a093c6c693e446f776e6c6f6164203c7374726f6e673e476f6f676c652041757468656e74696361746f723c2f7374726f6e673e206f6e20796f757220736d61727470686f6e652e3c2f6c693e0d0a093c6c693e5265636569766520796f757220746f6b656e20627920534d532e3c2f6c693e0d0a3c2f6f6c3e0d0a0d0a3c703e4f6e636520796f7520636f6d706c657465207468652070726f63657373206f6e207468697320706167652c2074776f2d666163746f722061757468656e7469636174696f6e2077696c6c20626520656e61626c65642e3c2f703e0d0a0d0a3c703e506c65617365206e6f74653a20496620796f75206c6f736520796f75722070686f6e6520796f752077696c6c206e65656420746f20676f207468726f756768206f7572203c6120687265663d2272657365745f3266612e70687022207461726765743d225f626c616e6b223e72657365742070726f636573733c2f613e20746f20726573746f7265206163636573732e3c2f703e0d0a, 0x3c703e486162696c69746172207375206375656e74612070617261207574696c697a6172206c6120617574656e746963616369266f61637574653b6e20646520646f7320666163746f726573206c65206272696e646120756e206e6976656c20646520736567757269646164206d266161637574653b7320656c657661646f2e204164656d266161637574653b7320646520737520636f6e7472617365266e74696c64653b6120726567756c61722c207375206375656e7461207265717565726972266161637574653b20646520756e2063266f61637574653b6469676f2070696e20717565206f6274656e6472266161637574653b2064657364652073752074656c266561637574653b666f6e6f206d266f61637574653b76696c207061726120696e6772657361722061207375206375656e74612e3c2f703e0d0a0d0a3c703e48617920646f7320666f726d6173206465206861636572206573746f3a3c2f703e0d0a0d0a3c6f6c3e0d0a093c6c693e496e7374616c6520656c20617070206c6c616d61646f203c7374726f6e673e41757468793c2f7374726f6e673e20656e207375206d266f61637574653b76696c2028723c656d3e65636f6d656e6461646f3c2f656d3e292e3c2f6c693e0d0a093c6c693e496e7374616c65203c7374726f6e673e476f6f676c652041757468656e74696361746f723c2f7374726f6e673e20656e207375206d266f61637574653b76696c2e3c2f6c693e0d0a093c6c693e526563696261207375732063266f61637574653b6469676f7320706f7220534d532e3c2f6c693e0d0a3c2f6f6c3e0d0a0d0a3c703e556e612076657a20636f6d706c657461646f20656c2070726f6365736f20646520657374612070266161637574653b67696e612c206c6120617574656e746963616369266f61637574653b6e20646520646f7320666163746f726573206573746172266161637574653b20686162696c69746164612e3c2f703e0d0a0d0a3c703e506f72206661766f72206e6f7461723a205369207365206c6520657874726176266961637574653b612073752074656c266561637574653b666f6e6f2c2074656e6472266161637574653b2071756520736567756972206e75657374726f203c6120687265663d2272657365745f3266612e70687022207461726765743d225f626c616e6b223e70726f6365736f2064652072656375706572616369266f61637574653b6e3c2f613e20706172612072657374617572617220656c2061636365736f2e3c2f703e0d0a),
(31, 'security-token', 'Verify Your Token', 'Verificar su código', 0x3c703e4e6f772069742069732074696d6520746f206f70656e207468652041757468792061707020796f7520646f776e6c6f61646564206f6e20796f75722063656c6c70686f6e652e205768656e20796f7520646f20736f2c20796f752073686f756c64207365652061206e756d6572696320746f6b656e2e20506c6561736520696e70757420697420696e746f2074686520666f726d2062656c6f772e3c6272202f3e0d0a266e6273703b3c2f703e0d0a, 0x3c703e41686f72612c20696e67726573652061206c612061706c6963616369266f61637574653b6e204175746879207175652062616a266f61637574653b20612073752063656c756c61722e20416c2068616365726c6f2c206c612061706c6963616369266f61637574653b6e206c65206d6f7374726172266161637574653b20756e2063266f61637574653b6469676f2c206f202671756f743b746f6b656e2671756f743b206e756d266561637574653b7269636f2e20506f72206661766f7220696e6772266561637574653b73656c6f20656e20656c20666f726d756c6172696f206120636f6e74696e75616369266f61637574653b6e2e3c2f703e0d0a),
(32, 'security-setup', 'Two-Factor Authentication Setup', 'Configuración de autenticación de dos factores', 0x3c703e54776f2d666163746f722061757468656e7469636174696f6e2069732073657420757020666f7220796f7572206163636f756e74207573696e672074686520666f6c6c6f77696e672070686f6e653a3c2f703e0d0a, 0x3c703e4c6120617574656e746963616369266f61637574653b6e20646520646f7320666163746f72657320657374266161637574653b20636f6e66696775726164612070617261207375206375656e7461207573616e646f20656c207369677569656e7465206d266f61637574653b76696c3a3c2f703e0d0a),
(33, 'security-token-login', 'Verify Your Token', 'Verificar su código', 0x3c703e506c6561736520656e74657220796f757220746f6b656e2e2054686973206d61792062652067656e6572617465642062792074686520417574687920417070206f722073656e7420627920534d5320746f20796f75722070686f6e652c20646570656e64696e67206f6e20796f757220707265666572656e6365732e3c2f703e0d0a0d0a3c703e506c65617365206e6f74653a20496620796f75206c6f737420796f75722070686f6e6520796f752077696c6c206e65656420746f20676f207468726f756768206f7572203c6120687265663d2268747470733a2f2f7777772e61757468792e636f6d2f70686f6e65732f6368616e676522207461726765743d225f626c616e6b223e72657365742070726f636573733c2f613e20746f20726573746f7265206163636573732e3c2f703e0d0a, 0x3c703e506f72206661766f7220696e677265736520656c2063266f61637574653b6469676f20616c6561746f72696f2e20457374652065732067656e657261646f20706f72204175746879206f20726563696269646f20706f7220534d5320646570656e6469656e646f2064652073757320707265666572656e636961732e3c2f703e0d0a0d0a3c703e506f72206661766f72206e6f7461723a205369207365206c652065787472617669266f61637574653b2073752074656c266561637574653b666f6e6f2c2074656e6472266161637574653b2071756520736567756972206e75657374726f203c6120687265663d2268747470733a2f2f7777772e61757468792e636f6d2f70686f6e65732f6368616e676522207461726765743d225f626c616e6b223e70726f6365736f2064652072656375706572616369266f61637574653b6e3c2f613e20706172612072657374617572617220656c2061636365736f2e3c2f703e0d0a),
(34, 'what-are-bitcoins', 'A Short Introduction To Bitcoin', 'Una corta introducción a los bitcoins', 0x3c703e3c7374726f6e673e426974636f696e3c2f7374726f6e673e2069732061203c6120687265663d22687474703a2f2f656e2e77696b6970656469612e6f72672f77696b692f506565722d746f2d7065657222207469746c653d22506565722d746f2d70656572223e706565722d746f2d706565723c2f613e203c6120687265663d22687474703a2f2f656e2e77696b6970656469612e6f72672f77696b692f5061796d656e745f73797374656d22207469746c653d225061796d656e742073797374656d223e7061796d656e742073797374656d3c2f613e20616e64203c6120687265663d22687474703a2f2f656e2e77696b6970656469612e6f72672f77696b692f4469676974616c5f63757272656e637922207469746c653d224469676974616c2063757272656e6379223e6469676974616c2063757272656e63793c2f613e20696e74726f6475636564206173203c6120687265663d22687474703a2f2f656e2e77696b6970656469612e6f72672f77696b692f4f70656e5f736f7572636522207469746c653d224f70656e20736f75726365223e6f70656e20736f757263653c2f613e20736f66747761726520696e2032303039206279203c6120687265663d22687474703a2f2f656e2e77696b6970656469612e6f72672f77696b692f50736575646f6e796d22207469746c653d2250736575646f6e796d223e70736575646f6e796d6f75733c2f613e20646576656c6f706572203c6120687265663d22687474703a2f2f656e2e77696b6970656469612e6f72672f77696b692f5361746f7368695f4e616b616d6f746f22207469746c653d225361746f736869204e616b616d6f746f223e5361746f736869204e616b616d6f746f3c2f613e2e2049742069732061203c6120687265663d22687474703a2f2f656e2e77696b6970656469612e6f72672f77696b692f43727970746f63757272656e637922207469746c653d2243727970746f63757272656e6379223e63727970746f63757272656e63793c2f613e2c20736f2d63616c6c656420626563617573652069742075736573203c6120687265663d22687474703a2f2f656e2e77696b6970656469612e6f72672f77696b692f43727970746f67726170687922207469746c653d2243727970746f677261706879223e63727970746f6772617068793c2f613e20746f20636f6e74726f6c20746865206372656174696f6e20616e64207472616e73666572206f66206d6f6e65792e55736572732073656e64207061796d656e74732062792062726f616463617374696e67203c6120687265663d22687474703a2f2f656e2e77696b6970656469612e6f72672f77696b692f4469676974616c5f7369676e617475726522207469746c653d224469676974616c207369676e6174757265223e6469676974616c6c79207369676e65643c2f613e206d6573736167657320746f20746865206e6574776f726b2e205061727469636970616e7473206b6e6f776e206173203c6120636c6173733d226d772d72656469726563742220687265663d22687474703a2f2f656e2e77696b6970656469612e6f72672f77696b692f426974636f696e5f6d696e696e6722207469746c653d22426974636f696e206d696e696e67223e6d696e6572733c2f613e2076657269667920616e64203c6120687265663d22687474703a2f2f656e2e77696b6970656469612e6f72672f77696b692f54696d657374616d7022207469746c653d2254696d657374616d70223e74696d657374616d703c2f613e207472616e73616374696f6e7320696e746f206120736861726564207075626c69632064617461626173652063616c6c65642074686520626c6f636b20636861696e2c20666f722077686963682074686579206172652072657761726465642077697468207472616e73616374696f6e206665657320616e64206e65776c79206d696e74656420626974636f696e732e436f6e76656e74696f6e616c6c79202671756f743b426974636f696e2671756f743b206361706974616c697a65642072656665727320746f2074686520746563686e6f6c6f677920616e64206e6574776f726b2077686572656173202671756f743b626974636f696e732671756f743b206c6f776572636173652072656665727320746f207468652063757272656e637920697473656c662e266e6273703b426974636f696e732063616e206265206f627461696e6564206279206d696e696e67206f7220696e2065786368616e676520666f722070726f64756374732c2073657276696365732c206f72206f746865722063757272656e636965732e3c2f703e0d0a0d0a3c703e3c656d3e536f757263653a2057696b6970656469613c2f656d3e3c6272202f3e0d0a266e6273703b3c2f703e0d0a0d0a3c703e3c696672616d6520616c6c6f7766756c6c73637265656e3d2222206672616d65626f726465723d223022206865696768743d2233313522207372633d222f2f7777772e796f75747562652e636f6d2f656d6265642f556d36334f517a33626a6f222077696474683d22353630223e3c2f696672616d653e3c2f703e0d0a, 0x3c703e3c7374726f6e673e42697463266f61637574653b696e3c2f7374726f6e673e20287369676e6f3a20e0b8bf3b206162722e3a204254432920657320756e61203c6120687265663d22687474703a2f2f65732e77696b6970656469612e6f72672f77696b692f43726970746f64697669736122207469746c653d2243726970746f646976697361223e63726970746f6469766973613c2f613e2064657363656e7472616c697a61646120636f6e63656269646120656e203c6120687265663d22687474703a2f2f65732e77696b6970656469612e6f72672f77696b692f3230303822207469746c653d2232303038223e323030383c2f613e20706f7220756e6120706572736f6e6120286f20677275706f20646520706572736f6e617329207175652062616a6f20656c2073657564266f61637574653b6e696d6f202671756f743b3c6120687265663d22687474703a2f2f65732e77696b6970656469612e6f72672f77696b692f426974636f696e235361746f7368695f4e616b616d6f746f22207469746c653d22426974636f696e223e5361746f736869204e616b616d6f746f3c2f613e2671756f743b207075626c6963266f61637574653b20756e206c6962726f20626c616e636f207175652070726f706f6e6520756e2073697374656d61206465207472616e73616363696f6e657320656c65637472266f61637574653b6e6963617320717565206e6f20646570656e6465206465206c6120636f6e6669616e7a612c2073696e6f20717565207065726d697465207265616c697a6172207472616e73666572656e6369617320646520666f726d6120646972656374612073696e206c61206e656365736964616420646520756e20696e7465726d6564696172696f2e20456c2074266561637574653b726d696e6f2073652061706c6963612074616d6269266561637574653b6e20616c203c6120636c6173733d226d772d72656469726563742220687265663d22687474703a2f2f65732e77696b6970656469612e6f72672f77696b692f50726f746f636f6c6f5f253238696e666f726d2543332541317469636125323922207469746c653d2250726f746f636f6c6f2028696e666f726dc3a17469636129223e70726f746f636f6c6f3c2f613e2064697365266e74696c64653b61646f20706f7220656c206d69736d6f206175746f7220792061206c61203c6120687265663d22687474703a2f2f65732e77696b6970656469612e6f72672f77696b692f5265645f64655f636f6d70757461646f72617322207469746c653d2252656420646520636f6d70757461646f726173223e7265643c2f613e203c6120687265663d22687474703a2f2f65732e77696b6970656469612e6f72672f77696b692f506565722d746f2d7065657222207469746c653d22506565722d746f2d70656572223e5032503c2f613e20717565206c6f2073757374656e74612e20416c20636f6e74726172696f206465206c61206d61796f72266961637574653b61206465206c6173206d6f6e656461732c20656c2062697463266f61637574653b696e206e6f20657374266161637574653b2072657370616c6461646f20706f72206e696e67267561637574653b6e20676f626965726e6f206e6920646570656e6465206465206c6120636f6e6669616e7a6120656e206e696e67267561637574653b6e20656d69736f722063656e7472616c2c2073696e6f20717565207574696c697a6120756e203c6120687265663d22687474703a2f2f65732e77696b6970656469612e6f72672f77696b692f50726f6f662d6f662d776f726b5f73797374656d22207469746c653d2250726f6f662d6f662d776f726b2073797374656d223e73697374656d61206465207072756562612064652074726162616a6f3c2f613e207061726120696d706564697220656c20646f626c6520676173746f207920616c63616e7a617220656c20636f6e73656e736f20656e74726520746f646f73206c6f73206e6f646f732071756520696e74656772616e206c61207265642e20426974636f696e20657320756e2070726f796563746f2072656c61746976616d656e7465206e7565766f2071756520736520656e6375656e74726120656e2065766f6c756369266f61637574653b6e2e20506f7220657374612072617a266f61637574653b6e2c20737573206465736172726f6c6c61646f726573207265636f6d69656e64616e2073657220636175746f732079207472617461726c6f20636f6d6f20736f667477617265206578706572696d656e74616c2e3c2f703e0d0a0d0a3c703e3c656d3e536f757263653a2057696b6970656469613c2f656d3e3c2f703e0d0a0d0a3c703e3c696672616d6520616c6c6f7766756c6c73637265656e3d2222206672616d65626f726465723d223022206865696768743d2233313522207372633d222f2f7777772e796f75747562652e636f6d2f656d6265642f556d36334f517a33626a6f222077696474683d22353630223e3c2f696672616d653e3c2f703e0d0a),
(35, 'how-bitcoin-works', 'How Does Bitcoin Work?', 'Cómo funciona Bitcoin?', 0x3c6831207374796c653d22746578742d616c69676e3a63656e746572223e486f7720646f657320426974636f696e20776f726b3f3c2f68313e0d0a0d0a3c70207374796c653d22746578742d616c69676e3a63656e746572223e546869732069732061207175657374696f6e2074686174206f6674656e2063617573657320636f6e667573696f6e2e2048657265262333393b73206120717569636b206578706c616e6174696f6e213c2f703e0d0a0d0a3c68323e5468652062617369637320666f722061206e657720757365723c2f68323e0d0a0d0a3c70207374796c653d22746578742d616c69676e3a6a757374696679223e41732061206e657720757365722c20796f752063616e266e6273703b6765742073746172746564266e6273703b7769746820426974636f696e20776974686f757420756e6465727374616e64696e672074686520746563686e6963616c2064657461696c732e204f6e636520796f75206861766520696e7374616c6c6564206120426974636f696e2077616c6c6574206f6e20796f757220636f6d7075746572206f72206d6f62696c652070686f6e652c2069742077696c6c2067656e657261746520796f757220666972737420426974636f696e206164647265737320616e6420796f752063616e20637265617465206d6f7265207768656e6576657220796f75206e656564206f6e652e20596f752063616e20646973636c6f736520796f75722061646472657373657320746f20796f757220667269656e647320736f207468617420746865792063616e2070617920796f75206f7220766963652076657273612e20496e20666163742c2074686973206973207072657474792073696d696c617220746f20686f7720656d61696c20776f726b732c20657863657074207468617420426974636f696e206164647265737365732073686f756c64206f6e6c792062652075736564206f6e63652e3c2f703e0d0a0d0a3c70207374796c653d22746578742d616c69676e3a6a757374696679223e3c6272202f3e0d0a3c696d6720616c743d22426974636f696e22207372633d2268747470733a2f2f626974636f696e2e6f72672f696d672f626974636f696e2d686f772d69742d776f726b732e73766722207374796c653d22626f726465723a30707822202f3e3c2f703e0d0a0d0a3c68323e42616c616e636573266e6273703b2d20626c6f636b20636861696e3c2f68323e0d0a0d0a3c70207374796c653d22746578742d616c69676e3a6a757374696679223e54686520626c6f636b20636861696e2069732061266e6273703b3c7374726f6e673e736861726564207075626c6963206c65646765723c2f7374726f6e673e266e6273703b6f6e2077686963682074686520656e7469726520426974636f696e206e6574776f726b2072656c6965732e20416c6c20636f6e6669726d6564207472616e73616374696f6e732061726520696e636c7564656420696e2074686520626c6f636b20636861696e2e2054686973207761792c20426974636f696e2077616c6c6574732063616e2063616c63756c617465207468656972207370656e6461626c652062616c616e636520616e64206e6577207472616e73616374696f6e732063616e20626520766572696669656420746f206265207370656e64696e6720626974636f696e732074686174206172652061637475616c6c79206f776e656420627920746865207370656e6465722e2054686520696e7465677269747920616e6420746865206368726f6e6f6c6f676963616c206f72646572206f662074686520626c6f636b20636861696e2061726520656e666f726365642077697468266e6273703b63727970746f6772617068792e3c2f703e0d0a0d0a3c68323e5472616e73616374696f6e73266e6273703b2d2070726976617465206b6579733c2f68323e0d0a0d0a3c70207374796c653d22746578742d616c69676e3a6a757374696679223e41207472616e73616374696f6e206973266e6273703b3c7374726f6e673e61207472616e73666572206f662076616c7565206265747765656e20426974636f696e2077616c6c6574733c2f7374726f6e673e266e6273703b74686174206765747320696e636c7564656420696e2074686520626c6f636b20636861696e2e20426974636f696e2077616c6c657473206b656570206120736563726574207069656365206f6620646174612063616c6c65642061266e6273703b3c656d3e70726976617465206b65793c2f656d3e266e6273703b6f7220736565642c207768696368206973207573656420746f207369676e207472616e73616374696f6e732c2070726f766964696e672061206d617468656d61746963616c2070726f6f6620746861742074686579206861766520636f6d652066726f6d20746865206f776e6572206f66207468652077616c6c65742e20546865266e6273703b3c656d3e7369676e61747572653c2f656d3e266e6273703b616c736f2070726576656e747320746865207472616e73616374696f6e2066726f6d206265696e6720616c746572656420627920616e79626f6479206f6e636520697420686173206265656e206973737565642e20416c6c207472616e73616374696f6e73206172652062726f616463617374206265747765656e20757365727320616e6420757375616c6c7920626567696e20746f20626520636f6e6669726d656420627920746865206e6574776f726b20696e2074686520666f6c6c6f77696e67203130206d696e757465732c207468726f75676820612070726f636573732063616c6c6564266e6273703b3c656d3e6d696e696e673c2f656d3e2e3c2f703e0d0a0d0a3c68323e50726f63657373696e67266e6273703b2d206d696e696e673c2f68323e0d0a0d0a3c70207374796c653d22746578742d616c69676e3a6a757374696679223e4d696e696e672069732061266e6273703b3c7374726f6e673e646973747269627574656420636f6e73656e7375732073797374656d3c2f7374726f6e673e266e6273703b74686174206973207573656420746f266e6273703b3c656d3e636f6e6669726d3c2f656d3e266e6273703b77616974696e67207472616e73616374696f6e7320627920696e636c7564696e67207468656d20696e2074686520626c6f636b20636861696e2e20497420656e666f726365732061206368726f6e6f6c6f676963616c206f7264657220696e2074686520626c6f636b20636861696e2c2070726f746563747320746865206e65757472616c697479206f6620746865206e6574776f726b2c20616e6420616c6c6f777320646966666572656e7420636f6d70757465727320746f206167726565206f6e20746865207374617465206f66207468652073797374656d2e20546f20626520636f6e6669726d65642c207472616e73616374696f6e73206d757374206265207061636b656420696e2061266e6273703b3c656d3e626c6f636b3c2f656d3e266e6273703b7468617420666974732076657279207374726963742063727970746f677261706869632072756c657320746861742077696c6c20626520766572696669656420627920746865206e6574776f726b2e2054686573652072756c65732070726576656e742070726576696f757320626c6f636b732066726f6d206265696e67206d6f646966696564206265636175736520646f696e6720736f20776f756c6420696e76616c696461746520616c6c20666f6c6c6f77696e6720626c6f636b732e204d696e696e6720616c736f206372656174657320746865206571756976616c656e74206f66206120636f6d7065746974697665206c6f747465727920746861742070726576656e747320616e7920696e646976696475616c2066726f6d20656173696c7920616464696e67206e657720626c6f636b7320636f6e73656375746976656c7920696e2074686520626c6f636b20636861696e2e2054686973207761792c206e6f20696e646976696475616c732063616e20636f6e74726f6c207768617420697320696e636c7564656420696e2074686520626c6f636b20636861696e206f72207265706c616365207061727473206f662074686520626c6f636b20636861696e20746f20726f6c6c206261636b207468656972206f776e207370656e64732e3c2f703e0d0a0d0a3c68323e476f696e6720646f776e207468652072616262697420686f6c653c2f68323e0d0a0d0a3c70207374796c653d22746578742d616c69676e3a6a757374696679223e54686973206973206f6e6c79206120766572792073686f727420616e6420636f6e636973652073756d6d617279206f66207468652073797374656d2e20496620796f752077616e7420746f2067657420696e746f207468652064657461696c732c20796f752063616e266e6273703b3c6120687265663d2268747470733a2f2f626974636f696e2e6f72672f626974636f696e2e70646622207374796c653d22636f6c6f723a207267622834342c203131312c20313733293b20746578742d6465636f726174696f6e3a206e6f6e653b223e7265616420746865206f726967696e616c2070617065723c2f613e266e6273703b7468617420646573637269626573207468652073797374656d262333393b732064657369676e2c20616e64206578706c6f726520746865266e6273703b426974636f696e2077696b692e3c2f703e0d0a0d0a3c70207374796c653d22746578742d616c69676e3a6a757374696679223e266e6273703b3c2f703e0d0a0d0a3c70207374796c653d22746578742d616c69676e3a6a757374696679223e3c656d3e536f757263653a266e6273703b3c6120687265663d22687474703a2f2f7777772e626974636f696e2e6f7267223e202671756f743b7777772e626974636f696e2e6f72672671756f743b3c2f613e3c2f656d3e3c2f703e0d0a, 0x3c6831207374796c653d22746578742d616c69676e3a63656e746572223e266971756573743b43266f61637574653b6d6f2066756e63696f6e6120426974636f696e3f3c2f68313e0d0a0d0a3c70207374796c653d22746578742d616c69676e3a63656e746572223e4573746120657320756e612070726567756e7461207175652061206d656e75646f20636175736120636f6e667573696f6e65732e2026696578636c3b417175266961637574653b207469656e6520756e61206578706c6963616369266f61637574653b6e2072266161637574653b70696461213c2f703e0d0a0d0a3c68323e4c6f206573656e6369616c207061726120756e207573756172696f206e7565766f3c2f68323e0d0a0d0a3c70207374796c653d22746578742d616c69676e3a6a757374696679223e436f6d6f207573756172696f206e7565766f2c207573746564207075656465266e6273703b656d70657a6172266e6273703b636f6e20426974636f696e2073696e20656e74656e646572206c6f7320646574616c6c65732074266561637574653b636e69636f732e20556e612076657a2075737465642074656e676120696e7374616c61646f20756e206d6f6e656465726f20656e207375206f7264656e61646f72206f20646973706f73697469766f206d266f61637574653b76696c2c2073652067656e65726172266161637574653b207375207072696d6572612064697265636369266f61637574653b6e20426974636f696e207920706f6472266161637574653b206372656172206d266161637574653b73206375616e646f206c6f206e656365736974652e205075656465206461722073752064697265636369266f61637574653b6e20612073757320616d69676f73207061726120717565206c652070616775656e206f207669636576657273612e20446520686563686f2c2065732073696d696c6172206120636f6d6f2066756e63696f6e6120656c20636f7272656f20656c65637472266f61637574653b6e69636f2c206578636570746f20717565206c617320646972656363696f6e657320426974636f696e20736f6c616d656e7465206465626572266961637574653b616e207365722075736164617320756e6120267561637574653b6e6963612076657a2e3c2f703e0d0a0d0a3c70207374796c653d22746578742d616c69676e3a6a757374696679223e3c6272202f3e0d0a3c696d6720616c743d22426974636f696e22207372633d2268747470733a2f2f626974636f696e2e6f72672f696d672f626974636f696e2d686f772d69742d776f726b732e73766722207374796c653d22626f726465723a30707822202f3e3c2f703e0d0a0d0a3c68323e42616c616e636573266e6273703b2d20636164656e6120646520626c6f717565733c2f68323e0d0a0d0a3c70207374796c653d22746578742d616c69676e3a6a757374696679223e4c6120636164656e6120646520626c6f71756573206f202671756f743b626c6f636b20636861696e2671756f743b20657320756e61266e6273703b3c7374726f6e673e636f6e746162696c696461642070267561637574653b626c69636120636f6d706172746964613c2f7374726f6e673e266e6273703b656e206c6120717565207365206261736120746f6461206c612072656420426974636f696e2e20546f646173206c6173207472616e73616363696f6e657320636f6e6669726d6164617320736520696e636c7579656e20656e206c6120636164656e6120646520626c6f717565732e2044652065737461206d616e657261206c6f73206d6f6e656465726f7320426974636f696e2070756564656e2063616c63756c61722073752073616c646f206761737461626c652079206c6173206e7565766173207472616e73616363696f6e65732070756564656e207365722076657269666963616461732c20617365677572616e646f2071756520656c20636f62726f20736520657374612068616369656e646f20616c20717565207265616c697a6120656c207061676f2e204c6120696e7465677269646164207920656c206f7264656e2063726f6e6f6c266f61637574653b6769636f206465206c6120636164656e6120646520626c6f7175657320736520686163656e2063756d706c697220636f6e63726970746f67726166266961637574653b612e3c2f703e0d0a0d0a3c68323e5472616e73616363696f6e6573266e6273703b2d206c6c617665732070726976616461733c2f68323e0d0a0d0a3c70207374796c653d22746578742d616c69676e3a6a757374696679223e556e61207472616e7361636369266f61637574653b6e206573266e6273703b3c7374726f6e673e756e61207472616e73666572656e6369612064652076616c6f72657320656e747265206d6f6e656465726f7320426974636f696e3c2f7374726f6e673e266e6273703b71756520736572266161637574653b20696e636c7569646120656e206c6120636164656e6120646520626c6f717565732e204c6f73206d6f6e656465726f7320426974636f696e20646973706f6e656e20646520756e20667261676d656e746f207365637265746f206c6c616d61646f266e6273703b636c61766520707269766164612c207574696c697a6164612070617261206669726d6172206c6173206f7065726163696f6e65732c2070726f706f7263696f6e616e646f20756e6120707275656261206d6174656d266161637574653b7469636120646520717565206c61207472616e7361636369266f61637574653b6e20657374266161637574653b20686563686120706f7220656c2070726f706965746172696f2064656c206d6f6e656465726f2e204c61266e6273703b6669726d61266e6273703b74616d6269266561637574653b6e20657669746120717565206c61207472616e7361636369266f61637574653b6e206e6f2073656120616c74657261646120706f7220616c677569656e20756e612076657a20266561637574653b737461206861207369646f20656d69746964612e20546f646173206c6173207472616e73616363696f6e657320736f6e20646966756e646964617320656e747265206c6f73207573756172696f73207920706f72206c6f2067656e6572616c20656d7069657a616e20612073657220636f6e6669726d6164617320706f72206c612072656420656e206c6f73203130206d696e75746f73207369677569656e74657320612074726176266561637574653b7320646520756e2070726f6365736f206c6c616d61646f266e6273703b6d696e6572266961637574653b612e3c2f703e0d0a0d0a3c68323e50726f636573616d69656e746f266e6273703b2d206d696e6572266961637574653b613c2f68323e0d0a0d0a3c70207374796c653d22746578742d616c69676e3a6a757374696679223e4c61206d696e6572266961637574653b6120657320756e266e6273703b3c7374726f6e673e73697374656d6120646520636f6e73656e736f20646973747269627569646f3c2f7374726f6e673e266e6273703b717565207365207574696c697a612070617261266e6273703b636f6e6669726d6172266e6273703b6c6173207472616e73616363696f6e65732070656e6469656e74657320612073657220696e636c756964617320656e206c6120636164656e6120646520626c6f717565732e20486163652063756d706c697220756e206f7264656e2063726f6e6f6c266f61637574653b6769636f20656e206c6120636164656e6120646520626c6f717565732c2070726f74656765206c61206e65757472616c69646164206465206c61207265642079207065726d69746520756e206163756572646520656e74726520746f646f73206c6f732065717569706f7320736f62726520656c2065737461646f2064656c2073697374656d612e205061726120636f6e6669726d6172206c6173207472616e73616363696f6e65732c206465626572266161637574653b6e2073657220656d7061636164617320e2808be2808b656e20756e266e6273703b626c6f717565266e6273703b71756520736520616a75737465206120657374726963746173206e6f726d6173206465206369667261646f20792071756520736572266161637574653b207665726966696361646f20706f72206c61207265642e204573746173206e6f726d617320696d706964656e20717565206375616c717569657220626c6f71756520616e746572696f72207365206d6f646966697175652c207961207175652068616365726c6f20696e76616c69646172266961637574653b6120746f646f73206c6f7320626c6f71756573207369677569656e7465732e204c61206d696e6572266961637574653b612074616d6269266561637574653b6e206372656120656c206571756976616c656e7465206120756e61206c6f746572266961637574653b6120636f6d70657469746976612071756520696d7069646520717565206375616c717569657220706572736f6e612070756564612066266161637574653b63696c6d656e74652061266e74696c64653b61646972206e7565766f7320626c6f7175657320636f6e73656375746976616d656e746520656e206c6120636164656e6120646520626c6f717565732e2044652065737461206d616e6572612c206e696e67756e6120706572736f6e6120707565646520636f6e74726f6c6172206c6f2071756520657374266161637574653b20696e636c7569646f20656e206c6120636164656e6120646520626c6f71756573206f207265656d706c617a617220706172746573206465206c6120636164656e6120646520626c6f717565732070617261207265766572746972207375732070726f70696f7320676173746f732e3c2f703e0d0a0d0a3c68323e266971756573743b204861737461207175266561637574653b2070756e746f20657374266161637574653b732064697370756573746f206120646573637562726972206d266161637574653b73203f3c2f68323e0d0a0d0a3c70207374796c653d22746578742d616c69676e3a6a757374696679223e4573746f2065732073266f61637574653b6c6f20756e20726573756d656e206d7579206272657665207920636f6e6369736f2064656c2073697374656d612e205369207175696572657320636f6e6f636572206d6173206c6f7320646574616c6c65732c20707565646573206c65657220656c266e6273703b3c6120687265663d2268747470733a2f2f626974636f696e2e6f72672f626974636f696e5f65735f6c6174616d2e70646622207374796c653d22636f6c6f723a207267622834342c203131312c20313733293b20746578742d6465636f726174696f6e3a206e6f6e653b223e617274266961637574653b63756c6f206f726967696e616c3c2f613e266e6273703b71756520646573637269626520656c2064697365266e74696c64653b6f2064656c2073697374656d612c2079206578706c6f72617220656c266e6273703b57696b6920646520426974636f696e2e3c2f703e0d0a0d0a3c70207374796c653d22746578742d616c69676e3a6a757374696679223e266e6273703b3c2f703e0d0a0d0a3c70207374796c653d22746578742d616c69676e3a6a757374696679223e3c656d3e536f757263653a203c6120687265663d22687474703a2f2f7777772e626974636f696e2e6f72672f6573223e2671756f743b7777772e626974636f696e2e6f72672671756f743b3c2f613e3c2f656d3e3c2f703e0d0a),
(36, 'trading-bitcoins', 'How to Trade Bitcoins', '¿Como comprar y vender bitcoins?', 0x3c703e4f6e636520796f752068617665207375636365737366756c6c792066756e64656420796f7572206163636f756e74207769746820466961742043757272656e637920616e642f6f7220426974636f696e20796f752063616e2061636365737320746869732066656174757265206279207669736974696e6720746865203c6120687265663d22687474703a2f2f7777772e3162746378652e636f6d2f6275792d73656c6c2e70687022207461726765743d225f626c616e6b223e6275792f73656c6c20706167653c2f613e2e205468657265206172652074776f207479706573206f66206f72646572733a3c2f703e0d0a0d0a3c756c3e0d0a093c6c693e427579204f7264657220286f72202671756f743b4269642671756f743b293a20416e206f7264657220746f2065786368616e676520466961742043757272656e637920666f7220426974636f696e2e3c2f6c693e0d0a093c6c693e53656c6c204f7264657220286f72202671756f743b41736b2671756f743b293a20416e206f7264657220746f2065786368616e676520426974636f696e20666f7220466961742043757272656e63792e3c2f6c693e0d0a3c2f756c3e0d0a0d0a3c703e496e20626f74682063617365732c20796f75206d75737420656e7465722074686520616d6f756e74206f6620626974636f696e7320746f2073656c6c206f722062757920616e642073656c6563742074686520466961742043757272656e637920746f20726563656976652f73656c6c2e205768656e20796f7520636c69636b2074686520627574746f6e20746f20706c61636520746865206f726465722c20796f752077696c6c2062652073686f776e20612073756d6d617279206f6620796f7572206f726465722e20596f752063616e207468656e2064656369646520746f20636f6e6669726d206f722072657475726e20746f20746865206f7264657220706167652e3c2f703e0d0a0d0a3c703e3c6272202f3e0d0a5768656e20746865203c7374726f6e673e6275792f73656c6c206174206d61726b6574207072696365203c2f7374726f6e673e69732073656c65637465642c205b65786368616e67655f6e616d655d2077696c6c206175746f6d61746963616c6c792061646a75737420796f7572206f7264657220707269636520746f20746865207072657661696c696e67206d61726b657420707269636520617320697420666c75637475617465732e20546869732077696c6c20626520646f6e652065766572792035206d696e757465732e3c2f703e0d0a, 0x3c703e556e612076657a20717565206861206361726761646f20666f6e646f732061207375206375656e746120656e206d6f6e6564612066696475636961726961206f20426974636f696e2c20706f6472266161637574653b20636f6d70726172206f2076656e64657220626974636f696e73206163636573616e646f206c612070266161637574653b67696e61206465203c6120687265663d22687474703a2f2f7777772e3162746378652e636f6d2f6275792d73656c6c2e706870223e636f6d707261722f76656e6465723c2f613e2e2053652070756564656e207265616c697a617220646f73206f7065726163696f6e657320646520636f6d70726176656e74613a3c2f703e0d0a0d0a3c756c3e0d0a093c6c693e264f61637574653b7264656e20646520636f6d7072613a20556e6120266f61637574653b7264656e207061726120696e74657263616d62696172206d6f6e656461206669647563696172696120706f7220426974636f696e2e3c2f6c693e0d0a093c6c693e264f61637574653b7264656e2064652076656e74613a20556e6120266f61637574653b7264656e207061726120696e74657263616d6269617220426974636f696e20706f72206d6f6e65646120666964756369617269612e3c2f6c693e0d0a3c2f756c3e0d0a0d0a3c703e496e206c6f7320646f73206361736f732c206465626520696e677265736172206c612063616e746964616420646520626974636f696e732071756520646573656120636f6d70726172206f2076656e64657220792073656c656363696f6e6172206c61206d6f6e6564612066696475636961726120717565206465736561207574696c697a61722e204375616e646f20696e74656e746120696e677265736172206c6120266f61637574653b7264656e2c207365206c65206d6f7374726172266161637574653b20756e20726573267561637574653b6d656e20646520737520266f61637574653b7264656e2079206c61206f706369266f61637574653b6e20646520636f6e6669726d6172206f2072656772657361722061206c612070266161637574653b67696e6120616e746572696f7220706172612063616e63656c61722e3c2f703e0d0a0d0a3c703e4375616e646f203c7374726f6e673e636f6d707261722f76656e64657220612070726563696f206465206d65726361646f3c2f7374726f6e673e20657374266161637574653b2073656c656363696f6e61646f2c205b65786368616e67655f6e616d655d20616a7573746172266161637574653b206175746f6d266161637574653b746963616d656e746520656c2070726563696f20646520737520266f61637574653b7264656e20616c2070726563696f206465206d65726361646f20636164612035206d696e75746f73206d69656e7472617320266561637574653b73746520666c75637475652e3c2f703e0d0a),
(37, 'how-to-register', 'How to Register', 'Cómo registrarse', 0x3c703e546f2073746172742074726164696e6720626974636f696e73206f6e205b65786368616e67655f6e616d655d2c20796f75206d757374206669727374206861766520612076616c6964206163636f756e742077697468203c6120687265663d22687474703a2f2f7777772e63727970746f6361706974616c2e636f2f223e43727970746f204361706974616c20436f72702e203c2f613e28434343292e20546869732077696c6c20616c6c6f7720796f7520746f2066756e6420616e642077697468647261772066726f6d20796f7572205b65786368616e67655f6e616d655d206163636f756e74207573696e67206f76657220333020646966666572656e7420466961742063757272656e636965732e3c2f703e0d0a0d0a3c703e416674657220796f7520686176652072656769737465726564206f6e207468656972207369746520616e642070617373656420616c6c20746865697220766572696669636174696f6e2c20796f752063616e20726567697374657220666f722061206e6577206163636f756e743a3c2f703e0d0a0d0a3c756c3e0d0a093c6c693e506c6561736520766973697420746865203c6120687265663d2272656769737465722e706870223e726567697374726174696f6e3c2f613e20706167652e3c2f6c693e0d0a093c6c693e596f752077696c6c2062652074616b656e20746f2061207061676520776865726520796f752063616e2073746172742074686520726567697374726174696f6e2070726f636573732e3c2f6c693e0d0a093c6c693e456e74657220616c6c2074686520726571756972656420696e666f726d6174696f6e2e3c2f6c693e0d0a093c6c693e456e74657220612076616c696420656d61696c2061646472657373207468617420796f752063616e206163636573732e3c2f6c693e0d0a093c6c693e4f6e636520796f75206861766520656e746572656420616c6c20746865207265717569726564206669656c64732c20636c69636b202671756f743b52656769737465722671756f743b2e266e6273703b416e20656d61696c2077696c6c2062652073656e7420746f2074686520656d61696c2061646472657373207468617420796f752070726f766964656420636f6e7461696e696e67206120757365726e616d6520616e6420612074656d706f726172792070617373776f72642e20506c65617365206368616e676520746869732070617373776f7264207768656e2070726f6d70746564206f6e20796f7572206669727374206c6f67696e2e3c2f6c693e0d0a3c2f756c3e0d0a, 0x3c703e5061726120636f6d656e7a6172206120636f6d7072617220792076656e64657220626974636f696e7320656e205b65786368616e67655f6e616d655d2c207072696d65726f2074656e6472266161637574653b20717565207265676973747261727365207061726120756e61206375656e746120636f6e2043727970746f204361706974616c20436f72702028434343292e20264561637574653b73746f206c65207065726d69746972266161637574653b206361726761722079207265746972617220666f6e646f73206465207375206375656e7461205b65786368616e67655f6e616d655d20656e206d266161637574653b73206465203330206d6f6e65646173206669647563696172696173206469666572656e7465732e3c2f703e0d0a0d0a3c703e556e612076657a20717565207365206861207265676973747261646f20636f6e2043434320792070617361646f20746f646f7320737573207061736f732c20736520707565646520726567697374726172207061726120756e61206375656e7461206e756576613a3c2f703e0d0a0d0a3c756c3e0d0a093c6c693e506f72206661766f722c20766973697465206c61203c6120687265663d2272656769737465722e706870223e70266161637574653b67696e6120646520726567697374726f3c2f613e2e3c2f6c693e0d0a093c6c693e557374656420736572266161637574653b206c6c657661646f206120756e612070266161637574653b67696e6120646f6e646520736520707565646520696e696369617220656c2070726f6365736f20646520726567697374726f2e3c2f6c693e0d0a093c6c693e496e677265736520746f6461206c6120696e666f726d616369266f61637574653b6e207265717565726964612e3c2f6c693e0d0a093c6c693e496e74726f64757a636120756e612064697265636369266f61637574653b6e20646520636f7272656f20656c65637472266f61637574653b6e69636f2076266161637574653b6c69646120616c20707565646120616363656465722e3c2f6c693e0d0a093c6c693e556e612076657a20717565206861796120696e74726f64756369646f20746f646f73206c6f732063616d706f73206e656365736172696f732c206861676120636c696320656e202671756f743b52656769737472617273652671756f743b2e20556e20636f7272656f20656c65637472266f61637574653b6e69636f20736572266161637574653b20656e766961646f2061206c612064697265636369266f61637574653b6e20646520636f7272656f20656c65637472266f61637574653b6e69636f207175652075737465642070726f706f7263696f6e266f61637574653b20636f6e20756e206e6f6d627265206465207573756172696f207920756e6120636f6e7472617365266e74696c64653b612074656d706f72616c2e20506f72206661766f722c2063616d626965206573746120636f6e7472617365266e74696c64653b61206375616e646f207365206c6520736f6c696369746520656e207375207072696d657220696e6963696f2064652073657369266f61637574653b6e2e3c2f6c693e0d0a3c2f756c3e0d0a),
(46, 'logged-out', 'You have been securely logged out...', 'Usted ha salido de su cuenta de manera segura...', 0x3c703e506c6561736520636c69636b203c6120687265663d226c6f67696e2e706870223e686572653c2f613e20746f206c6f6720696e20616761696e206f72203c6120687265663d22696e6465782e706870223e686572653c2f613e20746f20676f20746f2074686520686f6d65706167652e3c2f703e0d0a, 0x3c703e506f72206661766f722070756c7365203c6120687265663d226c6f67696e2e706870223e617175266961637574653b3c2f613e207061726120696e677265736172206120756e61206375656e7461206f203c6120687265663d22696e6465782e706870223e617175266961637574653b3c2f613e20706172612069722061206c612070266161637574653b67696e6120646520696e6963696f2e3c2f703e0d0a),
(38, 'fee-schedule', 'Fee Schedule', 'Tarifas', 0x3c703e3c7370616e207374796c653d22636f6c6f723a23464630303030223e2a2a2053616d706c6520466565205363686564756c65202a2a3c2f7370616e3e3c2f703e0d0a0d0a3c703e54686520666f6c6c6f77696e672069732074686520636f6d6d6973696f6e20706572207472616465206f6e205b65786368616e67655f6e616d655d2e20596f757220666565206c6576656c2069732064657465726d696e656420627920796f7572206d6f6e74686c792074726164696e6720766f6c756d6520617320666f6c6c6f77733a3c2f703e0d0a, 0x3c703e3c7370616e207374796c653d22636f6c6f723a23464630303030223e2a2a2054617269666173206465206d75657374726120736f6c616d656e7465202a2a3c2f7370616e3e3c2f703e0d0a0d0a3c703e4120636f6e74696e75616369266f61637574653b6e206c6173207461726966617320706f72206f706572616369266f61637574653b6e20646520636f6d70726176656e746120656e205b65786368616e67655f6e616d655d2e205375206e6976656c206465207461726966612065732064657465726d696e61646120706f7220737520766f6c267561637574653b6d656e20646520636f6d70726176656e7461206d656e7375616c3a3c2f703e0d0a),
(39, 'contact', 'Contact [exchange_name]', 'Contactar a [exchange_name]', 0x3c703e466f722067656e6572616c20696e717569726965732c20796f75206d617920636f6e746163742075732062792066696c6c696e67206f75742074686520666f6c6c6f77696e6720666f726d2e20466f7220737570706f72742077697468207573696e672074686520736974652c20706c65617365207669736974206f7572203c6120687265663d2268656c702e706870223e737570706f727420706f7274616c3c2f613e2e3c2f703e0d0a, 0x3c703e5061726120636f6e73756c7461732067656e6572616c65732c206e6f7320707565646520636f6e746163746172206c6c656e616e646f20656c207369677569656e746520666f726d756c6172696f2e205061726120736f706f7274652074266561637574653b636e69636f2c20706f72206661766f7220766973697465206e75657374726f203c6120687265663d2268656c702e706870223e706f7274616c20646520736f706f7274653c2f613e2e3c2f703e0d0a),
(40, 'contact-small', '[exchange_name]', '[exchange_name]', 0x3c703e436f6d70616e7920496e666f20486572653c2f703e0d0a, 0x3c703e436f6d70616e7920496e666f20486572653c2f703e0d0a),
(41, 'bank-accounts', 'Crypto Capital Accounts', 'Cuentas Crypto Capital', 0x3c703e496e206f7264657220746f206465706f736974206f7220776974686472617720666961742063757272656e6379202863757272656e63696573206f74686572207468616e20426974636f696e292066726f6d20796f7572205b65786368616e67655f6e616d655d206163636f756e742c20796f75206d757374206861766520616e206578697374696e67206163636f756e742077697468203c6120687265663d22687474703a2f2f7777772e63727970746f6361706974616c2e636f2f223e43727970746f204361706974616c3c2f613e2e20466f72206d6f726520696e666f726d6174696f6e2c20706c6561736520726566657220746f206f7572203c6120687265663d2268747470733a2f2f3162746378652e66726573686465736b2e636f6d2f737570706f72742f736f6c7574696f6e732f61727469636c65732f313030303032323233332d66756e64696e672d796f75722d316274637865223e68656c7020706f7274616c3c2f613e2e3c2f703e0d0a, 0x3c703e50617261206465706f7369746172206f2072657469726172206d6f6e65646173206669647563696172617320286c6173206d6f6e6564617320747261646963696f6e616c65732066266961637574653b736963617329206465736465207375206375656e7461205b65786368616e67655f6e616d655d2c206465626572266161637574653b2074656e657220756e61206375656e7461206578697374656e746520636f6e203c6120687265663d22687474703a2f2f7777772e63727970746f6361706974616c2e636f2f223e4372792e70746f204361706974616c3c2f613e2e2050617261206d266161637574653b7320696e666f726d616369266f61637574653b6e2c20706f72206661766f72207265666572697273652061206e75657374726f203c6120687265663d2268747470733a2f2f3162746378652e66726573686465736b2e636f6d2f737570706f72742f736f6c7574696f6e732f61727469636c65732f313030303032323233332d66756e64696e672d796f75722d316274637865223e706f7274616c2064652061797564613c2f613e2e3c2f703e0d0a),
(42, 'bank-accounts-add', 'Crypto Capital Accounts Add', 'Cuentas Crypto Capital', 0x3c703e506c6561736520656e74657220796f75722043727970746f204361706974616c206163636f756e74206e756d6265722062656c6f772e20596f752063616e206f627461696e2074686973206e756d62657220627920636c69636b696e67206f6e202671756f743b4163636f756e742053756d6d6172792671756f743b2066726f6d20746865206c6566742d68616e64206d656e75206f6620796f75722043727970746f204361706974616c206163636f756e742e3c2f703e0d0a0d0a3c703e3c7374726f6e673e506c65617365206e6f74653c2f7374726f6e673e2c20697420697320696d706f7274616e7420746f2073656c6563742074686520636f72726563742063757272656e637920666f7220746865206163636f756e742e204661696c696e6720746f20646f20736f2077696c6c20726573756c7420696e206120636f6e76657273696f6e20666565207768656e206465706f736974696e6720666961742e3c2f703e0d0a, 0x3c703e506f72206661766f7220696e6772657365207375206e267561637574653b6d65726f206465206375656e74612043727970746f204361706974616c2e205075656465206f6274656e65722065737465206e267561637574653b6d65726f2070756c73616e646f20656e202671756f743b4163636f756e742053756d6d6172792671756f743b20656e20656c206d656e267561637574653b2064656c206c61646f20697a7175696572646f20656e207375206375656e74612043727970746f204361706974616c2e3c2f703e0d0a0d0a3c703e3c7374726f6e673e506f72206661766f72206e6f7461723c2f7374726f6e673e2c20657320696d706f7274616e7465206573706563696669636172206c61206d6f6e65646120636f7272656374612070617261206c61206375656e74612e20506f72206c6f20636f6e74726172696f2c20736520696e637572726972266161637574653b6e20636f73746f7320646520636f6e7665727369266f61637574653b6e20616c206465706f73697461722e3c2f703e0d0a),
(43, 'bitcoin-addresses', 'Bitcoin Addresses', 'Bitcoin Addresses', 0x3c703e5468657365206172652074686520616464726573736573207468617420796f752063616e2075736520746f207265636569766520426974636f696e20746f20796f7572205b65786368616e67655f6e616d655d206163636f756e742e20596f752063616e2067656e65726174652061206e6577206164647265737320657665727920323420686f75727320616e642063616e206861766520757020746f2031302061646472657373657320617420612074696d652e3c2f703e0d0a, 0x3c703e457374617320736f6e206c617320646972656363696f6e65732071756520707565646573207574696c697a61722070617261207265636962697220626974636f696e732061207475206375656e7461205b65786368616e67655f6e616d655d2e2050756564652067656e6572617220756e61206e75657661206361646120323420686f72617320792070756564652074656e657220686173746120313020646972656363696f6e65732061206c612076657a2e3c2f703e0d0a),
(44, 'deposit-bank-instructions', 'Bank Deposit Instructions', 'Instrucciones para depósito bancario', 0x3c703e506c65617365206c6f67696e20746f20796f75722043727970746f204361706974616c206163636f756e74203c7374726f6e673e5b636c69656e745f6163636f756e745d3c2f7374726f6e673e20616e64206372656174652061206e6577207472616e7366657220746f206163636f756e74206e756d626572203c7374726f6e673e5b657363726f775f6163636f756e745d3c2f7374726f6e673e2c2077697468206163636f756e74206e616d65203c7374726f6e673e5b657363726f775f6e616d655d3c2f7374726f6e673e2e2046696c6c206f7574202671756f743b3c7374726f6e673e43727970746f204361706974616c3c2f7374726f6e673e2671756f743b20756e646572203c656d3e42656e65666963696172792042616e6b3c2f656d3e2e204f6e636520746865207472616e7366657220697320636f6d706c6574652c20796f7572205b65786368616e67655f6e616d655d206163636f756e742077696c6c2062652063726564697465642e3c2f703e0d0a, 0x3c703e506f72206661766f7220696e67726573652061207375206375656e74613c7374726f6e673e205b636c69656e745f6163636f756e745d3c2f7374726f6e673e20656e2043727970746f204361706974616c20792070726f6772616d6520756e61206e75657661207472616e73666572656e6369612061206e267561637574653b6d65726f206465206375656e7461203c7374726f6e673e5b657363726f775f6163636f756e745d3c2f7374726f6e673e2c20636f6e206e6f6d627265206465206375656e74613c7374726f6e673e205b657363726f775f6e616d655d3c2f7374726f6e673e2e20496e6772657365202671756f743b3c7374726f6e673e43727970746f204361706974616c3c2f7374726f6e673e2671756f743b2062616a6f203c656d3e42656e65666963696172792042616e6b3c2f656d3e2e20556e612076657a20636f6d706c657461206c61207472616e73666572656e6369612c207365206c6520616372656469746172266161637574653b2061207375206375656e7461205b65786368616e67655f6e616d655d2e3c2f703e0d0a),
(45, 'deposit-no-bank', 'No Bank Accounts', 'No hay cuentas de banco', 0x3c703e546865726520617265206e6f2062616e6b206163636f756e74732061736f636961746564207769746820796f75722070726f66696c652e3c2f703e0d0a, 0x3c703e4e6f20686179206375656e7461732064652062616e636f206166696c696164617320612073752070657266696c2e3c2f703e0d0a),
(47, 'terms', 'Terms and Conditions of Use', 'Términos y condiciones de uso', '', '');
INSERT INTO `content` (`id`, `url`, `title_en`, `title_es`, `content_en`, `content_es`) VALUES
(48, 'securing-account', 'Securing Your Account', '¿Cómo asegurar su cuenta?', 0x3c703e42792064656661756c742c206e6577206163636f756e7473206172652073657420757020746f2075736520656d61696c20766572696669636174696f6e20666f7220616c6c2073656e736974697665206f7065726174696f6e732c2073756368206173207769746864726177616c7320616e642073657474696e6773206368616e6765732e204576656e20736f2c207765207265636f6d6d656e6420636f6e6669677572696e6720796f75722063656c6c70686f6e6520746f2070726f766964652074776f2d666163746f722061757468656e7469636174696f6e20666f7220796f7572206163636f756e742e3c2f703e0d0a0d0a3c703e54776f2d666163746f722061757468656e7469636174696f6e2063616e20626520736574207570206279207669736974696e6720746865203c6120687265663d22687474703a2f2f7777772e3162746378652e636f6d2f73656375726974792e70687022207461726765743d225f626c616e6b223e736563757269747920706167653c2f613e206f6e20796f7572206163636f756e7420616e6420666f6c6c6f77696e672074686520696e737472756374696f6e732073686f776e2e2049742077696c6c2070726f7669646520616e206578747261206c61796572206f6620736563757269747920666f7220796f7572206163636f756e742e3c2f703e0d0a0d0a3c703e4f757220746563686e6963616c207465616d206174205b65786368616e67655f6e616d655d20697320636f6e74616e746c79206d6f6e69746f72696e6720746865207365637572697479206f66206f757220637573746f6d657273262333393b206163636f756e747320746f20656e73757265207468652068696768657374207374616e64617264732061726520696d706c656d656e7465642e2049662c20617420616e792074696d652c20796f752062656c69657665207468617420796f7572206163636f756e7420686173206265656e20636f6d70726f6d697365642c20706c65617365206c6f636b20796f7572206163636f756e74206279207669736974696e6720746865203c6120687265663d22687474703a2f2f7777772e3162746378652e636f6d2f73657474696e67732e70687022207461726765743d225f626c616e6b223e73657474696e677320706167653c2f613e20616e6420636c69636b696e67206f6e20746865202671756f743b4c6f636b204d79204163636f756e742671756f743b20627574746f6e2e20506c65617365206e6f74696679206f757220746563686e6963616c207465616d206f662074686520736974756174696f6e2e20596f752063616e206c6174657220756e6c6f636b20796f7572206163636f756e74206f6e20746861742073616d652070616765206f6e636520736563757269747920686173206265656e20636f6e6669726d65642e3c2f703e0d0a, 0x3c703e506f72206465666563746f2c206c6173206375656e74617320657374266161637574653b6e20636f6e6669677572616461732070617261207574696c697a61722076657269666963616369266f61637574653b6e20706f7220636f7272656f20656c65637472266f61637574653b6e69636f207061726120746f646173206c6173206f7065726163696f6e65732073656e7369626c65732c20636f6d6f206c6f732072657469726f7320792063616d62696f7320646520636f6e6669677572616369266f61637574653b6e2e2041756e206173266961637574653b2c207365207265636f6d69656e646120636f6e6669677572617220656c2074656c266561637574653b666f6e6f206d266f61637574653b76696c20706172612070726f706f7263696f6e6172206c6120617574656e746963616369266f61637574653b6e20646520646f7320666163746f7265732070617261207375206375656e74612e3c6272202f3e0d0a3c6272202f3e0d0a417574656e746963616369266f61637574653b6e20646520646f7320666163746f72657320736520707565646520636f6e66696775726172207669736974616e646f206c61203c6120687265663d22687474703a2f2f7777772e3162746378652e636f6d2f73656375726974792e706870223e70266161637574653b67696e61206465207365677572696461643c2f613e206465207375206375656e74612079207369677569656e646f206c617320696e737472756363696f6e657320717565207365206d7565737472616e2e204573746f2070726f706f7263696f6e6172266161637574653b20756e206e6976656c2061646963696f6e616c206465207365677572696461642070617261207375206375656e74612e3c6272202f3e0d0a3c6272202f3e0d0a4e75657374726f2065717569706f2074266561637574653b636e69636f206465205b65786368616e67655f6e616d655d206d6f6e69746f72656120636f6e7374616e74656d656e7465206c6120736567757269646164206465206c6173206375656e746173206465206e75657374726f7320636c69656e7465732070617261206173656775726172206c6f73206d266161637574653b7320616c746f7320657374266161637574653b6e646172657320646520656a6563756369266f61637574653b6e2e2053692c20656e206375616c7175696572206d6f6d656e746f2c207573746564206372656520717565207375206375656e7461206861207369646f20636f6d70726f6d65746964612c20706f72206661766f7220626c6f71756565207375206375656e7461207669736974616e646f206c612070266161637574653b67696e6120646520636f6e6669677572616369266f61637574653b6e20792068616369656e646f20636c696320656e20656c20626f74266f61637574653b6e202671756f743b426c6f7175656172206d69206375656e74612671756f743b2e204c7565676f20636f6e74616374652061206e75657374726f2065717569706f20646520736f706f7274652070617261207265706f72746172206c612073697475616369266f61637574653b6e2e204d266161637574653b732074617264652c20706f6472266161637574653b20646573626c6f7175656172207375206375656e746120656e20657361206d69736d612070266161637574653b67696e6120756e612076657a2071756520736520736570612071756520657374266161637574653b2073656775726f2e3c2f703e0d0a),
(49, 'funding-account', 'Funding Your Account', '¿Cómo obtener fondos?', 0x3c703e3c7370616e207374796c653d22666f6e742d66616d696c793a68656c7665746963612c73616e732d73657269663b20666f6e742d73697a653a31307074223e3c7374726f6e673e466961742043757272656e63792046756e64696e673a3c2f7374726f6e673e3c2f7370616e3e3c2f703e0d0a0d0a3c703e496e206f7264657220746f2066756e6420796f7572206163636f756e74207769746820466961742063757272656e637920796f75206d757374206f70656e20616e206163636f756e742077697468203c6120687265663d22687474703a2f2f7777772e63727970746f6361706974616c2e636f2f22207374796c653d226261636b67726f756e642d636f6c6f723a20726762283235352c203235352c20323535293b223e43727970746f204361706974616c20436f72703c2f613e2028434343292e20546869732077696c6c20616c6c6f7720796f7520746f2066756e6420796f7572206163636f756e74732077697468206d6f7374206d616a6f722063757272656e636965732e3c2f703e0d0a0d0a3c703e416674657220796f7520686176652073657420757020796f757220434343206163636f756e7420616e64207472616e736665727265642066756e647320696e746f2069742c20796f752063616e206173736f6369617465206974207769746820796f757220314254435845206163636f756e74206279207669736974696e6720746865203c6120687265663d22687474703a2f2f7777772e3162746378652e636f6d2f62616e6b2d6163636f756e74732e70687022207461726765743d225f626c616e6b223e62616e6b206163636f756e74733c2f613e207061676520696e20796f7572206163636f756e7420616e6420666f6c6c6f77696e672074686520696e737472756374696f6e732074686572652e20506c65617365206265207375726520746f20656e74657220746865206e756d626572206f6620796f757220434343206163636f756e7420636f72726563746c792e204661696c696e6720746f20646f20736f2063616e206c65616420746f206c6f73696e672066756e647320696e207468652073797374656d2e3c2f703e0d0a0d0a3c703e4f6e636520796f75206861766520666f6c6c6f7765642074686573652073746570732c20796f752063616e2066756e6420796f757220314254435845206163636f756e74206279207669736974696e6720746865203c6120687265663d22687474703a2f2f7777772e3162746378652e636f6d2f6465706f7369742e70687022207461726765743d225f626c616e6b223e6465706f73697420706167653c2f613e20616e6420666f6c6c6f77696e672074686520696e737472756374696f6e732074686572652e3c2f703e0d0a0d0a3c703e266e6273703b3c2f703e0d0a0d0a3c703e3c7370616e207374796c653d22666f6e742d66616d696c793a68656c7665746963612c73616e732d73657269663b20666f6e742d73697a653a31307074223e3c7374726f6e673e426974636f696e2046756e64696e673a3c2f7374726f6e673e3c2f7370616e3e3c2f703e0d0a0d0a3c703e596f752063616e2066756e6420796f7572206163636f756e74207769746820426974636f696e206279207669736974696e6720746865203c6120687265663d22687474703a2f2f7777772e3162746378652e636f6d2f6465706f7369742e70687022207461726765743d225f626c616e6b223e6465706f73697420706167653c2f613e20616e6420666f6c6c6f77696e672074686520696e737472756374696f6e732e20596f752063616e20616c736f206d616e61676520616e64206f627461696e20616c7465726e617469766520426974636f696e2061646472657373657320666f7220796f7572206163636f756e74206279207669736974696e6720746865203c6120687265663d22687474703a2f2f7777772e3162746378652e636f6d2f626974636f696e2d6164647265737365732e70687022207461726765743d225f626c616e6b223e626974636f696e206164647265737365733c2f613e20706167652e20596f752063616e206f627461696e20757020746f2031302061646472657373657320617420612074696d652c20686f77657665722c20796f75206d6179206f6e6c79206f627461696e206f6e65206e657720616464726573737320657665727920323420686f7572732e3c2f703e0d0a, ''),
(50, 'withdrawing-account', 'Withdrawing Funds', '¿Cómo retirar fondos?', 0x3c703e3c7374726f6e673e5769746864726177696e6720426974636f696e3c2f7374726f6e673e3c2f703e0d0a0d0a3c703e546f20776974686472617720426974636f696e2066726f6d20796f7572206163636f756e742c20706c6561736520766973697420746865203c6120687265663d22687474703a2f2f7777772e3162746378652e636f6d2f77697468647261772e70687022207461726765743d225f626c616e6b223e7769746864726177616c20706167653c2f613e2e20456e7465722074686520426974636f696e206164647265737320746f20776869636820796f7520776f756c64206c696b6520746f2073656e6420796f757220626974636f696e732c2061732077656c6c2061732074686520616d6f756e7420796f7520776f756c64206c696b6520746f2073656e642e20506c65617365203c7374726f6e673e6265206361726566756c3c2f7374726f6e673e20746f20656e746572207468652065786163742073657175656e6365206f66206368617261637465727320666f722074686520426974636f696e20616464726573732e204f7274686572776973652c20796f757220626974636f696e732077696c6c206265206c6f73742e20446570656e64696e67206f6e20796f75722073657474696e67732c20796f75206d61792062652061736b656420746f2061757468656e74696361746520796f7572207769746864726177616c2062792074776f2d666163746f722061757468656e7469636174696f6e206f7220656d61696c2e3c2f703e0d0a0d0a3c703e266e6273703b3c2f703e0d0a0d0a3c703e3c7374726f6e673e5769746864726177696e6720466961742043757272656e63793c2f7374726f6e673e3c2f703e0d0a0d0a3c703e506c65617365206e6f74653a20612076616c69642043727970746f204361706974616c206163636f756e74206d757374206265206166696c6961746564207769746820796f7572206163636f756e742e20546f207769746864726177204669617420796f7572206163636f756e742c20706c6561736520766973697420746865203c6120687265663d22687474703a2f2f7777772e3162746378652e636f6d2f77697468647261772e70687022207461726765743d225f626c616e6b223e7769746864726177616c20706167653c2f613e2e2053656c656374207468652043727970746f204361706974616c206163636f756e7420746f20776869636820796f7520776f756c64206c696b6520746f20776974686472617720796f75722066756e64732c20656e7465722074686520616d6f756e7420746f20776974686472617720616e6420636c69636b20746865202671756f743b57697468647261772043757272656e63792671756f743b20627574746f6e2e20506c65617365206d616b652073757265207468617420746865206163636f756e742069732064656e6f6d696e6174656420696e207468652073616d652063757272656e637920617320746865206f6e6520796f7520617265207769746864726177696e67206f7220636f6e76657273696f6e2066656573206d617920626520696e6375727265642e3c2f703e0d0a0d0a3c703e446570656e64696e67206f6e20796f75722073657474696e67732c20796f75206d61792062652061736b656420746f2061757468656e74696361746520796f7572207769746864726177616c2062792074776f2d666163746f722061757468656e7469636174696f6e206f7220656d61696c2e3c2f703e0d0a0d0a3c703e266e6273703b3c2f703e0d0a, 0x3c703e3c7374726f6e673e52657469726f20646520426974636f696e3c2f7374726f6e673e3c6272202f3e0d0a3c6272202f3e0d0a50617261207265746972617220426974636f696e206465207375206375656e7461202c20706f72206661766f7220766973697465206c612070266161637574653b67696e61203c6120687265663d22687474703a2f2f7777772e3162746378652e636f6d2f77697468647261772e706870223e64652072657469726f3c2f613e2e20496e74726f64757a6361206c612064697265636369266f61637574653b6e20426974636f696e2061206c6120717565206c6520677573746172266961637574653b6120656e766961722073757320626974636f696e732c206173266961637574653b20636f6d6f206c612063616e74696461642071756520646573656120656e766961722e20506f72206661766f722061736567267561637574653b7265736520646520696e677265736172206c612073656375656e6369612065786163746120646520636172616374657265732070617261206c612064697265636369266f61637574653b6e20426974636f696e2e20506f72206c6f20636f6e74726172696f2c20736520706572646572266161637574653b6e206c6f7320626974636f696e7320656e766961646f732e20446570656e6469656e646f206465206c6120636f6e6669677572616369266f61637574653b6e2c207365206c6520657869676972266161637574653b20617574656e74696361722073752072657469726f20706f7220617574656e746963616369266f61637574653b6e20646520646f7320666163746f726573206f20636f7272656f20656c65637472266f61637574653b6e69636f2e3c6272202f3e0d0a3c6272202f3e0d0a3c7374726f6e673e52657469726f206465206d6f6e656461732066696475636961726961733c2f7374726f6e673e3c6272202f3e0d0a3c6272202f3e0d0a4e6f74613a20756e61206375656e74612043727970746f204361706974616c2076266161637574653b6c6964612064656265206573746172207961206166696c6961646120636f6e207375206375656e74612e20506172612072657469726172206d6f6e65646173206669647563696172696173206465207375206375656e74612c20706f72206661766f7220766973697465206c612070266161637574653b67696e61203c6120687265663d22687474703a2f2f7777772e3162746378652e636f6d2f77697468647261772e706870223e64652072657469726f3c2f613e2e2053656c656363696f6e65206c61206375656e74612064652043727970746f204361706974616c2061206c612071756520757374656420646573656120726574697261722073757320666f6e646f732c20696e6772657365206c612063616e7469646164206120726574697261722079206861676120636c696320656e20656c20626f74266f61637574653b6e202671756f743b526574697261722671756f743b2e20506f72206661766f722c2061736567267561637574653b7265736520646520717565206c61206375656e746120657374652064656e6f6d696e61646120656e206c61206d69736d61206d6f6e65646120656e206c612071756520757374656420657374266161637574653b207265746972616e646f206f20706f6472266961637574653b6120696e63757272696e6720636f6d6973696f6e657320706f7220636f6e7665727369266f61637574653b6e206465206d6f6e656461732e3c6272202f3e0d0a3c6272202f3e0d0a446570656e6469656e646f20646520737520636f6e6669677572616369266f61637574653b6e2c207365206c6520706f6472266161637574653b2065786967697220617574656e74696361722073752072657469726f20706f7220617574656e746963616369266f61637574653b6e20646520646f7320666163746f726573206f20636f7272656f20656c65637472266f61637574653b6e69636f2e3c2f703e0d0a),
(53, 'reset-2fa', 'Resetting Two-Factor Authentication', 'Reiniciar autenticación de dos factores', 0x3c703e496620796f752068617665206c6f737420796f75722070686f6e6520616e64206e65656420746f2072657365742074776f2d666163746f722061757468656e7469636174696f6e2c207468652070726f6365737320697320646966666572656e7420646570656e64696e67206f6e207468652061757468656e7469636174696f6e206d6574686f6420796f752063686f736520666f7220796f7572206163636f756e743a3c2f703e0d0a0d0a3c6f6c3e0d0a093c6c693e466f722041757468792c20796f75206e65656420746f207669736974207468656972206f776e203c6120687265663d2268747470733a2f2f7777772e61757468792e636f6d2f70686f6e65732f7265736574223e726573657420706167653c2f613e2e205768656e20796f752066696c6c206f75742074686520726571756972656420696e666f726d6174696f6e2c20796f752077696c6c207265636569766520726573657420696e737472756374696f6e732061742074686520656d61696c20796f752072656769737465726564207768656e20796f7520696e7374616c6c65642074686520617070206f6e20796f75722063656c6c70686f6e652e3c2f6c693e0d0a093c6c693e466f7220476f6f676c652041757468656e74696361746f722c20796f752077696c6c206e65656420746f2075736520746865203c7374726f6e673e73656372657420636f64653c2f7374726f6e673e207468617420796f752077726f746520646f776e207768656e20796f75207365742075702074776f2d666163746f722061757468656e7469636174696f6e2e20456e746572207468652061707020616e64206d616e75616c6c792061646420616e206163636f756e74207573696e6720746861742073656372657420636f64652e3c2f6c693e0d0a093c6c693e496620796f752075736520534d532c207468652072657365742069732068616e646c6564207573696e672041757468792061732077656c6c2e20596f752063616e20726573657420796f757220534d5320766572696669636174696f6e206f6e207468656972266e6273703b3c6120687265663d2268747470733a2f2f7777772e61757468792e636f6d2f70686f6e65732f7265736574223e726573657420706167653c2f613e2e3c2f6c693e0d0a3c2f6f6c3e0d0a, 0x3c703e5369206861207065726469646f207375206d266f61637574653b76696c2079206e65636573697461207265696e6963696172206c6120617574656e746963616369266f61637574653b6e20646520646f7320666163746f7265732c20656c2070726f6365736f206573206469666572656e746520646570656e6469656e646f2064656c206d266561637574653b746f646f20646520617574656e746963616369266f61637574653b6e20717565206573636f6769266f61637574653b206375616e646f2072656769737472266f61637574653b207375206375656e74613a3c2f703e0d0a0d0a3c6f6c3e0d0a093c6c693e506172612061757468792c206573206e656365736172696f2076697369746172207375203c6120687265663d22687474703a2f2f7777772e61757468792e636f6d2f70686f6e65732f7265736574223e70266161637574653b67696e61206465207265696e696369616e6369266f61637574653b6e3c2f613e2e20416c2070726f76656572206c6120696e666f726d616369266f61637574653b6e206e65636573617269612c2072656369626972266161637574653b206c617320696e737472756363696f6e6573206465207265696e696369616369266f61637574653b6e20656e20656c20656d61696c20717565207574696c697a266f61637574653b206375616e646f20696e7374616c266f61637574653b20417574687920656e207375206d266f61637574653b76696c2e3c2f6c693e0d0a093c6c693e5061726120476f6f676c652041757468656e74696361746f722c206e6563657369746172266161637574653b20656c203c7374726f6e673e63266f61637574653b6469676f207365637265746f3c2f7374726f6e673e207175652064656269266f61637574653b206775617264617220616c206d6f6d656e746f20646520726567697374726172207375206375656e746120656e206c612061706c6963616369266f61637574653b6e2e20496e677265736520616c206170702079206167726567756520756e61206375656e7461206d616e75616c6d656e7465207574696c697a616e646f206573652063266f61637574653b6469676f2e3c2f6c693e0d0a093c6c693e5369207574696c697a6120534d532c206c61207265696e696369616369266f61637574653b6e20736520686172266161637574653b20612074726176266561637574653b732064652041757468792074616d6269266561637574653b6e2e2050756564652073656775697220656c2070726f6365736f20656e206c61203c6120687265663d22687474703a2f2f7777772e61757468792e636f6d2f70686f6e65732f7265736574223e70266161637574653b67696e61206465207265696e696369616369266f61637574653b6e3c2f613e2e3c2f6c693e0d0a3c2f6f6c3e0d0a),
(51, 'security-google', 'Verify Google Authenticator', 'Verificar Google Authenticator', 0x3c703e4e6f772069742069732074696d6520746f206f70656e20476f6f676c652041757468656e74696361746f72206f6e20796f75722070686f6e6520616e642063686f6f736520746865206f7074696f6e20746f207365742075702061206e6577206163636f756e742e20506c65617365207363616e2074686520515220636f64652070726f76696465642062656c6f7720746f2073657420757020796f7572203246412c207468656e20656e746572207468652070726f76696465642050494e20696e2074686520626f7820696e646963617465642062656c6f7720746f2070726f7465637420796f7572206163636f756e742e3c2f703e0d0a0d0a3c703e3c7374726f6e673e3c7370616e207374796c653d22636f6c6f723a23464630303030223e2a2a2a2a205645525920494d504f5254414e54202a2a2a2a3c2f7370616e3e3c2f7374726f6e673e3c2f703e0d0a0d0a3c703e506c656173652c203c7374726f6e673e777269746520646f776e207468652073656372657420636f64653c2f7374726f6e673e2070726f76696465642062656c6f772e205468697320697320746865206f6e6c792077617920796f752063616e20726573657420796f757220476f6f676c652041757468656e74696361746f72206163636f756e7420696620796f75206c6f736520796f75722070686f6e652e204f74686572776973652c20796f752077696c6c206265206c6f636b6564206f7574206f6620796f7572206163636f756e742e3c2f703e0d0a, 0x3c703e41686f72612c206162726120476f6f676c652041757468656e74696361746f7220656e207375206d266f61637574653b76696c20792073656c656363696f6e65206c61206f706369266f61637574653b6e2070617261206167726567617220756e61206e75657661206375656e74612e20506f72206661766f7220657363616e266561637574653b6520656c20515220636f646520717565207365206d75657374726120656e20657374612070266161637574653b67696e612064656e74726f20646520476f6f676c652041757468656e74696361746f72207061726120616772656761726c6f2e204c7565676f20696e677265736520656c2050494e20717565206c65206d7565737472612041757468656e74696361746f72207061726120766572696669636172207375206375656e74612e3c2f703e0d0a0d0a3c703e3c7374726f6e673e3c7370616e207374796c653d22636f6c6f723a23464630303030223e2a2a2a2a204d555920494d504f5254414e5445202a2a2a2a3c2f7370616e3e3c2f7374726f6e673e3c2f703e0d0a0d0a3c703e506f72206661766f722c203c7374726f6e673e6573637269626120656c2063266f61637574653b6469676f207365637265746f2079206775266161637574653b7264656c6f20656e20756e206c756761722073656775726f3c2f7374726f6e673e2e204573746f207365207574696c697a6172266161637574653b2070617261207265696e6963696172207375206375656e746120656e20476f6f676c652041757468656e74696361746f72207369207365206578747261766961207375206d6f76696c2e20506f72206c6f20636f6e74726172696f2c206e6f20706f6472266161637574653b20766f6c766572206120696e6772657361722061207375206375656e74612e3c2f703e0d0a),
(52, 'security-setup-google', 'Two-Factor Authentication Setup', 'Configuración de autenticación de dos factores', 0x3c703e596f7572206163636f756e742069732063757272656e746c792073657420757020746f2075736520476f6f676c652041757468656e74696361746f7220666f722074776f2d666163746f722061757468656e7469636174696f6e2e3c2f703e0d0a, 0x3c703e5375206375656e74612061637475616c6d656e74652075736120476f6f676c652041757468656e74696361746f72207061726120617574656e746963616369266f61637574653b6e20646520646f7320666163746f7265732e3c6272202f3e0d0a266e6273703b3c2f703e0d0a),
(54, 'about', 'About 1BTCXE', 'Acerca de 1BTCXE', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `content_files`
--

CREATE TABLE IF NOT EXISTS `content_files` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `f_id` int(10) unsigned NOT NULL,
  `ext` char(4) NOT NULL,
  `dir` varchar(255) NOT NULL,
  `url` text NOT NULL,
  `old_name` varchar(255) NOT NULL,
  `field_name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `f_id` (`f_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `conversions`
--

CREATE TABLE IF NOT EXISTS `conversions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `amount` double(10,2) NOT NULL,
  `currency` int(10) NOT NULL,
  `currency1` int(10) NOT NULL,
  `date` datetime NOT NULL,
  `is_active` enum('Y','N') NOT NULL DEFAULT 'N',
  `amount_received` double(10,2) NOT NULL,
  `amount_needed` double(10,2) NOT NULL,
  `factored` int(10) NOT NULL DEFAULT '0',
  `factored1` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `date` (`date`),
  KEY `is_active` (`is_active`),
  KEY `factored` (`factored`),
  KEY `factored1` (`factored1`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `currencies`
--

CREATE TABLE IF NOT EXISTS `currencies` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `currency` varchar(3) NOT NULL,
  `fa_symbol` varchar(255) NOT NULL,
  `account_number` bigint(20) unsigned NOT NULL,
  `account_name` varchar(255) NOT NULL,
  `is_active` enum('Y','N') NOT NULL DEFAULT 'N',
  `usd_bid` varchar(255) NOT NULL,
  `usd_ask` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `currency` (`currency`),
  KEY `usd_bid` (`usd_bid`),
  KEY `usd_ask` (`usd_ask`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=39 ;

--
-- Dumping data for table `currencies`
--

INSERT INTO `currencies` (`id`, `currency`, `fa_symbol`, `account_number`, `account_name`, `is_active`, `usd_bid`, `usd_ask`) VALUES
(1, 'EUR', '&#8364;', 0, '', 'Y', '', ''),
(2, 'CNY', '&#165;', 0, '', 'Y', '', ''),
(3, 'GBP', '&#163;', 0, '', 'Y', '', ''),
(4, 'JPY', '&#165;', 0, '', 'Y', '', ''),
(5, 'CAD', 'C$', 0, '', 'Y', '', ''),
(6, 'BGN', '&#1083;&#1074;', 0, '', 'Y', '', ''),
(7, 'CZK', '&#75;&#269;', 0, '', 'Y', '', ''),
(8, 'DKK', 'kr', 0, '', 'Y', '', ''),
(9, 'HKD', 'HK$', 0, '', 'Y', '', ''),
(10, 'HRK', 'kn', 0, '', 'Y', '', ''),
(11, 'HUF', 'Ft', 0, '', 'Y', '', ''),
(12, 'ILS', '&#8362;', 0, '', 'Y', '', ''),
(13, 'INR', '&#8377;', 0, '', 'Y', '', ''),
(14, 'LTL', 'Lt', 0, '', 'Y', '', ''),
(15, 'LVL', 'Ls', 0, '', 'Y', '', ''),
(16, 'MXN', '$', 0, '', 'Y', '', ''),
(17, 'NOK', 'kr', 0, '', 'Y', '', ''),
(18, 'NZD', '$', 0, '', 'Y', '', ''),
(19, 'PLN', 'z&#322;', 0, '', 'Y', '', ''),
(20, 'RON', 'lei', 0, '', 'Y', '', ''),
(21, 'RUB', 'py6', 0, '', 'Y', '', ''),
(22, 'SEK', 'kr', 0, '', 'Y', '', ''),
(23, 'SGD', 'S$', 0, '', 'Y', '', ''),
(24, 'THB', '&#3647;', 0, '', 'Y', '', ''),
(25, 'TRY', 'TL', 0, '', 'Y', '', ''),
(26, 'ZAR', 'R', 0, '', 'Y', '', ''),
(27, 'USD', '$', 0, '', 'Y', '', ''),
(28, 'BTC', 'BTC', 0, '', 'Y', '', ''),
(35, 'COP', 'COL$', 0, '', 'N', '', ''),
(36, 'ARS', 'ARS$', 0, '', 'N', '', ''),
(37, 'MUR', 'Rs', 0, '', 'Y', '', ''),
(38, 'TWD', 'NT$', 0, '', 'N', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `current_stats`
--

CREATE TABLE IF NOT EXISTS `current_stats` (
  `id` int(1) unsigned NOT NULL AUTO_INCREMENT,
  `total_btc` bigint(20) unsigned NOT NULL,
  `market_cap` bigint(20) unsigned NOT NULL,
  `trade_volume` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `current_stats`
--

INSERT INTO `current_stats` (`id`, `total_btc`, `market_cap`, `trade_volume`) VALUES
(1, 12679600, 6187644800, 3461648);

-- --------------------------------------------------------

--
-- Table structure for table `daily_reports`
--

CREATE TABLE IF NOT EXISTS `daily_reports` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `date` datetime NOT NULL,
  `total_btc` double(20,8) unsigned NOT NULL,
  `total_fiat_usd` double(20,2) unsigned NOT NULL,
  `open_orders_btc` double(20,8) unsigned NOT NULL,
  `btc_per_user` double(20,8) unsigned NOT NULL,
  `transactions_btc` double(20,8) unsigned NOT NULL,
  `avg_transaction_size_btc` double(20,8) unsigned NOT NULL,
  `transaction_volume_per_user` double(20,8) unsigned NOT NULL,
  `total_fees_btc` double(20,2) unsigned NOT NULL,
  `fees_per_user_btc` double(20,2) unsigned NOT NULL,
  `usd_per_user` double(20,2) unsigned NOT NULL,
  `gross_profit_btc` double(20,2) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `date` (`date`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `emails`
--

CREATE TABLE IF NOT EXISTS `emails` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(255) NOT NULL,
  `title_en` varchar(255) NOT NULL,
  `title_es` varchar(255) NOT NULL,
  `content_en` blob NOT NULL,
  `content_es` blob NOT NULL,
  PRIMARY KEY (`id`),
  KEY `key` (`key`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=20 ;

--
-- Dumping data for table `emails`
--

INSERT INTO `emails` (`id`, `key`, `title_en`, `title_es`, `content_en`, `content_es`) VALUES
(11, 'forgot', 'Password Reset Request', 'Solicitud de cambio de contraseña', 0x3c703e44656172205b66697273745f6e616d655d205b6c6173745f6e616d655d2c3c2f703e0d0a0d0a3c703e596f752063616e206c6f6720696e746f205b65786368616e67655f6e616d655d207573696e672074686520666f6c6c6f77696e672074656d706f726172792063726564656e7469616c733a3c2f703e0d0a0d0a3c703e3c7374726f6e673e557365726e616d653a3c2f7374726f6e673e205b6e65775f757365725d3c2f703e0d0a0d0a3c703e3c7374726f6e673e50617373776f72643a3c2f7374726f6e673e205b6e65775f70617373776f72645d3c2f703e0d0a0d0a3c703e506c65617365206368616e676520796f75722070617373776f72642075706f6e206c6f67696e2e3c2f703e0d0a0d0a3c703e4265737420726567617264732c3c2f703e0d0a0d0a3c703e5b65786368616e67655f6e616d655d20537570706f7274205465616d3c2f703e0d0a, 0x3c703e457374696d61646f205b66697273745f6e616d655d205b6c6173745f6e616d655d2c3c2f703e0d0a0d0a3c703e507565646520696e6772657361722061205b65786368616e67655f6e616d655d20636f6e206c6f73207369677569656e7465732063726564656e6369616c65732074656d706f72616c65733a3c2f703e0d0a0d0a3c703e3c7374726f6e673e5573756172696f3a3c2f7374726f6e673e205b6e65775f757365725d3c2f703e0d0a0d0a3c703e3c7374726f6e673e436f6e7472617365266e74696c64653b613a3c2f7374726f6e673e205b6e65775f70617373776f72645d3c2f703e0d0a0d0a3c703e506f72206661766f722063616d62696520737520636f6e7472617365266e74696c64653b61206375616e646f206c6f67726120696e6772657361722e3c2f703e0d0a0d0a3c703e4174656e74616d656e74652c3c2f703e0d0a0d0a3c703e536f706f727465206465205b65786368616e67655f6e616d655d3c2f703e0d0a),
(12, 'contact', 'Contact Form', 'Contact Form', 0x3c703e3c753e434f4e5441435420464f524d3c2f753e3c2f703e0d0a0d0a3c703e5b7661726961626c65735d3c2f703e0d0a, 0x3c703e3c753e434f4e5441435420464f524d3c2f753e3c2f703e0d0a0d0a3c703e5b7661726961626c65735d3c2f703e0d0a),
(13, 'request-auth', 'Withdrawal Authorization', 'Autorización de retiro', 0x3c703e44656172205b66697273745f6e616d655d205b6c6173745f6e616d655d2c3c2f703e0d0a0d0a3c703e506c6561736520666f6c6c6f7720746865203c6120687265663d22687474703a2f2f7777772e3162746378652e636f6d2f77697468647261772e7068703f656d61696c5f617574683d3126616d703b61757468636f64653d5b61757468636f64655d223e74686973206c696e6b3c2f613e20746f20617574686f72697a6520796f7572207769746864726177616c2e3c2f703e0d0a0d0a3c703e4265737420726567617264732c3c2f703e0d0a0d0a3c703e5b65786368616e67655f6e616d655d20537570706f7274205465616d3c2f703e0d0a, 0x3c703e457374696d61646f205b66697273745f6e616d655d205b6c6173745f6e616d655d2c3c2f703e0d0a0d0a3c703e506f72206661766f722073696761203c6120687265663d22687474703a2f2f7777772e3162746378652e636f6d2f77697468647261772e7068703f656d61696c5f617574683d3126616d703b61757468636f64653d5b61757468636f64655d223e65737465206c696e6b3c2f613e2070617261206175746f72697a61722073752072657469726f2e3c2f703e0d0a0d0a3c703e4174656e6369266f61637574653b6e2c3c2f703e0d0a0d0a3c703e536f706f727465206465205b65786368616e67655f6e616d655d3c2f703e0d0a),
(14, 'register', 'Your Registration Information', 'Su información de registro', 0x3c703e44656172205b66697273745f6e616d655d205b6c6173745f6e616d655d2c3c2f703e0d0a0d0a3c703e5468616e6b20796f7520666f72207369676e696e6720757020666f72205b65786368616e67655f6e616d655d2e20596f752063616e206c6f6720696e207573696e672074686520666f6c6c6f77696e6720696e666f726d6174696f6e3a3c2f703e0d0a0d0a3c703e3c753e557365723a3c2f753e205b757365725d3c2f703e0d0a0d0a3c703e3c753e50617373776f72643a3c2f753e205b706173735d3c2f703e0d0a0d0a3c703e4265737420726567617264732c3c2f703e0d0a0d0a3c703e5b65786368616e67655f6e616d655d20537570706f7274205465616d3c2f703e0d0a, 0x3c703e457374696d61646f205b66697273745f6e616d655d205b6c6173745f6e616d655d2c3c2f703e0d0a0d0a3c703e4772616369617320706f722072656769737472617273652070617261207574696c697a6172205b65786368616e67655f6e616d655d2e205075656465206163636564657220616c20736974696f207574696c697a616e646f206c6f73207369677569656e7465732063726564656e6369616c65733a3c2f703e0d0a0d0a3c703e3c753e5573756172696f3a3c2f753e205b757365725d3c2f703e0d0a0d0a3c703e3c753e436f6e7472617365266e74696c64653b613a3c2f753e205b706173735d3c2f703e0d0a0d0a3c703e53616c75646f732c3c2f703e0d0a0d0a3c703e536f706f727465206465205b65786368616e67655f6e616d655d3c2f703e0d0a),
(15, 'settings-auth', 'Settings Change Request', 'Solicitud de cambio de información', 0x3c703e44656172205b66697273745f6e616d655d205b6c6173745f6e616d655d2c3c2f703e0d0a0d0a3c703e596f752061726520726563656976696e672074686973206d657373616765206265636175736520736f6d65626f64792068617320747269656420746f206368616e676520796f7572206163636f756e742073657474696e67732e20496620796f7520646964206e6f742074727920746f206368616e676520796f75722073657474696e67732c20706c65617365207265706f7274207468697320746f206f75722073746166662e3c2f703e0d0a0d0a3c703e506c6561736520666f6c6c6f7720746865203c6120687265663d22687474703a2f2f7777772e3162746378652e636f6d2f73657474696e67732e7068703f656d61696c5f617574683d3126616d703b61757468636f64653d5b61757468636f64655d223e74686973206c696e6b3c2f613e20696620796f7520776f756c64206c696b6520746f20617574686f72697a652074686973206368616e67652e3c2f703e0d0a0d0a3c703e4265737420726567617264732c3c2f703e0d0a0d0a3c703e5b65786368616e67655f6e616d655d20537570706f7274205465616d3c2f703e0d0a, 0x3c703e457374696d61646f205b66697273745f6e616d655d205b6c6173745f6e616d655d2c3c2f703e0d0a0d0a3c703e557374656420726563696269266f61637574653b2065737465206d656e73616a6520706f7220756e20696e74656e746f2064652063616d626961722073757320707265666572656e63696173206f20696e666f726d616369266f61637574653b6e20706572736f6e616c2e20536920706f72206c6f20636f6e74726172696f2c207573746564206e6f20686120686563686f206e696e67267561637574653b6e2063616d62696f2c20706f72206661766f7220726570266f61637574653b7274656c6f2061206e75657374726f20706572736f6e616c2e3c2f703e0d0a0d0a3c703e506f72206661766f722070756c736520656e203c6120687265663d22687474703a2f2f7777772e3162746378652e636f6d2f73657474696e67732e7068703f656d61696c5f617574683d3126616d703b61757468636f64653d5b61757468636f64655d223e657374652076266961637574653b6e63756c6f3c2f613e207369206465736561206175746f72697a617220657374652063616d62696f2e3c2f703e0d0a0d0a3c703e4174656e7461746d656e74652c3c2f703e0d0a0d0a3c703e536f706f727465206465205b65786368616e67655f6e616d655d3c2f703e0d0a),
(16, 'register-notify', 'New User Registered', 'New User Registered', 0x3c703e5b7661726961626c65735d3c2f703e0d0a, 0x3c703e5b7661726961626c65735d3c2f703e0d0a),
(17, 'login-notify', 'Login Notification', 'Notificación de login', 0x3c703e44656172205b66697273745f6e616d655d205b6c6173745f6e616d655d2c3c2f703e0d0a0d0a3c703e536f6d65626f647920686173206c6f6767656420696e746f20796f7572206163636f756e742066726f6d204950205b6970616464726573735d2e3c2f703e0d0a0d0a3c703e4265737420726567617264732c3c2f703e0d0a0d0a3c703e5b65786368616e67655f6e616d655d20537570706f7274205465616d3c2f703e0d0a, 0x3c703e457374696d61646f205b66697273745f6e616d655d205b6c6173745f6e616d655d2c3c2f703e0d0a0d0a3c703e416c677569656e20686120696e6772657361646f2061207375206375656e746120646573646520656c204950205b6970616464726573735d2e3c2f703e0d0a0d0a3c703e53616c75646f732c3c2f703e0d0a0d0a3c703e536f706f727465206465205b65786368616e67655f6e616d655d3c2f703e0d0a),
(18, 'security-auth', 'Two-factor Authentication Request', 'Solicitud de autenticación de dos factores', 0x3c703e44656172205b66697273745f6e616d655d205b6c6173745f6e616d655d2c3c2f703e0d0a0d0a3c703e596f752061726520726563656976696e672074686973206d6573736167652061732070617274206f66207468652070726f63657373206f6620616464696e672074776f2d666163746f722061757468656e7469636174696f6e20746f20796f7572206163636f756e742e20496620796f7520646964206e6f742074727920746f20646f20746869732c20706c65617365207265706f7274207468697320746f206f75722073746166662e3c2f703e0d0a0d0a3c703e506c6561736520666f6c6c6f7720746865203c6120687265663d22687474703a2f2f7777772e3162746378652e636f6d2f73656375726974792e7068703f61757468636f64653d5b61757468636f64655d223e74686973206c696e6b3c2f613e20696620796f7520776f756c64206c696b6520746f20617574686f72697a652074686973206368616e67652e3c2f703e0d0a0d0a3c703e4265737420726567617264732c3c2f703e0d0a0d0a3c703e5b65786368616e67655f6e616d655d20537570706f7274205465616d3c2f703e0d0a, 0x3c703e457374696d61646f205b66697273745f6e616d655d205b6c6173745f6e616d655d2c3c2f703e0d0a0d0a3c703e557374656420726563696269266f61637574653b2065737465206d656e73616a6520636f6d6f2070617274652064656c2070726f6365736f206465206167726567617220617574656e746963616369266f61637574653b6e20646520646f7320666163746f7265732061207375206375656e74612e20536920706f72206c6f20636f6e74726172696f2c207573746564206e6f20686120696e74656e7461646f206861636572206573746f2c20706f72206661766f7220726570266f61637574653b7274656c6f2061206e75657374726f20706572736f6e616c2e3c2f703e0d0a0d0a3c703e506f72206661766f722070756c736520656e203c6120687265663d22687474703a2f2f7777772e3162746378652e636f6d2f73656375726974792e7068703f61757468636f64653d5b61757468636f64655d223e657374652076266961637574653b6e63756c6f3c2f613e207369206465736561206175746f72697a617220657374652063616d62696f2e3c2f703e0d0a0d0a3c703e4174656e7461746d656e74652c3c2f703e0d0a0d0a3c703e536f706f727465206465205b65786368616e67655f6e616d655d3c2f703e0d0a),
(19, 'order-cancelled', 'Order Partially Executed', 'Órden parcialmente ejecutada', 0x3c703e44656172205b66697273745f6e616d655d205b6c6173745f6e616d655d2c3c2f703e0d0a0d0a3c703e596f752061726520726563656976696e672074686973206d6573736167652062656361757365205b616d6f756e745d20425443206f66206f6e65206f6620796f7572206f726465727320636f756c64206e6f742062652066756c6c792065786563757465642062656361757365206f66206c61636b206f662066756e64732e205468697320736974756174696f6e2063616e206f63637572207768656e2061207269736520696e20746865206d61726b6574207072696365206361757365732074686520746f74616c20616d6f756e74206f662061206d61726b6574206f7264657220746f2065786365656420796f757220617661696c61626c652066756e64732e205468657265666f72652c206f6e6c792074686520617661696c61626c6520616d6f756e742077696c6c20626520657865637574656420746f2061766f69642061206e656761746976652062616c616e6365206f6e20796f7572206163636f756e742e3c2f703e0d0a0d0a3c703e4265737420726567617264732c3c2f703e0d0a0d0a3c703e5b65786368616e67655f6e616d655d20537570706f7274205465616d3c2f703e0d0a, 0x3c703e457374696d61646f205b66697273745f6e616d655d205b6c6173745f6e616d655d2c3c2f703e0d0a0d0a3c703e557374656420686120726563696269646f2065737465206d656e73616a6520706f72717565205b616d6f756e745d2042544320646520756e612064652073757320266f61637574653b7264656e6573206e6f207075646f2073657220656a6563757461646120706f722066616c746120646520666f6e646f732e20457374612073697475616369266f61637574653b6e2073652070756564652070726573656e746172206375616e646f20756e20616c7a6120656e20656c2070726563696f2064656c206d65726361646f20686163652071756520656c2076616c6f7220746f74616c20646520737520266f61637574653b7264656e206465206d65726361646f207375627265706173652073757320666f6e646f7320646973706f6e69626c65732e20506f72206c6f2074616e746f2c2073266f61637574653b6c6f20736520706f6472266161637574653b20656a656375746172206c612063616e746964616420646973706f6e69626c6520706172612065766974617220756e2062616c616e6365206e6567617469766f20656e207375206375656e74612e3c2f703e0d0a0d0a3c703e53616c75646f732c3c2f703e0d0a0d0a3c703e536f706f727465206465205b65786368616e67655f6e616d655d3c2f703e0d0a);

-- --------------------------------------------------------

--
-- Table structure for table `fees`
--

CREATE TABLE IF NOT EXISTS `fees` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fee` double(16,8) unsigned NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `date` (`date`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `fee_schedule`
--

CREATE TABLE IF NOT EXISTS `fee_schedule` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fee` double(10,2) NOT NULL,
  `from_usd` double(10,2) NOT NULL,
  `to_usd` double(10,2) NOT NULL,
  `order` int(10) NOT NULL,
  `fee1` double(10,2) NOT NULL DEFAULT '0.00',
  `global_btc` double(16,8) unsigned NOT NULL DEFAULT '0.00000000',
  PRIMARY KEY (`id`),
  KEY `from_usd` (`from_usd`),
  KEY `to_usd` (`to_usd`),
  KEY `global_btc` (`global_btc`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `fee_schedule`
--

INSERT INTO `fee_schedule` (`id`, `fee`, `from_usd`, `to_usd`, `order`, `fee1`, `global_btc`) VALUES
(1, 0.50, 0.00, 500.00, 0, 0.00, 0.00000000),
(2, 0.48, 500.01, 1000.00, 0, 0.00, 0.00000000),
(3, 0.46, 1000.01, 2000.00, 0, 0.00, 0.00000000),
(4, 0.44, 2000.01, 4000.00, 0, 0.00, 0.00000000),
(5, 0.42, 4000.01, 6500.00, 0, 0.00, 0.00000000),
(6, 0.40, 6500.01, 10000.00, 0, 0.00, 0.00000000),
(7, 0.38, 10000.01, 15000.00, 0, 0.00, 0.00000000),
(8, 0.36, 15000.01, 20000.00, 0, 0.00, 0.00000000),
(9, 0.34, 20000.01, 25000.00, 0, 0.00, 0.00000000),
(10, 0.32, 25000.01, 37500.00, 0, 0.00, 0.00000000),
(11, 0.30, 36500.01, 50000.00, 0, 0.00, 0.00000000),
(12, 0.28, 50000.01, 62500.00, 0, 0.00, 0.00000000),
(13, 0.26, 62500.01, 75000.00, 0, 0.00, 0.00000000),
(14, 0.24, 7500.01, 100000.00, 0, 0.00, 0.00000000),
(15, 0.22, 100000.01, 150000.00, 0, 0.00, 0.00000000),
(16, 0.20, 150000.01, 0.00, 0, 0.00, 0.00000000);

-- --------------------------------------------------------

--
-- Table structure for table `historical_data`
--

CREATE TABLE IF NOT EXISTS `historical_data` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `usd` decimal(6,2) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `date` (`date`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `history`
--

CREATE TABLE IF NOT EXISTS `history` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `date` datetime NOT NULL,
  `ip` varchar(255) NOT NULL,
  `history_action` int(10) NOT NULL,
  `order_id` int(10) NOT NULL,
  `bitcoin_address` varchar(255) NOT NULL,
  `site_user` int(10) NOT NULL,
  `request_id` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `date` (`date`),
  KEY `site_user` (`site_user`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `history_actions`
--

CREATE TABLE IF NOT EXISTS `history_actions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name_en` varchar(255) NOT NULL,
  `name_es` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `history_actions`
--

INSERT INTO `history_actions` (`id`, `name_en`, `name_es`) VALUES
(1, 'Login', 'Login'),
(2, 'Buy Order', 'Orden Compra'),
(3, 'Sell Order', 'Orden Venta'),
(4, 'Deposit', 'Depositar'),
(5, 'Withdraw', 'Retirar');

-- --------------------------------------------------------

--
-- Table structure for table `iso_countries`
--

CREATE TABLE IF NOT EXISTS `iso_countries` (
  `id` int(10) NOT NULL,
  `country_id` int(10) NOT NULL,
  `locale` varchar(10) NOT NULL DEFAULT 'en',
  `code` char(2) NOT NULL,
  `name` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `prefix` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `iso_countries`
--

INSERT INTO `iso_countries` (`id`, `country_id`, `locale`, `code`, `name`, `prefix`) VALUES
(1, 1, 'en', 'AF', 'Afghanistan', '+93'),
(2, 2, 'en', 'AL', 'Albania', '+355'),
(3, 3, 'en', 'DZ', 'Algeria', '+213'),
(4, 4, 'en', 'AD', 'Andorra', '+376'),
(5, 5, 'en', 'AO', 'Angola', '+244'),
(6, 6, 'en', 'AG', 'Antigua and Barbuda', '+1-268'),
(7, 7, 'es', 'AR', 'Argentina', '+54'),
(8, 8, 'en', 'AM', 'Armenia', '+374'),
(9, 9, 'en', 'AU', 'Australia', '+61'),
(10, 10, 'de', 'AT', 'Austria', '+43'),
(11, 11, 'en', 'AZ', 'Azerbaijan', '+994'),
(12, 12, 'en', 'BS', 'Bahamas, The', '+1-242'),
(13, 13, 'en', 'BH', 'Bahrain', '+973'),
(14, 14, 'en', 'BD', 'Bangladesh', '+880'),
(15, 15, 'en', 'BB', 'Barbados', '+1-246'),
(16, 16, 'ru', 'BY', 'Belarus', '+375'),
(17, 17, 'fr', 'BE', 'Belgium', '+32'),
(18, 18, 'en', 'BZ', 'Belize', '+501'),
(19, 19, 'en', 'BJ', 'Benin', '+229'),
(20, 20, 'en', 'BT', 'Bhutan', '+975'),
(21, 21, 'es', 'BO', 'Bolivia', '+591'),
(22, 22, 'en', 'BA', 'Bosnia and Herzegovina', '+387'),
(23, 23, 'en', 'BW', 'Botswana', '+267'),
(24, 24, 'en', 'BR', 'Brazil', '+55'),
(25, 25, 'en', 'BN', 'Brunei', '+673'),
(26, 26, 'en', 'BG', 'Bulgaria', '+359'),
(27, 27, 'en', 'BF', 'Burkina Faso', '+226'),
(28, 28, 'en', 'BI', 'Burundi', '+257'),
(29, 29, 'en', 'KH', 'Cambodia', '+855'),
(30, 30, 'en', 'CM', 'Cameroon', '+237'),
(31, 31, 'en', 'CA', 'Canada', '+1'),
(32, 32, 'en', 'CV', 'Cape Verde', '+238'),
(33, 33, 'fr', 'CF', 'Central African Republic', '+236'),
(34, 34, 'fr', 'TD', 'Chad', '+235'),
(35, 35, 'es', 'CL', 'Chile', '+56'),
(36, 36, 'en', 'CN', 'China, People''s Republic of', '+86'),
(37, 37, 'es', 'CO', 'Colombia', '+57'),
(38, 38, 'en', 'KM', 'Comoros', '+269'),
(39, 39, 'fr', 'CD', 'Congo, Democratic Republic of the (Congo ? Kinshasa)', '+243'),
(40, 40, 'fr', 'CG', 'Congo, Republic of the (Congo ? Brazzaville)', '+242'),
(41, 41, 'es', 'CR', 'Costa Rica', '+506'),
(42, 42, 'fr', 'CI', 'Cote d''Ivoire (Ivory Coast)', '+225'),
(43, 43, 'en', 'HR', 'Croatia', '+385'),
(44, 44, 'es', 'CU', 'Cuba', '+53'),
(45, 45, 'en', 'CY', 'Cyprus', '+357'),
(46, 46, 'en', 'CZ', 'Czech Republic', '+420'),
(47, 47, 'en', 'DK', 'Denmark', '+45'),
(48, 48, 'fr', 'DJ', 'Djibouti', '+253'),
(49, 49, 'en', 'DM', 'Dominica', '+1-767'),
(50, 50, 'es', 'DO', 'Dominican Republic', '+1-809 and 1-829'),
(51, 51, 'es', 'EC', 'Ecuador', '+593'),
(52, 52, 'en', 'EG', 'Egypt', '+20'),
(53, 53, 'es', 'SV', 'El Salvador', '+503'),
(54, 54, 'en', 'GQ', 'Equatorial Guinea', '+240'),
(55, 55, 'en', 'ER', 'Eritrea', '+291'),
(56, 56, 'en', 'EE', 'Estonia', '+372'),
(57, 57, 'en', 'ET', 'Ethiopia', '+251'),
(58, 58, 'en', 'FJ', 'Fiji', '+679'),
(59, 59, 'en', 'FI', 'Finland', '+358'),
(60, 60, 'fr', 'FR', 'France', '+33'),
(61, 61, 'en', 'GA', 'Gabon', '+241'),
(62, 62, 'en', 'GM', 'Gambia, The', '+220'),
(63, 63, 'en', 'GE', 'Georgia', '+995'),
(64, 64, 'de', 'DE', 'Germany', '+49'),
(65, 65, 'en', 'GH', 'Ghana', '+233'),
(66, 66, 'en', 'GR', 'Greece', '+30'),
(67, 67, 'en', 'GD', 'Grenada', '+1-473'),
(68, 68, 'es', 'GT', 'Guatemala', '+502'),
(69, 69, 'en', 'GN', 'Guinea', '+224'),
(70, 70, 'en', 'GW', 'Guinea-Bissau', '+245'),
(71, 71, 'en', 'GY', 'Guyana', '+592'),
(72, 72, 'fr', 'HT', 'Haiti', '+509'),
(73, 73, 'es', 'HN', 'Honduras', '+504'),
(74, 74, 'en', 'HU', 'Hungary', '+36'),
(75, 75, 'en', 'IS', 'Iceland', '+354'),
(76, 76, 'en', 'IN', 'India', '+91'),
(77, 77, 'en', 'ID', 'Indonesia', '+62'),
(78, 78, 'en', 'IR', 'Iran', '+98'),
(79, 79, 'en', 'IQ', 'Iraq', '+964'),
(80, 80, 'en', 'IE', 'Ireland', '+353'),
(81, 81, 'he', 'IL', 'Israel', '+972'),
(82, 82, 'en', 'IT', 'Italy', '+39'),
(83, 83, 'en', 'JM', 'Jamaica', '+1-876'),
(84, 84, 'en', 'JP', 'Japan', '+81'),
(85, 85, 'en', 'JO', 'Jordan', '+962'),
(86, 86, 'en', 'KZ', 'Kazakhstan', '+7'),
(87, 87, 'en', 'KE', 'Kenya', '+254'),
(88, 88, 'en', 'KI', 'Kiribati', '+686'),
(89, 89, 'en', 'KP', 'Korea, Democratic People''s Republic of (North Korea)', '+850'),
(90, 90, 'en', 'KR', 'Korea, Republic of  (South Korea)', '+82'),
(91, 91, 'en', 'KW', 'Kuwait', '+965'),
(92, 92, 'en', 'KG', 'Kyrgyzstan', '+996'),
(93, 93, 'en', 'LA', 'Laos', '+856'),
(94, 94, 'en', 'LV', 'Latvia', '+371'),
(95, 95, 'en', 'LB', 'Lebanon', '+961'),
(96, 96, 'en', 'LS', 'Lesotho', '+266'),
(97, 97, 'en', 'LR', 'Liberia', '+231'),
(98, 98, 'en', 'LY', 'Libya', '+218'),
(99, 99, 'de', 'LI', 'Liechtenstein', '+423'),
(100, 100, 'en', 'LT', 'Lithuania', '+370'),
(101, 101, 'fr', 'LU', 'Luxembourg', '+352'),
(102, 102, 'en', 'MK', 'Macedonia', '+389'),
(103, 103, 'en', 'MG', 'Madagascar', '+261'),
(104, 104, 'en', 'MW', 'Malawi', '+265'),
(105, 105, 'en', 'MY', 'Malaysia', '+60'),
(106, 106, 'en', 'MV', 'Maldives', '+960'),
(107, 107, 'en', 'ML', 'Mali', '+223'),
(108, 108, 'en', 'MT', 'Malta', '+356'),
(109, 109, 'en', 'MH', 'Marshall Islands', '+692'),
(110, 110, 'en', 'MR', 'Mauritania', '+222'),
(111, 111, 'en', 'MU', 'Mauritius', '+230'),
(112, 112, 'es', 'MX', 'Mexico', '+52'),
(113, 113, 'en', 'FM', 'Micronesia', '+691'),
(114, 114, 'en', 'MD', 'Moldova', '+373'),
(115, 115, 'en', 'MC', 'Monaco', '+377'),
(116, 116, 'en', 'MN', 'Mongolia', '+976'),
(117, 117, 'en', 'ME', 'Montenegro', '+382'),
(118, 118, 'fr', 'MA', 'Morocco', '+212'),
(119, 119, 'en', 'MZ', 'Mozambique', '+258'),
(120, 120, 'en', 'MM', 'Myanmar (Burma)', '+95'),
(121, 121, 'en', 'NA', 'Namibia', '+264'),
(122, 122, 'en', 'NR', 'Nauru', '+674'),
(123, 123, 'en', 'NP', 'Nepal', '+977'),
(124, 124, 'en', 'NL', 'Netherlands', '+31'),
(125, 125, 'en', 'NZ', 'New Zealand', '+64'),
(126, 126, 'es', 'NI', 'Nicaragua', '+505'),
(127, 127, 'en', 'NE', 'Niger', '+227'),
(128, 128, 'en', 'NG', 'Nigeria', '+234'),
(129, 129, 'en', 'NO', 'Norway', '+47'),
(130, 130, 'en', 'OM', 'Oman', '+968'),
(131, 131, 'en', 'PK', 'Pakistan', '+92'),
(132, 132, 'en', 'PW', 'Palau', '+680'),
(133, 133, 'es', 'PA', 'Panama', '+507'),
(134, 134, 'en', 'PG', 'Papua New Guinea', '+675'),
(135, 135, 'es', 'PY', 'Paraguay', '+595'),
(136, 136, 'es', 'PE', 'Peru', '+51'),
(137, 137, 'en', 'PH', 'Philippines', '+63'),
(138, 138, 'en', 'PL', 'Poland', '+48'),
(139, 139, 'en', 'PT', 'Portugal', '+351'),
(140, 140, 'en', 'QA', 'Qatar', '+974'),
(141, 141, 'en', 'RO', 'Romania', '+40'),
(142, 142, 'ru', 'RU', 'Russia', '+7'),
(143, 143, 'en', 'RW', 'Rwanda', '+250'),
(144, 144, 'en', 'KN', 'Saint Kitts and Nevis', '+1-869'),
(145, 145, 'en', 'LC', 'Saint Lucia', '+1-758'),
(146, 146, 'en', 'VC', 'Saint Vincent and the Grenadines', '+1-784'),
(147, 147, 'en', 'WS', 'Samoa', '+685'),
(148, 148, 'en', 'SM', 'San Marino', '+378'),
(149, 149, 'en', 'ST', 'Sao Tome and Principe', '+239'),
(150, 150, 'en', 'SA', 'Saudi Arabia', '+966'),
(151, 151, 'fr', 'SN', 'Senegal', '+221'),
(152, 152, 'en', 'RS', 'Serbia', '+381'),
(153, 153, 'en', 'SC', 'Seychelles', '+248'),
(154, 154, 'en', 'SL', 'Sierra Leone', '+232'),
(155, 155, 'en', 'SG', 'Singapore', '+65'),
(156, 156, 'en', 'SK', 'Slovakia', '+421'),
(157, 157, 'en', 'SI', 'Slovenia', '+386'),
(158, 158, 'en', 'SB', 'Solomon Islands', '+677'),
(159, 159, 'en', 'SO', 'Somalia', '+252'),
(160, 160, 'en', 'ZA', 'South Africa', '+27'),
(161, 161, 'es', 'ES', 'Spain', '+34'),
(162, 162, 'en', 'LK', 'Sri Lanka', '+94'),
(163, 163, 'en', 'SD', 'Sudan', '+249'),
(164, 164, 'en', 'SR', 'Suriname', '+597'),
(165, 165, 'en', 'SZ', 'Swaziland', '+268'),
(166, 166, 'en', 'SE', 'Sweden', '+46'),
(167, 167, 'fr', 'CH', 'Switzerland', '+41'),
(168, 168, 'en', 'SY', 'Syria', '+963'),
(169, 169, 'en', 'TJ', 'Tajikistan', '+992'),
(170, 170, 'en', 'TZ', 'Tanzania', '+255'),
(171, 171, 'en', 'TH', 'Thailand', '+66'),
(172, 172, 'en', 'TL', 'Timor-Leste (East Timor)', '+670'),
(173, 173, 'en', 'TG', 'Togo', '+228'),
(174, 174, 'en', 'TO', 'Tonga', '+676'),
(175, 175, 'en', 'TT', 'Trinidad and Tobago', '+1-868'),
(176, 176, 'fr', 'TN', 'Tunisia', '+216'),
(177, 177, 'en', 'TR', 'Turkey', '+90'),
(178, 178, 'en', 'TM', 'Turkmenistan', '+993'),
(179, 179, 'en', 'TV', 'Tuvalu', '+688'),
(180, 180, 'en', 'UG', 'Uganda', '+256'),
(181, 181, 'ru', 'UA', 'Ukraine', '+380'),
(182, 182, 'en', 'AE', 'United Arab Emirates', '+971'),
(183, 183, 'en', 'GB', 'United Kingdom', '+44'),
(184, 184, 'en', 'US', 'United States', '+1'),
(185, 185, 'es', 'UY', 'Uruguay', '+598'),
(186, 186, 'en', 'UZ', 'Uzbekistan', '+998'),
(187, 187, 'en', 'VU', 'Vanuatu', '+678'),
(188, 188, 'en', 'VA', 'Vatican City', '+379'),
(189, 189, 'es', 'VE', 'Venezuela', '+58'),
(190, 190, 'en', 'VN', 'Viet Nam', '+84'),
(191, 191, 'en', 'YE', 'Yemen', '+967'),
(192, 192, 'en', 'ZM', 'Zambia', '+260'),
(193, 193, 'en', 'ZW', 'Zimbabwe', '+263'),
(195, 195, 'en', 'TW', 'China, Republic of (Taiwan)', '+886'),
(236, 236, 'es', 'PR', 'Puerto Rico', '+1-787 and 1-939'),
(249, 249, 'en', 'HK', 'Hong Kong', '+852'),
(265, 265, 'en', 'PS', 'Palestinian Territories (Gaza Strip and West Bank)', '+970');

-- --------------------------------------------------------

--
-- Table structure for table `lang`
--

CREATE TABLE IF NOT EXISTS `lang` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(255) NOT NULL,
  `esp` varchar(255) NOT NULL,
  `eng` varchar(255) NOT NULL,
  `order` varchar(255) NOT NULL,
  `p_id` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `p_id` (`p_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=359 ;

--
-- Dumping data for table `lang`
--

INSERT INTO `lang` (`id`, `key`, `esp`, `eng`, `order`, `p_id`) VALUES
(9, 'home', 'Inicio', 'Home', '', 0),
(10, 'home-title', 'Compre y venda Bitcoin con seguridad y rápida ejecución', 'Buy and Sell Bitcoins With High Security and Low Latency', '', 9),
(11, 'order-book', 'Libreta de órdenes', 'Order Book', '', 0),
(12, 'what-are-bitcoins', '¿Qué son los Bitcoins?', 'What Are Bitcoins?', '', 0),
(13, 'how-bitcoin-works', 'Cómo funciona Bitcoin', 'How Bitcoin Works', '', 12),
(14, 'trading-bitcoins', 'Compraventa de Bitcoins', 'Trading Bitcoins', '', 12),
(15, 'how-to-register', 'Cómo registrarse', 'How To Register', '', 0),
(16, 'fee-schedule', 'Tarifas', 'Fee Schedule', '', 0),
(17, 'account', 'Mi Cuenta', 'My Account', '', 0),
(18, 'open-orders', 'Órdenes abiertas', 'Open Orders', '', 17),
(19, 'transactions', 'Transacciones', 'Transactions', '', 17),
(20, 'security', 'Seguridad', 'Security', '', 0),
(21, 'buy-sell', 'Comprar/vender', 'Buy/Sell', '', 0),
(22, 'deposit', 'Depositar', 'Deposit', '', 0),
(23, 'withdraw', 'Retirar', 'Withdraw', '', 0),
(24, 'help', 'Ayuda / FAQ', 'Help / FAQ', '', 0),
(25, 'terms', 'Términos de uso', 'Terms of Use', '', 0),
(26, 'contact', 'Contáctenos', 'Contact Us', '', 0),
(27, 'home-login', 'Login', 'Login', '', 0),
(28, 'home-register', 'Registrarse', 'Register', '', 9),
(29, 'home-trading', 'Aprenda como empezar el trading de Bitcoins ahora', 'Learn how you can start trading Bitcoins now', '', 9),
(30, 'home-more', 'Leer Más', 'Read More', '', 9),
(31, 'home-bitcoin-market', 'Resúmen de Mercado <strong>Bitcoin</strong>', 'Bitcoin Market <strong>Overview</strong>', '', 9),
(32, 'home-bitcoin-market-explain', 'Estadí­sticas clave sobre el mercado de compraventa de Bitcoin', 'Key statistics about the Bitcoin trading market', '', 9),
(33, 'home-stats-last-price', 'Último precio', 'Last Price', '', 9),
(34, 'home-stats-daily-change', 'Cambio diario', 'Daily Change', '', 9),
(35, 'home-stats-days-range', 'Rango del dia', 'Day''s Range', '', 9),
(36, 'home-stats-todays-open', 'Apertura hoy', 'Today''s Open', '', 9),
(37, 'home-stats-24h-volume', 'Volumen 24h', '24h Volume', '', 9),
(38, 'home-stats-market-cap', 'Capit. mercado', 'Market Cap', '', 9),
(39, 'home-stats-total-btc', 'BTC totales', 'Total BTC', '', 9),
(40, 'home-stats-global-volume', 'Volumen global', 'Global Volume', '', 9),
(41, 'javascript-date-format', '%e/%m/%y', '%m/%e/%y', '', 42),
(42, 'dates', 'Fechas', 'Dates', '', 0),
(43, 'sun', 'Dom', 'Sun', '', 42),
(44, 'mon', 'Lun', 'Mon', '', 42),
(45, 'tue', 'Mar', 'Tue', '', 42),
(46, 'wed', 'Mié', 'Wed', '', 42),
(47, 'thu', 'Jue', 'Thu', '', 42),
(48, 'fri', 'Vie', 'Fri', '', 42),
(49, 'sat', 'Sáb', 'Sat', '', 42),
(50, 'jan', 'Ene', 'Jan', '', 42),
(51, 'feb', 'Feb', 'Feb', '', 42),
(52, 'mar', 'Mar', 'Mar', '', 42),
(53, 'apr', 'Abr', 'Apr', '', 42),
(54, 'may', 'May', 'May', '', 42),
(55, 'jun', 'Jun', 'Jun', '', 42),
(56, 'jul', 'Jul', 'Jul', '', 42),
(57, 'aug', 'Ago', 'Aug', '', 42),
(58, 'sep', 'Sep', 'Sep', '', 42),
(59, 'oct', 'Oct', 'Oct', '', 42),
(60, 'nov', 'Nov', 'Nov', '', 42),
(61, 'dec', 'Dic', 'Dec', '', 42),
(62, 'date-format', 'j/n/y', 'n/j/y', '', 42),
(63, 'transactions-time-since', 'Efectuado hace', 'Time Since', '', 17),
(64, 'transactions-amount', 'Cantidad', 'Amount', '', 17),
(65, 'transactions-price', 'Precio', 'Price', '', 17),
(67, 'home-live-trades', 'Últimas transacciones', 'Latest Trades', '', 9),
(68, 'home-live-orders', 'Órdenes abiertas', 'Open Orders', '', 9),
(69, 'currency', 'Moneda', 'Currency', '', 9),
(70, 'transactions-no', 'No hay transacciones.', 'No transactions to show.', '', 17),
(71, 'orders-bid', 'Oferta', 'Bid', '', 11),
(72, 'orders-ask', 'Demanda', 'Ask', '', 11),
(73, 'orders-no-bid', 'No hay ofertas.', 'No bids to show.', '', 11),
(74, 'orders-no-ask', 'No hay demanda.', 'No asks to show.', '', 11),
(75, 'news', 'Noticias', 'News', '', 0),
(76, 'news-latest', 'Últimas <strong>noticias</strong>', 'Latest <strong>News</strong>', '', 75),
(77, 'news-explain', 'Noticias relevantes sobre Bitcoin y este sitio en particular.', 'Relevant news about Bitcoin and this site in particular.', '', 75),
(82, 'home-basic-nav', 'Navegación', 'Navigation', '', 9),
(83, 'home-about-bitcoin', 'Info. sobre Bitcoin', 'Bitcoin Info', '', 9),
(84, 'home-account-functions', 'Mi Cuenta', 'Account', '', 9),
(85, 'news-see-all', 'Ver más noticias', 'Read more news', '', 75),
(86, 'order-book-see', 'Ver libreta de órdenes', 'Go to order book', '', 9),
(87, 'orders-price', 'Precio', 'Price', '', 11),
(88, 'orders-amount', 'Cantidad', 'Amount', '', 11),
(89, 'orders-value', 'Valor', 'Value', '', 11),
(90, 'forgot-ask', '¿Olvidó su información de login?', 'Forgot your login information?', '', 27),
(91, 'login-dont-have', '¿No tiene cuenta? Aprenda sobre cómo abrir una.', 'Don''t have an account? Find out how to open one.', '', 27),
(92, 'login-user-empty-error', 'Debe ingresar un usuario.', 'You must provide a username.', '', 27),
(93, 'login-password-empty-error', 'Debe ingresar una contraseña.', 'You must provide a password.', '', 27),
(94, 'login-invalid-login-error', 'Información de login inválido.', 'Invalid login information.', '', 27),
(95, 'login-forgot', 'Olvidó contraseña', 'Forgot Password', '', 27),
(96, 'forgot-explain', '¿Olvidó su información de login? Ingrese su email y le enviaremos credenciales nuevos.', 'Forgot your login information? Enter your email and we will send you new credentials.', '', 27),
(97, 'login-forgot-send-new', 'Obtener nuevo login', 'Get New Login', '', 27),
(98, 'login-remembered', '¿Recordó su info? Pulse aquí para regresar a login.', 'Remembered your info? Click here to return to login.', '', 27),
(99, 'email-send-error', 'Ocurrió un error y el email no se pudo enviar. Por favor inténtelo más tarde.', 'An error occurred and the email could not be sent. Please try again later.', '', 27),
(100, 'email-address-error', 'Email inválido.', 'Invalid email address.', '', 27),
(101, 'email-sent-message', 'El email fué enviado exitosamente.', 'The email was sent successfully.', '', 27),
(102, 'login-password-sent-message', 'Se le ha enviado un nuevo usuario y contraseña. Por favor revise su email.', 'You have been sent a new username and password. Please check your email.', '', 27),
(103, 'login-account-not-found', 'No existe ninguna cuenta vinculada al email que especificó.', 'There is no account for the email address you have specified.', '', 27),
(104, 'settings', 'Preferencias', 'Settings', '', 0),
(105, 'account-nav', 'Navegación de cuenta', 'Account Navigation', '', 17),
(106, 'account-welcome', 'Bienvenido', 'Welcome', '', 17),
(107, 'account-balance', 'Balances disponibles', 'Available Balances', '', 17),
(109, 'account-on-hold', 'Balances retenidos', 'Balances On Hold', '', 17),
(110, 'account-available', 'disponible', 'available', '', 17),
(111, 'account-on-order', 'en órdenes abiertas', 'in open orders', '', 17),
(112, 'account-on-widthdrawal', 'esperando retiro', 'waiting for withdrawal', '', 17),
(113, 'account-fee-structure', 'Nivel de tarifa y volumen', 'Fee Level and Volume', '', 17),
(114, 'account-fee-bracket', 'Tasa de comisión (tomador)', 'Commission rate (taker)', '', 17),
(115, 'account-30-day-vol', 'Volumen en USD a 30 dias', '30 day volume in USD', '', 17),
(116, 'account-view-fee-schedule', 'Ver tabla de tarifas', 'View fee schedule', '', 17),
(117, 'orders-edit', 'Editar esta órden', 'Edit this order', '', 9),
(118, 'orders-filter-currency', 'Filtrar por moneda', 'Filter by currency', '', 17),
(119, 'orders-order-by', 'Ordenar por', 'Order By', '', 17),
(120, 'orders-order-by-btc-price', 'Precio BTC', 'BTC Price', '', 17),
(121, 'orders-order-by-date', 'Fecha/hora de órden', 'Order date/time', '', 17),
(122, 'orders-order-by-fiat', 'Valor de la Ã³rden', 'Order Value', '', 17),
(123, 'transactions-type', 'Tipo', 'Type', '', 17),
(124, 'transactions-time', 'Hora y Fecha', 'Date and Time', '', 17),
(125, 'transactions-btc', 'Monto BTC', 'BTC Amount', '', 17),
(126, 'transactions-fiat', 'Valor', 'Value', '', 17),
(127, 'transactions-price', 'Precio BTC', 'BTC Price', '', 17),
(128, 'transactions-fee', 'Comisión', 'Fee', '', 17),
(129, 'transactions-any', 'Cualquiera', 'Any', '', 17),
(130, 'transactions-pagination', 'Mostrando [results] transacciones en [num_pages] páginas.', 'Showing [results] transactions on [num_pages] pages.', '', 17),
(131, 'orders-bid-top-10', '10 mejores ofertas', 'Top 10 Bids', '', 17),
(132, 'orders-ask-top-10', '10 mejores ventas', 'Top 10 Sellers', '', 17),
(133, 'buy-bitcoins', 'Comprar Bitcoins', 'Buy Bitcoins', '', 17),
(134, 'sell-bitcoins', 'Vender Bitcoins', 'Sell Bitcoins', '', 17),
(135, 'click-to-start', 'Pulsar para iniciar', 'Click to start', '', 17),
(136, 'buy-amount', 'Cantidad a comprar', 'Amount to Buy', '', 17),
(137, 'buy-with-currency', 'Moneda a utilizar', 'Currency to use', '', 17),
(138, 'buy-price', 'Precio', 'Price', '', 17),
(139, 'sell-amount', 'Cantidad a vender', 'Amount to Sell', '', 17),
(140, 'buy-subtotal', 'Subtotal', 'Subtotal', '', 17),
(141, 'buy-fee', 'Comisión', 'Fee', '', 17),
(142, 'buy-total', 'BTC a recibir', 'BTC to Receive', '', 17),
(143, 'sell-total', '[currency] total a recibir', '[currency] to receive', '', 17),
(144, 'buy-market-price', 'Comprar a precio del mercado', 'Buy at market price', '', 17),
(145, 'sell-market-price', 'Vender a precio del mercado', 'Sell at market price', '', 17),
(146, 'buy-market-rates-info', 'Pulse para más información.', 'Click for info on how this works.', '', 17),
(147, 'buy-total-approx', 'BTC approx. a recibir', 'Approx. BTC to Receive', '', 17),
(148, 'sell-total-approx', '[currency] approx a recibir', 'Approx [currency] to receive', '', 17),
(149, 'buy-errors-no-amount', 'Debe comprar una cantidad mayor a cero.', 'You must buy an amount greater than zero.', '', 17),
(150, 'buy-errors-no-price', 'Debe especificar el precio al que desea comprar.', 'You must specify a price at which to buy.', '', 17),
(151, 'sell-errors-no-price', 'Debe especificar el precio al que desea vender.', 'You must specify a price at which to sell.', '', 17),
(152, 'buy-errors-no-currency', 'Debe escoger una moneda.', 'No currency specified.', '', 17),
(153, 'buy-errors-balance-too-low', 'No tiene suficiente de la moneda especificada.', 'You do not have enough of the specified currency.', '', 17),
(154, 'sell-errors-balance-too-low', 'No tiene suficientes Bitcoins.', 'You do not have enough Bitcoins.', '', 17),
(155, 'log-out', 'Logout', 'Logout', '', 9),
(156, 'account-nothing-on-hold', 'No tiene órdenes ni solicitudes de retiro abiertas.', 'You have no open orders or withdrawal requests.', '', 17),
(157, 'buy-fiat-available', '[currency] disponibles', 'Available [currency]', '', 17),
(158, 'sell-btc-available', 'BTC disponibles', 'Available BTC', '', 17),
(159, 'transactions-done-message', 'Se realizaron [transactions] nuevas transacciones.', 'You have realized [transactions] new transactions.', '', 17),
(160, 'transactions-orders-done-message', 'Se ha creado una nueva órden y [transactions] nuevas transacciones.', 'You have created a new order and realized [transactions] new transactions.', '', 17),
(161, 'edit-order', 'Editar órden', 'Edit Order', '', 17),
(162, 'transactions-orders-new-message', 'Se ha creado una nueva órden.', 'You have created a new order.', '', 17),
(163, 'transactions-orders-edit-message', 'Su órden fué editada exitósamente.', 'Your order has been edited successfully.', '', 17),
(164, 'transactions-orders-done-edit-message', 'Se ha editado una órden y efectuado [transactions] nuevas transacciones.', 'You have edited your order and realized [transactions] new transactions.', '', 17),
(165, 'home-your-order', 'Usted es el autor de ésta órden', 'You made this order', '', 9),
(166, 'home-overview', 'Resúmen', 'Overview', '', 9),
(167, 'security-enable-two-factor', 'Habilitar autenticación de dos factores', 'Enable Two-Factor Authentication', '', 20),
(168, 'security-country', 'Su país', 'Your Country', '', 20),
(169, 'security-cell', 'Su num. celular', 'Your Cellphone #', '', 20),
(170, 'security-enable', 'Habilitar Authy', 'Enable Authy', '', 20),
(171, 'security-no-cell', 'Debe ingresar un número de celular.', 'You must provide a cellphone number.', '', 20),
(172, 'security-no-cc', 'Debe seleccionar un paí­s.', 'You must select a country.', '', 20),
(173, 'security-com-error', 'No nos pudimos comunicar con el servidor de Authy. Por favor inténtelo más tarde.', 'The Authy server was unreachable. Please try again later.', '', 20),
(174, 'security-enter-token', 'Ingresar código', 'Enter Token', '', 20),
(175, 'security-token', 'Su cÃ³digo ("token")', 'Your Token', '', 20),
(176, 'security-validate', 'Validar', 'Validate', '', 20),
(177, 'security-no-token', 'Por favor ingrese el pin desde su aplicación de 2FA.', 'Please enter the token from your 2FA app.', '', 20),
(178, 'security-success-message', 'Se ha configurado autenticación de dos factores exitósamente.', 'Congratulations. You are now set up to use two-factor authentication.', '', 20),
(179, 'security-verified', 'Verificado', 'Verified', '', 20),
(180, 'security-change-number', 'Cambiar de número', 'Change Number', '', 20),
(181, 'security-send-sms', 'Enviar por SMS', 'Send By SMS', '', 20),
(182, 'security-dont-ask', 'No me pidan esto por 30 di­as', 'Don''t ask me for this for 30 days', '', 20),
(183, 'verify-token', 'Autenticación', 'Authentication', '', 20),
(184, 'login-required-error', 'es un campo requerido.', 'is a required field.', '', 104),
(185, 'login-email-error', 'Debe ingresar un email válido.', 'You must enter a valid email.', '', 104),
(186, 'login-password-error', 'Su contraseña debe tener al menos 8 caracteres. La mayorÃ­a de los caracteres especiale son permitidos.', 'Your password must have at least 8 characters. Most special chars are permitted.', '', 104),
(187, 'settings-personal-info', 'Información personal', 'Personal Info', '', 104),
(188, 'settings-pass', 'Contraseña', 'Password', '', 104),
(189, 'settings-pass-confirm', 'Confirmar Contraseña', 'Confirm Password', '', 104),
(190, 'settings-first-name', 'Nombre', 'First Name', '', 104),
(191, 'settings-last-name', 'Apellido', 'Last Name', '', 104),
(192, 'settings-country', 'País', 'Country', '', 104),
(193, 'settings-email', 'Email', 'Email', '', 104),
(194, 'settings-save-info', 'Guardar info', 'Save Info', '', 104),
(195, 'settings-personal-message', 'Su información personal ha sido actualizada.', 'Your personal info has been updated.', '', 104),
(196, 'settings-withdrawal-2fa-btc', 'Confirmar retiros de BTC con autenticación de dos factores.', 'Confirm BTC withdrawals with two-factor authentication.', '', 104),
(197, 'settings-withdrawal-email-btc', 'Confirmar retiros de BTC por email.', 'Confirm BTC withdrawals by email.', '', 104),
(198, 'settings-withdrawal-2fa-bank', 'Confirmar retiros bancarios con autenticación de dos factores.', 'Confirm bank withdrawals with two-factor authentication.', '', 104),
(199, 'settings-withdrawal-email-bank', 'Confirmar retiros bancarios por email.', 'Confirm bank withdrawals by email.', '', 104),
(200, 'settings-notify-deposit-btc', 'Notificar por email cuando se deposita BTC.', 'Notify by email when BTC deposits are made.', '', 104),
(201, 'settings-notify-deposit-bank', 'Notificar por email cuando se deposita por banca.', 'Notify by email when bank deposits are made.', '', 104),
(202, 'settings-conf', 'Seguridad y notificaciones', 'Security and Notifications', '', 104),
(203, 'settings-save-settings', 'Guardar preferencias', 'Save Settings', '', 104),
(204, 'fee-schedule-fee', 'Comisión de tomador (taker)', 'Taker Fee', '', 16),
(205, 'fee-schedule-volume', 'Volumen a 30 di­as en', '30 day volume in', '', 16),
(206, 'contact-inquiries', 'Para consultas generales', 'For General Inquiries', '', 26),
(207, 'settings-company', 'Compañí­a', 'Company', '', 26),
(208, 'settings-subject', 'Tema', 'Subject', '', 26),
(209, 'settings-message', 'Su mensaje', 'Your Message', '', 26),
(210, 'settings-capcha', 'Por favor copiar el texto de verificación', 'Please copy the verification text', '', 26),
(211, 'contact-send', 'Enviar mensaje', 'Send Message', '', 26),
(212, 'login-capcha-error', 'El texto de verificación no concuerda con la imágen.', 'The verification text does not match the image.', '', 26),
(213, 'email-send-error', 'Ocurrió un error y el email no se pudo enviar. Por favor inténtelo más tarde.', 'An error ocurred and your message could not be sent. Please try again later.', '', 26),
(214, 'contact-message', 'Gracias por contactarnos. Le responderemos lo más rápido posible.', 'Thank you for getting in contact with us. We will respond to your message as soon as possible.', '', 26),
(215, 'bank-accounts', 'Cuentas Bancarias', 'Bank Accounts', '', 0),
(216, 'bank-accounts-add', 'Agregar Cuenta', 'Add Account', '', 215),
(217, 'bank-accounts-account', 'Num. de cuenta', 'Account Num.', '', 215),
(218, 'bank-accounts-description', 'Descripción', 'Description', '', 215),
(219, 'bank-accounts-remove', 'Eliminar', 'Remove', '', 215),
(220, 'bank-accounts-no', 'No hay cuentas bancarias asociadas a su perfil.', 'There are no bank accounts associated with your profile.', '', 215),
(221, 'bank-accounts-add-label', 'Agregar cuenta Crypto Capital', 'Add Crypto Capital Account', '', 215),
(222, 'bank-accounts-account-cc', 'Número de cuenta Crypto Capital', 'Crypto Capital Account Number', '', 215),
(223, 'bank-accounts-add-account', 'Afiliar Cuenta', 'Add Account', '', 215),
(224, 'bank-accounts-already-exists', 'La cuenta especificada ya está asociada con su perfil.', 'That account is already associated with your profile.', '', 215),
(225, 'bank-accounts-invalid-number', 'Número de cuenta inválido.', 'Invalid account number.', '', 215),
(226, 'bank-accounts-crypto-label', 'Cuenta Crypto Capital', 'Crypto Capital Account', '', 215),
(227, 'bank-accounts-added-message', 'La cuenta ha sido afiliada exitósamente.', 'The account has been added successfully.', '', 215),
(228, 'bank-accounts-remove-error', 'La cuenta especificada no está asociada con su perfil.', 'The specified account is not associated with your profile.', '', 215),
(229, 'bank-accounts-removed-message', 'La cuenta ha sido eliminada.', 'The account was removed successfully.', '', 215),
(230, 'account-functions', 'Funciones', 'Account Functions', '', 17),
(231, 'bitcoin-addresses', 'Direcciones Bitcoin', 'Bitcoin Addresses', '', 0),
(232, 'bitcoin-addresses-add', 'Obtener nueva dirección', 'Get New Address', '', 231),
(233, 'bitcoin-addresses-date', 'Fecha y hora', 'Date and Time', '', 231),
(234, 'bitcoin-addresses-address', 'Dirección', 'Address', '', 231),
(235, 'bitcoin-addresses-no', 'No tiene direcciones Bitcoin. Por favor genere uno nuevo.', 'You have no Bitcoin addresses. Please generate a new one.', '', 231),
(236, 'bitcoin-addresses-added', 'Una nueva dirección fue agregada.', 'A new address was added.', '', 231),
(237, 'bitcoin-addresses-too-soon', 'Sólo se puede agregar una nueva dirección de Bitcoin cada 24 horas.', 'You can only add one new Bitcoin address every 24 hours.', '', 231),
(238, 'bank-accounts-no-currency', 'Debe especificar la moneda que utiliza la cuenta.', 'You must specify the account currency.', '', 215),
(239, 'bank-accounts-currency', 'Moneda', 'Currency', '', 215),
(240, 'bank-accounts-already-associated', 'La cuenta especificada ya está asociada con otro perfil.', 'That account is already associated with another profile.', '', 215),
(241, 'deposit-bitcoins', 'Depositar bitcoins', 'Deposit Bitcoins', '', 22),
(242, 'deposit-send-to-address', 'Enví­e bitcoins a esta dirección', 'Send Bitcoins to This Address', '', 22),
(243, 'deposit-manage-addresses', 'Administrar direcciones Bitcoin', 'Manage Bitcoin addresses', '', 22),
(244, 'deposit-fiat-instructions', 'Depositar monedas fiduciarias', 'Deposit Fiat Currency', '', 22),
(245, 'deposit-fiat-account', 'Cuenta bancaria para utilizar', 'Bank Account to Use', '', 22),
(246, 'deposit-manage-bank-accounts', 'Administrar cuentas bancarias', 'Manage bank accounts', '', 22),
(247, 'deposit-recent', 'Depósitos recientes', 'Recent Deposits', '', 22),
(248, 'deposit-date', 'Fecha y hora', 'Date and Time', '', 22),
(249, 'deposit-description', 'Descripción', 'Description', '', 22),
(250, 'deposit-amount', 'Cantidad', 'Amount', '', 22),
(251, 'deposit-status', 'Estatus', 'Status', '', 22),
(252, 'withdraw-bitcoins', 'Retirar bitcoins', 'Withdraw Bitcoins', '', 23),
(253, 'withdraw-send-to-address', 'Dirección a enviar', 'Send to Address', '', 23),
(254, 'withdraw-send-amount', 'Cantidad a enviar', 'Amount to Send', '', 23),
(255, 'withdraw-send-bitcoins', 'Enviar bitcoins', 'Send Bitcoins', '', 23),
(256, 'withdraw-fiat', 'Retirar moneda fiduciaria', 'Withdraw Fiat Currency', '', 23),
(257, 'withdraw-fiat-account', 'Cuenta bancaria receptora', 'Receiving Bank Account', '', 23),
(258, 'withdraw-currency', 'Moneda a retirar', 'Withdrawal Currency', '', 23),
(259, 'withdraw-amount', 'Cantidad a retirar', 'Amount to Withdraw', '', 23),
(260, 'withdraw-withdraw', 'Retirar dinero', 'Withdraw Currency', '', 23),
(261, 'deposit-no', 'No se han hecho depósitos a esta cuenta.', 'You have not made any deposits.', '', 22),
(262, 'withdraw-no', 'No se han efectuado retiros desde esta cuenta.', 'No withdrawals have been made.', '', 23),
(263, 'withdraw-no-account', 'Debe especificar a que cuenta desea retirar.', 'You must specify the withdrawal account.', '', 23),
(264, 'withdraw-account-not-found', 'La cuenta especificada no existe.', 'The specified account does not exist.', '', 23),
(265, 'withdraw-amount-zero', 'Por favor especificar una cantidad mayor a cero para retirar.', 'Please specify an amount to withdraw greater than zero.', '', 23),
(266, 'withdraw-account-not-associated', 'La cuenta especificada no está asociada con su perfil.', 'The specified account is not associated with your profile.', '', 23),
(267, 'withdraw-too-much', 'La cantidad a retirar excede los fondos disponibles.', 'The withdrawal amount exceeds your available funds.', '', 23),
(268, 'withdraw-email-notice', 'Se requiere acción de su parte para autorizar este retiro. Por favor siga el vínculo que recibió en su email.', 'Further action is required to authorize this request. Please follow the link that you received in your email to authorize this transaction.', '', 23),
(269, 'withdraw-sms-sent', 'Se le ha enviado un código de autorización por SMS.', 'An SMS message has been sent to you with the authorization code.', '', 23),
(270, 'withdraw-2fa-success', 'Su solicitud de retiro ha sido autorizada exitósamente.', 'Your withdrawal request has been authorized successfully.', '', 23),
(271, 'security-resend-sms', 'Reenviar SMS', 'Resend SMS', '', 20),
(272, 'withdraw-address-invalid', 'La dirección Bitcoin especificada es inválida.', 'You have specified an invalid Bitcoin address.', '', 23),
(273, 'withdraw-btc-request', 'Su solicitud de retiro se ha creado. Sus bitcoins serán enviados próximamente.', 'Your withdrawal request has been created successfully. Your bitcoins will be sent shortly.', '', 23),
(274, 'withdraw-btc-com-error', 'Ocurrió un error de sistema y la transacción no se pudo enviar. Por favor inténtelo de nuevo más tarde.', 'An error ocurred and your transaction could not be sent. Please try again later.', '', 23),
(275, 'withdraw-btc-success', 'Su retiro de bitcoins ha sido enviada exitósamente.', 'Your Bitcoin withdrawal was sent successfully.', '', 23),
(276, 'withdraw-success', 'Su solicitud de retiro se ha creado exitósamente.', 'Your withdrawal request has been created successfully.', '', 23),
(277, 'settings-user', 'Usuario', 'Username', '', 104),
(278, 'settings-unique-error', 'Ya existe una cuenta asociada al email especificado.', 'There is already an account associated with that email address.', '', 104),
(279, 'settings-registration-info', 'Información de registro', 'Registration Info', '', 104),
(280, 'register-success', 'Gracias por registrarse para utilizar [exchange_name]. Sus nombre de usuario y contraseña fueron enviados a su email.', 'Thank you for registering to use [exchange_name]! Your username and password have been sent to you by email.', '', 27),
(281, 'settings-request-expired', 'Error: La solicitud ha expirado.', 'Error: Request has expired.', '', 104),
(282, 'settings-settings-message', 'Sus preferencias personales se han actualizado.', 'Your personal settings have been updated.', '', 104),
(283, 'account-security-notify', 'Este demo utiliza bitcoins de Testnet (prueba). Puede depositar o retirar bitcoins de Testnet.', 'This demo is using Testnet bitcoins. You can transfer Testnet bitcoins in and out of the application.', '', 17),
(284, 'sell-errors-no-amount', 'Debe ingresar una cantidad mayor a cero para vender.', 'You must enter an amount greater than zero to sell.', '', 17),
(285, 'settings-change-notice', 'Se requiere acción de su parte para autorizar los cambios en su cuenta. Por favor siga el vínculo que recibió en su email.', 'Further action is required to authorize these changes. Please follow the link that you received in your email to authorize.', '', 104),
(286, 'login-password-compare', 'La contraseña ingresada no concuerda con la verificación.', 'The password you have entered does not match the verification.', '', 104),
(287, 'transactions-download', 'Bajar transacciones en archivo CSV', 'Download transctions CSV file', '', 17),
(288, 'first-login', 'Primer login', 'First Login', '', 104),
(289, 'settings-save-password', 'Cambiar contraseña', 'Set Password', '', 104),
(290, 'settings-personal-password', 'Personalizar contraseña', 'Personalize Password', '', 104),
(291, 'settings-pass-explain', 'Por favor especifique una contraseña para su nueva cuenta. Si no lo hace, lo puede hacer luego en la página de preferencias. ', 'Please specify a password for your new account. If you do not do so, you can still change it later in the settings page.', '', 104),
(292, 'settings-notify-login', 'Notificar por email cuando alguien hace login a su cuenta.', 'Notify by email when somebody logs into your account.', '', 104),
(293, 'orders-delete', 'Cancelar esta órden', 'Cancel this order', '', 9),
(294, 'orders-not-yours', 'Usted no puede cancelar una órden que no es suya.', 'You cannot cancel somebody else''s order.', '', 9),
(295, 'orders-order-cancelled', 'La órden especificada ha sido cancelada.', 'The selected order has been cancelled.', '', 9),
(296, 'orders-order-doesnt-exist', 'La órden especificada ya ha sido ejecutada o no existe.', 'The order you have specified has been executed already or does not exist.', '', 9),
(297, 'confirm-transaction', 'Confirmar detalles de transacción', 'Confirm Transaction Details', '', 17),
(298, 'confirm-buy', 'Confirmar compra', 'Confirm Buy', '', 17),
(299, 'confirm-sale', 'Confirmar venta', 'Confirm Sale', '', 17),
(300, 'confirm-back', 'Atrás', 'Back', '', 17),
(301, 'settings-terms-accept', 'Acepto los <a href="terms.php">términos y condiciones</a> de uso de sitio.', 'I accept the <a href="terms.php">terms and conditions</a> of use of this site.', '', 104),
(302, 'settings-terms-error', 'Debe aceptar los <a href="terms.php">términos de uso</a> para registrarse como usuario.', 'You must accept the <a href="terms.php">terms of use</a> to register.', '', 104),
(303, 'settings-delete-account', 'Desactivar mi cuenta', 'Deactivate My Account', '', 104),
(304, 'settings-delete-account-explain', 'Usted puede desactivar su cuenta pulsando en este botón. Si decide que desea reactivar su cuenta, lo puede hacer en cualquier momento ingresando a su cuenta y pulsando sobre el botón de reactivación.', 'By clicking this button, you can deactivate your account. If you change your mind, you can reactivate your account at any time by logging in.', '', 104),
(305, 'settings-account-deactivated', 'Su cuenta ha sido desactivada. Recuerde que lo puede reactivar de nuevo desde esta misma página.', 'Your account has been deactivated. Remember that you can reactivated again from this page if you decide to do so..', '', 104),
(306, 'settings-deactivate-error', 'Las cuentas que todavía mantienen fondos en BTC o cualquiér otra moneda no se pueden desactivar.', 'Accounts that still have funds in BTC or any other currency cannot be deactivated.', '', 104),
(307, 'settings-reactivate-account', 'Reactivar mi cuenta', 'Reactivate My Account', '', 104),
(308, 'settings-reactivate-account-explain', 'Al pulsar en este botón, podrá reactivar su cuenta desactivada, lo cual le dará acceso a toda funcionalidad otra vez.', 'By clicking this button, you can reactivate your deactivated account, enabling all functionality once again.', '', 104),
(309, 'settings-account-reactivated', 'Su cuenta se ha reactivado exitósamente.', 'Your account has been reactivated successfully.', '', 104),
(310, 'settings-lock-account', 'Bloquear mi cuenta', 'Lock My Account', '', 104),
(311, 'settings-lock-account-explain', 'Al pulsar en este botón, podrá bloquear su cuenta para deshabilitar toda funcionalidad. Podrá desbloquear lo luego ingresando a esta misma página.', 'By clicking this button, you can lock your account so that all actions will be disabled. You can unlock it from this same page.', '', 104),
(312, 'settings-unlock-account', 'Desbloquear mi cuenta', 'Unlock My Account', '', 104),
(313, 'settings-unlock-account-explain', 'Pulsando en este botón podrá desbloquear su cuenta y reactivar toda funcionalidad.', 'By clicking this button you can unlock your account and re-enable all functionality.', '', 104),
(314, 'settings-account-locked', 'Su cuenta ha sido bloqueada. Lo puede desbloquear visitando esta misma página.', 'Your account has been locked. You can unlock it by visiting this same page.', '', 104),
(315, 'settings-account-unlocked', 'Su cuenta ha sido desbloqueada.', 'Your account is now unlocked.', '', 104),
(316, 'securing-account', '¿Cómo asegurar su cuenta?', 'Securing Your Account', '', 9),
(317, 'funding-account', '¿Cómo obtener fondos?', 'Funding Your Account', '', 9),
(318, 'withdrawing-account', '¿Cómo retirar fondos?', 'Withdrawing Funds', '', 9),
(319, 'buy-errors-no-bank-account', '¿Está seguro que desea recibir [currency]? Sin una cuenta bancaria en [currency], no podrá retirar este dinero.', 'Are you sure that you want to receive [currency]? Without an account in [currency], you will not be able to withdraw this money.', '', 17),
(320, 'all-currencies', 'Todos', 'All', '', 17),
(321, 'withdrawal-recent', 'Retiros recientes', 'Recent Withdrawals', '', 23),
(322, 'security-enable-google', 'Habilitar Google Authenticator', 'Enable Google Authenticator', '', 20),
(329, 'reset-2fa', 'Reiniciar autent. de dos factores', 'Resetting 2FA', '', 9),
(327, 'security-disable', 'Inhabilitar Autenticación', 'Disable 2FA', '', 20),
(328, 'security-disabled-message', 'Su cuenta ya no esta protegida por autenticación de dos factores.', 'Your account is no longer protected by two-factor authentication.', '', 20),
(326, 'security-incorrect-token', 'PIN incorrecto.', 'Incorrect token.', '', 20),
(325, 'security-optional-google', 'Opcional para Google Auth.', 'Optional for Google Auth.', '', 20),
(323, 'security-scan-qr', 'Verificar Google Authenticator', 'Verify Google Authenticator', '', 20),
(324, 'security-secret-code', 'Código secreto', 'Secret Code', '', 20),
(330, 'buy-errors-no-compatible', 'No es posible crear una órden de mercado porque no hay órdenes compatibles en el sistema.', 'You cannot create a market order because there are no compatible orders available.', '', 17),
(331, 'buy-errors-too-little', 'La cantidad mínima para una órden es [fa_symbol][amount].', 'The minimum order quantity is [fa_symbol][amount].', '', 17),
(350, 'orders-converted-from', 'Esta órden ha sido convertida desde otra moneda ([currency]).', 'This order has been converted from a different currency ([currency]).', '', 17),
(351, 'account-fee-bracket1', 'Tasa de comisión (fijador)', 'Commission rate (maker)', '', 17),
(352, 'account-global-btc', 'Vol. BTC 24h en casa de cambio', 'Exchange-wide 24h BTC volume', '', 17),
(353, 'limit-min-price', 'El precio mínimo es [price] debido a una órden suya en otra moneda.', 'The minimum price is [price] because of your order in a different currency.', '', 17),
(354, 'limit-max-price', 'El precio máximo es [price] debido a una órden suya en otra moneda.', 'The maximum price is [price] because of your order in a different currency.', '', 17),
(355, 'fee-schedule-fee1', 'Comisión de fijador (maker)', 'Maker Fee', '', 16),
(356, 'fee-schedule-flc', 'CTC* - Volúmen global 24h', 'FLC* - 24h Global Volume', '', 16),
(358, 'default-currency', 'Moneda por defecto', 'Default Currency', '', 27);

-- --------------------------------------------------------

--
-- Table structure for table `monthly_reports`
--

CREATE TABLE IF NOT EXISTS `monthly_reports` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `date` datetime NOT NULL,
  `transactions_btc` double(10,2) NOT NULL,
  `avg_transaction_size_btc` double(10,2) NOT NULL,
  `transaction_volume_per_user` double(10,2) NOT NULL,
  `total_fees_btc` double(10,2) NOT NULL,
  `fees_per_user_btc` double(10,2) NOT NULL,
  `gross_profit_btc` double(10,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE IF NOT EXISTS `news` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title_en` varchar(255) NOT NULL,
  `title_es` varchar(255) NOT NULL,
  `date` datetime NOT NULL,
  `content_en` blob NOT NULL,
  `content_es` blob NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE IF NOT EXISTS `orders` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `date` datetime NOT NULL,
  `order_type` int(10) NOT NULL,
  `site_user` int(10) NOT NULL,
  `btc` double(16,8) unsigned NOT NULL,
  `fiat` double(10,2) NOT NULL,
  `currency` int(10) NOT NULL,
  `btc_price` double(10,2) NOT NULL,
  `market_price` enum('Y','N') NOT NULL DEFAULT 'N',
  `log_id` int(10) NOT NULL,
  `stop_price` double(10,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `date` (`date`),
  KEY `site_user` (`site_user`),
  KEY `currency` (`currency`),
  KEY `btc_price` (`btc_price`),
  KEY `market_price` (`market_price`),
  KEY `order_type` (`order_type`),
  KEY `stop_price` (`stop_price`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `order_log`
--

CREATE TABLE IF NOT EXISTS `order_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `date` datetime NOT NULL,
  `site_user` int(10) NOT NULL,
  `order_type` int(10) NOT NULL,
  `btc` double(16,8) NOT NULL,
  `market_price` enum('Y','N') NOT NULL DEFAULT 'N',
  `btc_price` double(10,2) NOT NULL,
  `fiat` double(10,2) NOT NULL,
  `currency` int(10) NOT NULL,
  `p_id` int(10) NOT NULL,
  `stop_price` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `order_types`
--

CREATE TABLE IF NOT EXISTS `order_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `name_en` varchar(255) NOT NULL,
  `name_es` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `order_types`
--

INSERT INTO `order_types` (`id`, `name`, `name_en`, `name_es`) VALUES
(1, 'Bid', 'Bid', 'Oferta'),
(2, 'Ask', 'Ask', 'Demanda');

-- --------------------------------------------------------

--
-- Table structure for table `requests`
--

CREATE TABLE IF NOT EXISTS `requests` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `date` datetime NOT NULL,
  `site_user` int(10) NOT NULL,
  `currency` int(10) NOT NULL,
  `amount` double(20,8) unsigned NOT NULL,
  `description` int(10) NOT NULL,
  `request_status` int(10) NOT NULL,
  `request_type` int(10) NOT NULL,
  `address_id` int(10) unsigned NOT NULL,
  `account` bigint(20) unsigned NOT NULL,
  `send_address` varchar(255) NOT NULL,
  `transaction_id` varchar(255) NOT NULL,
  `increment` double(10,2) NOT NULL,
  `done` enum('Y','N') NOT NULL DEFAULT 'N',
  `crypto_id` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `crypto_id` (`crypto_id`),
  KEY `date_2` (`date`),
  KEY `site_user` (`site_user`),
  KEY `currency` (`currency`),
  KEY `request_status` (`request_status`),
  KEY `request_type` (`request_type`),
  KEY `done` (`done`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `request_descriptions`
--

CREATE TABLE IF NOT EXISTS `request_descriptions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name_en` varchar(255) NOT NULL,
  `name_es` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `request_descriptions`
--

INSERT INTO `request_descriptions` (`id`, `name_en`, `name_es`) VALUES
(1, 'Withdrawal to CryptoFinancial account', 'Retiro a cuenta CryptoFinancial'),
(2, 'Bitcoin withdrawal', 'Retiro de Bitcoin'),
(3, 'Deposit from CryptoFinancial account', 'DepÃ³sito desde cuenta CryptoFinancial'),
(4, 'Bitcoin deposit', 'DepÃ³sito de Bitcoin');

-- --------------------------------------------------------

--
-- Table structure for table `request_status`
--

CREATE TABLE IF NOT EXISTS `request_status` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name_en` varchar(255) NOT NULL,
  `name_es` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `request_status`
--

INSERT INTO `request_status` (`id`, `name_en`, `name_es`) VALUES
(1, 'Pending', 'Pendiente'),
(2, 'Completed', 'Completo'),
(3, 'Canceled', 'Cancelado'),
(4, 'Awaiting Authorization', 'Esperando autorizaciÃ³n');

-- --------------------------------------------------------

--
-- Table structure for table `request_types`
--

CREATE TABLE IF NOT EXISTS `request_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name_en` varchar(255) NOT NULL,
  `name_es` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `request_types`
--

INSERT INTO `request_types` (`id`, `name_en`, `name_es`) VALUES
(1, 'Withdrawal', 'Retiro'),
(2, 'Deposit', 'DepÃ³sito');

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

CREATE TABLE IF NOT EXISTS `sessions` (
  `session_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `session_start` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `session_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `session_key` varchar(255) NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `nonce` int(10) unsigned NOT NULL,
  `awaiting` enum('Y','N') NOT NULL,
  PRIMARY KEY (`session_id`),
  KEY `nonce` (`nonce`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE IF NOT EXISTS `settings` (
  `name` varchar(200) NOT NULL DEFAULT '',
  `value` text NOT NULL,
  PRIMARY KEY (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`name`, `value`) VALUES
('pass_regex', '/[a-zA-Z0-9]{4,}/'),
('verify_default_error', 'login-required-error'),
('verify_email_error', 'login-email-error'),
('verify_phone_error', 'You must enter a valid phone number.'),
('verify_file_type_error', 'Wrong file type.'),
('verify_file_size_error', 'Wrong file size.'),
('verify_file_misc_error', 'Error uploading file.'),
('verify_file_required_error', 'You must attach a file.'),
('verify_password_error', 'login-password-error'),
('verify_zip_error', 'You must enter a valid zip code.'),
('verify_date_error', '[field] must be in the valid range of dates.'),
('verify_custom_error', 'Invalid entry for [field].'),
('verify_cat_select_error', 'You must select at least [n] categories.'),
('verify_error_class', 'error'),
('req_img', '&lt;em&gt;*&lt;/em&gt;'),
('table_creation_error', 'Table could not be created.'),
('form_get_record_error', 'Record could not be fetched.'),
('form_save_error', 'Information could not be saved.'),
('form_update_error', 'Information could not be updated.'),
('file_save_error', 'The file could not be saved.'),
('alt_url_label', ' or url '),
('table_created', 'Successfully created database table.'),
('form_save_message', 'Form saved.'),
('form_update_message', 'Record [field] updated.'),
('file_save_message', 'Field [field] saved succesfully.'),
('temp_file_location', 'tempfiles/'),
('default_upload_location', 'uploads/'),
('accepted_file_formats', ''),
('accepted_image_formats', 'a:4:{i:1;s:4:&quot;jpeg&quot;;i:2;s:3:&quot;gif&quot;;i:3;s:3:&quot;png&quot;;i:4;s:3:&quot;jpg&quot;;}'),
('accepted_audio_formats', 'a:2:{i:1;s:3:&quot;mp3&quot;;i:2;s:3:&quot;wma&quot;;}'),
('image_sizes', 'a:3:{s:5:&quot;small&quot;;a:2:{s:6:&quot;height&quot;;s:2:&quot;50&quot;;s:5:&quot;width&quot;;s:2:&quot;50&quot;;}s:6:&quot;medium&quot;;a:2:{s:6:&quot;height&quot;;s:3:&quot;165&quot;;s:5:&quot;width&quot;;s:3:&quot;165&quot;;}s:5:&quot;large&quot;;a:2:{s:6:&quot;height&quot;;s:3:&quot;286&quot;;s:5:&quot;width&quot;;s:3:&quot;490&quot;;}}'),
('ajax_confirm_delete', 'Are you sure you want to delete this?'),
('pm_copy_wrong_class', 'Cannot paste.'),
('pmt_record_files', 'Record: Show Uploaded Files'),
('subtotal_label', 'Page Total'),
('subavg_label', 'Page Average'),
('total_label', 'Grand Total'),
('avg_label', 'Grand Average'),
('pmt_grid_aggregate', 'Grid: Aggregate Field'),
('date_picker_icon', '../shared/images/date_picker.gif'),
('date_picker_css', '../shared/css/date_picker.css'),
('default_date_format', 'n/j/Y'),
('placeholder_image', 'images/placeholder.gif'),
('gallery_left_arrow', '&lt;'),
('gallery_right_arrow', '&gt;'),
('grid_no_table_error', 'Table [field] does not exist.'),
('grid_no_field_error', 'Field [field] does not exist.'),
('grid_no_results', 'No results to show.'),
('pagination_label', 'Showing [results] results on [num_pages] pages.'),
('pmt_grid_tokenizer', 'Grid: Tokenizer Filter'),
('pmt_calendar_autocomplete', 'Calendar: Autocomplete Filter'),
('pmt_calendar_tokenizer', 'Calendar: Tokenizer Filter'),
('pmt_calendar_checkbox', 'Calendar: Checkbox Filter'),
('pmt_calendar_select', 'Calendar: Select Filter'),
('print_icon', '&lt;img src=&quot;css/basic/print.png&quot;&gt;'),
('pm_decouple_cancel', 'Y'),
('pm_cancel_back', 'Y'),
('pmt_form_cancel_button', 'Form: Cancel Button'),
('pmt_record_cancel_button', 'Record: Cancel Button'),
('pmt_record_button', 'Record: Button'),
('pmt_form_file_multiple', 'Form: File Input (Multiple)'),
('my_account_button', 'My Account'),
('edit_tabs_this_button', 'Edit This Page'),
('path_ctrl', 'Control Panel'),
('back', 'Back'),
('forward', 'Forward'),
('up_directory', 'Up One Directory'),
('add_directory', 'Add New Folder'),
('add_step', 'Add New Step'),
('download_results', 'Download Results'),
('download_all', 'Download All Files'),
('save_order', 'Save Order'),
('user_unique_error', '[field] must have a unique value.'),
('user_username', 'Username'),
('user_password', 'Password'),
('user_last_name', 'Last Name'),
('user_phone', 'Phone'),
('user_email', 'Email'),
('user_group', 'Group'),
('user_group_name', 'Name'),
('user_is_admin', 'Is Admin?'),
('comments_action_2_short', 'edit&Atilde;&sup3; el record.'),
('comments_action_3_short', 'cre&Atilde;&sup3; el record.'),
('comments_action_4_short', 'mando el record al paso &lt;b&gt;[documentos.paso_id,pasos.step_order,pasos.name]&lt;/b&gt;'),
('comments_action_5_short', ''),
('pmt_grid_label', 'Grid: Label'),
('pmt_filemanager', 'File Manager Control'),
('pmt_filemanager_add_table', 'File Manager: Add Table'),
('pmt_redirect', 'Redirect Control'),
('pmt_flowchart', 'Flow Chart Control'),
('user_first_name', 'First Name'),
('path_attributes', 'Attributes'),
('path_message', 'Message'),
('path_error', 'Error'),
('path_prompt', 'Confirm'),
('first_page_text', '&lt; First'),
('last_page_text', 'Last &gt;'),
('results_per_page_text', 'Results per page: '),
('search_text', 'Search:'),
('filter_submit_text', 'Filter'),
('rows_per_page', '30'),
('move_hover_caption', 'Move'),
('view_hover_caption', 'View'),
('save_caption', 'Save'),
('email_send_error', 'email-send-error'),
('save_button', 'Guardar Cambios'),
('save_icon', '&lt;img src=&quot;css/basic/save.png&quot;&gt;'),
('delete_hover_caption', 'Delete'),
('home_icon', '&lt;img title=&quot;Home&quot; src=&quot;css/organic/home.png&quot; /&gt;'),
('dragdrop_add_child_button', 'Add Child'),
('edit_tabs_button', 'Edit Pages'),
('edit_page_button', '&lt;img title=&quot;Configure&quot; src=&quot;css/organic/configure.png&quot; /&gt;'),
('x_button', 'x'),
('ok_button', 'OK'),
('cancel_button', 'Cancel'),
('logout_button', 'Log Out'),
('path_separator', ' / '),
('path_edit_tabs', 'Pages and Tabs'),
('path_edit', 'Edit'),
('path_view', 'View'),
('path_users', 'Users and Groups'),
('path_settings', 'Settings'),
('ajax_save_message', 'The information was saved succesfully.'),
('ajax_save_error', 'Information could not be saved.'),
('ajax_insert_error', 'Record could not be created.'),
('ajax_delete_error', 'Record could not be deleted.'),
('login_empty_user', 'login-user-empty-error'),
('login_empty_pass', 'login-password-empty-error'),
('login_invalid', 'login-invalid-login-error'),
('no_database_error', 'No database to select.'),
('pm_list_tab', 'List'),
('pm_form_tab', 'Form'),
('pm_record_tab', 'Record'),
('pmt_list', 'List Control'),
('pmt_list_add_table', 'List: Add Table'),
('pmt_grid', 'Grid Control'),
('pmt_grid_field', 'Grid: Field'),
('pmt_grid_autocomplete', 'Grid: Autocomplete Filter'),
('pmt_grid_cats', 'Grid: Categories Filter'),
('pmt_grid_checkbox', 'Grid: Checkbox Filter'),
('pmt_grid_date_end', 'Grid: EndDate Filter'),
('pmt_grid_date_start', 'Grid: StartDate Filter'),
('pmt_grid_first_letter', 'Grid: FirstLetter Filter'),
('pmt_grid_per_page', 'Grid: ResultsPerPage Filter'),
('pmt_grid_radio', 'Grid: Radio Filter'),
('pmt_grid_search', 'Grid: Search Filter'),
('pmt_grid_select', 'Grid: Select Filter'),
('pmt_form', 'Form Control'),
('pmt_form_text_input', 'Form: Text Input'),
('pmt_form_text_editor', 'Form: Text Editor'),
('pmt_form_text_area', 'Form: Text Area'),
('pmt_form_auto_complete', 'Form: Autocomplete'),
('pmt_form_button', 'Form: Button'),
('pmt_form_cat_select', 'Form: Category Select'),
('pmt_form_checkbox', 'Form: Checkbox'),
('pmt_form_date_widget', 'Form: Date Input'),
('pmt_form_end_fieldset', 'Form: End Fieldset'),
('pmt_form_end_group', 'Form: End Group'),
('pmt_form_file_input', 'Form: File Input'),
('pmt_form_gallery', 'Form: Gallery'),
('pmt_form_hidden_input', 'Form: Hidden Input'),
('pmt_form_password_input', 'Form: Password Input'),
('pmt_form_radio_input', 'Form: Radio Input'),
('pmt_form_reset_button', 'Form: Reset Button'),
('pmt_form_select_input', 'Form: Select Input'),
('pmt_form_start_fieldset', 'Form: Start Fieldset'),
('pmt_form_start_group', 'Form: Start Group'),
('pmt_form_submit_button', 'Form: Submit Button'),
('pmt_record', 'Record Control'),
('pmt_record_end_table', 'Record: End Table'),
('pmt_record_field', 'Record: Add Field'),
('pmt_record_gallery', 'Record: Gallery'),
('pmt_record_heading', 'Record: Heading'),
('pmt_record_image', 'Record: Image'),
('pmt_record_start_table', 'Record: Sutable'),
('pmt_gallery_image', 'Gallery: Image'),
('pmt_gallery_multiple', 'Gallery: Multiple'),
('pmt_tabs', 'Tabs Control'),
('pmt_tabs_make_tab', 'Tabs: Add Tab'),
('auto_create_table', 'Y'),
('file_icons', ''),
('add_new_caption', 'Add New'),
('print_caption', 'Print'),
('edit_hover_caption', 'Edit'),
('skin', 'black_blue'),
('logo', 'css/basic/logo.png'),
('verify_invalid_char_error', 'Invalid character for [field].'),
('capcha_error', 'login-capcha-error'),
('compare_error', 'login-password-compare'),
('value_exists_error', 'login-user-exists'),
('default_timezone', 'America/Panama'),
('up', '&lt;img src=&quot;css/organic/up.gif&quot;&gt;'),
('down', '&lt;img src=&quot;css/organic/down.gif&quot;&gt;'),
('grid_activate_button', 'Set Active'),
('grid_deactivate_button', 'Set Inactive'),
('invalid_email_error', 'email-address-error'),
('email_sent_message', 'email-sent-message'),
('pmt_form_passive_field', 'Form: Passive Field'),
('pmt_form_colorpicker', 'Form: Color Picker'),
('pmt_form_colorpicker_nametext', 'Nombre del color...'),
('pmt_form_multiple', 'Form: Multiple'),
('delete_button_label', 'Delete Selected'),
('form_email', 'notifications@1btcxe.com'),
('form_email_from', '1BTCXE'),
('pmt_form_email_notify', 'Form: Email Notify'),
('pmt_form_start_area', 'Form: Start Area'),
('pmt_form_end_area', 'Form: End Area'),
('pmt_grid_month', 'Grid: Month Filter'),
('pmt_grid_year', 'Grid: Year Filter'),
('switch_to_graph', 'Swith to Bar Graph'),
('switch_to_grid', '&lt;img src=&quot;css/organic/table.png&quot;&gt;'),
('switch_to_list', 'Switch To List'),
('switch_to_table', 'Switch To Pie Graph'),
('name_column_label', 'classified by'),
('value_column_label', 'Show'),
('combine_label', 'Don\\''t classify'),
('switch_to_graph_line', 'Switch to Line Graph'),
('x_axis', 'over'),
('switch_to_graph_pie', 'Switch To Pie Graph'),
('pmt_form_create_record', 'Form: Create Record'),
('file_input_button', 'Browse &gt;'),
('pmt_form_grid', 'Form: Input Grid'),
('pmt_record_grid', 'Record: Inline Grid'),
('pmt_comments', 'Comments Control'),
('pmt_comments_setparams', 'Comments: Set Parameters'),
('comments_sent_message', 'Message sent.'),
('comments_there_are', 'There are [field] comments.'),
('comments_expand', 'Expandir.'),
('comments_hide', 'Ocultar.'),
('comments_none', 'No hay comentarios.'),
('comments_be_first', 'Be the first to add one.'),
('comments_no_url_error', 'No URL in submitted for comments.'),
('comments_no_record_error', 'No Record submitted for comments.'),
('comments_less_than_minute', 'hace menos de un minuto.'),
('comments_minutes_ago', 'hace [field] minutos'),
('comments_hours_ago', 'hace [field] horas'),
('comments_days_ago', 'hace [field] d&Atilde;&shy;as'),
('comments_months_ago', 'hace [field] meses'),
('comments_wrote_label', 'wrote:'),
('comments_reply_label', 'Responder'),
('comments_name_label', 'Nombre'),
('comments_email_label', 'Email'),
('comments_website_label', 'Sitio Web'),
('comments_comments_label', 'Comentarios'),
('comments_submit', 'Enviar'),
('comment_type_1', '&lt;img src=&quot;css/basic/comment.png&quot;&gt;'),
('comment_type_2', '&lt;img src=&quot;css/basic/edit_page.png&quot;&gt;'),
('comment_type_3', '&lt;img src=&quot;css/basic/add_page.png&quot;&gt;'),
('comment_type_4', '&lt;img src=&quot;css/basic/step_small.png&quot;&gt;'),
('comment_type_5', ''),
('comments_action_2', 'edit&Atilde;&sup3; los siguientes campos:'),
('comments_action_3', 'cre&Atilde;&sup3; el record:'),
('comments_action_4', 'mando el record al paso &lt;b&gt;[documentos.paso_id,pasos.step_order,pasos.name]&lt;/b&gt;'),
('comments_action_5', ''),
('comments_set_to', ''),
('comments_show_details', 'Mostrar detalles.'),
('comments_hide_details', 'Ocultar detalles.'),
('default_time_format', 'g:i a'),
('cal_week_from', 'Week from'),
('cal_week_until', 'until'),
('cal_today', 'Today'),
('cal_sun', 'Sun'),
('cal_mon', 'Mon'),
('cal_tue', 'Tue'),
('cal_wed', 'Wed'),
('cal_thur', 'Thu'),
('cal_fri', 'Fri'),
('cal_sat', 'Sat'),
('pmt_calendar', 'Calendar Control'),
('pmt_calendar_add_table', 'Calendar: Add Table'),
('pmt_calendar_field', 'Calendar: Add Field'),
('pmt_calendar_placeholder', 'Calendar: Placeholder Text'),
('locale', 'hebrew'),
('pmt_page_map', 'Page Map Control'),
('pagemap_nothing', 'No pages in this section.'),
('pmt_form_link', 'Form: Link'),
('pmt_record_link', 'Record: Link'),
('pm_ctrl_tab', 'Control Panel'),
('fck_css_file', ''),
('pmt_form_start_restricted', 'Form: Start Restricted'),
('pmt_form_end_restricted', 'Form: End Restricted'),
('pmt_form_aggregate', 'Form: Aggregate Value'),
('pmt_record_aggregate', 'Record: Aggregate Value'),
('pmt_form_indicator', 'Form: Indicator'),
('pmt_record_indicator', 'Record: Indicator'),
('pmt_grid_inline_form', 'Grid: Inline Form'),
('pmt_form_edit_record', 'Form: Edit Record'),
('gallery_desc_icon', 'css/basic/info.png'),
('gallery_desc_label', 'File description.'),
('gallery_desc_tooltip', 'Click to add a description.'),
('pmt_page_map_start_area', 'Page Map: Start Area'),
('pmt_page_map_end_area', 'Page Map: End Area'),
('print_button', 'Imprimir'),
('grid_delete_multiple', 'Delete selected elements?'),
('grid_change', 'Apply changes to selected elements?'),
('ajax_confirm_delete_sub', 'This will delete all sub-elements. Continue?'),
('pmt_form_include_page', 'Form: Include Page'),
('pmt_record_include_page', 'Record: Include Page'),
('ajax_synch', 'Are you sure you want to synch?'),
('pmt_synch', 'Synch With Form'),
('edit_button', '&lt;img title=&quot;Edit&quot; src=&quot;css/basic/edit.png&quot; /&gt;'),
('pm_exit', 'Salir del editor'),
('faux_no_options', 'No options to select.'),
('faux_editor_caption', 'This page'),
('grid_default_reset', 'Reset'),
('view_button', ''),
('move_button', ''),
('add_new_label', ''),
('add_new_button', ''),
('delete_button', ''),
('dragdrop_enabled_button', ''),
('dragdrop_disabled_button', ''),
('admin_button', 'Admin'),
('messages_yes_button', '[messages] new messages'),
('messages_no_button', 'No new messages.'),
('home_label', 'Home'),
('excel_add_new', ''),
('excel_table_label', ''),
('excel_upload_file_label', ''),
('excel_photos_label', ''),
('excel_next_label', ''),
('excel_records_updated_label', ''),
('excel_photos_updated_label', ''),
('excel_upload_date_label', ''),
('excel_user_label', ''),
('pmt_excel', 'Excel Uploader'),
('excel_invalid_file', ''),
('excel_invalid_table', ''),
('grid_until_label', 'until'),
('excel_template', ''),
('excel_upload_success_label', ''),
('excel_step1', ''),
('excel_step2', ''),
('excel_ignore_label', ''),
('excel_primary_label', ''),
('excel_photo_index_label', ''),
('excel_ignore_first_label', ''),
('excel_delete_all_label', ''),
('excel_update_label', ''),
('excel_auto_activate_label', ''),
('excel_template_label', ''),
('excel_update_message', ''),
('excel_not_update_message', ''),
('excel_no_primary_error', ''),
('excel_no_photo_index_error', ''),
('grid_view_filters', 'View Filters'),
('grid_hide_filters', 'Hide Filters'),
('grid_click_to_select', 'Cick to select...'),
('grid_n_selected', ' selected.'),
('pmt_form_start_tab', 'Form: Start Tab'),
('pmt_form_end_tab', 'Form: End Tab'),
('pmt_form_print_button', 'Form: Print Button'),
('pmt_calendar_add_new', 'Calendar: Add New Button'),
('cal_every', 'Every '),
('cal_day', 'day'),
('cal_dont_repeat', 'Don\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\''t repeat'),
('cal_view_month', 'View whole month');

-- --------------------------------------------------------

--
-- Table structure for table `settings_files`
--

CREATE TABLE IF NOT EXISTS `settings_files` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `f_id` int(10) unsigned NOT NULL,
  `ext` char(4) NOT NULL,
  `dir` varchar(255) NOT NULL,
  `url` text NOT NULL,
  `old_name` varchar(255) NOT NULL,
  `field_name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `f_id` (`f_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

-- --------------------------------------------------------

--
-- Table structure for table `site_users`
--

CREATE TABLE IF NOT EXISTS `site_users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pass` varchar(200) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `first_name` varchar(200) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `last_name` varchar(200) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) NOT NULL,
  `date` datetime NOT NULL,
  `tel` varchar(255) NOT NULL,
  `country` int(10) NOT NULL,
  `user` varchar(255) NOT NULL,
  `btc` double(20,8) unsigned NOT NULL,
  `usd` double(10,2) NOT NULL,
  `eur` double(10,2) NOT NULL,
  `cny` double(10,2) NOT NULL,
  `gbp` double(10,2) NOT NULL,
  `cad` double(10,2) NOT NULL,
  `jpy` double(10,2) NOT NULL,
  `rub` double(10,2) NOT NULL,
  `mxn` double(10,2) NOT NULL,
  `hkd` double(10,2) NOT NULL,
  `ils` double(10,2) NOT NULL,
  `inr` double(10,2) NOT NULL,
  `dkk` double(10,2) NOT NULL,
  `huf` double(10,2) NOT NULL,
  `lvl` double(10,2) NOT NULL,
  `ltl` double(10,2) NOT NULL,
  `nzd` double(10,2) NOT NULL,
  `nok` double(10,2) NOT NULL,
  `pln` double(10,2) NOT NULL,
  `ron` double(10,2) NOT NULL,
  `sgd` double(10,2) NOT NULL,
  `zar` double(10,2) NOT NULL,
  `sek` double(10,2) NOT NULL,
  `thb` double(10,2) NOT NULL,
  `try` double(10,2) NOT NULL,
  `czk` double(10,2) NOT NULL,
  `bgn` double(10,2) NOT NULL,
  `hrk` double(10,2) NOT NULL,
  `fee_schedule` int(10) NOT NULL,
  `country_code` int(10) NOT NULL,
  `authy_requested` enum('Y','N') NOT NULL DEFAULT 'N',
  `verified_authy` enum('Y','N') NOT NULL DEFAULT 'N',
  `authy_id` int(10) NOT NULL,
  `using_sms` enum('Y','N') NOT NULL DEFAULT 'N',
  `dont_ask_30_days` enum('Y','N') NOT NULL DEFAULT 'N',
  `dont_ask_date` datetime NOT NULL,
  `confirm_withdrawal_email_btc` enum('Y','N') NOT NULL DEFAULT 'N',
  `confirm_withdrawal_2fa_btc` enum('Y','N') NOT NULL DEFAULT 'N',
  `confirm_withdrawal_2fa_bank` enum('Y','N') NOT NULL DEFAULT 'N',
  `confirm_withdrawal_email_bank` enum('Y','N') NOT NULL DEFAULT 'N',
  `notify_deposit_btc` enum('Y','N') NOT NULL DEFAULT 'N',
  `notify_deposit_bank` enum('Y','N') NOT NULL DEFAULT 'N',
  `last_update` datetime NOT NULL,
  `no_logins` enum('Y','N') NOT NULL DEFAULT 'N',
  `notify_login` enum('Y','N') NOT NULL DEFAULT 'N',
  `deactivated` enum('Y','N') NOT NULL DEFAULT 'N',
  `locked` enum('Y','N') NOT NULL DEFAULT 'N',
  `ars` double(10,2) NOT NULL,
  `cop` double(10,2) NOT NULL,
  `mur` double(10,2) NOT NULL,
  `twd` double(10,2) NOT NULL,
  `google_2fa_code` varchar(255) NOT NULL,
  `verified_google` enum('Y','N') NOT NULL DEFAULT 'N',
  `last_lang` varchar(255) NOT NULL,
  `default_currency` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `pass` (`pass`,`user`),
  KEY `pass_2` (`pass`),
  KEY `user` (`user`),
  KEY `dont_ask_30_days` (`dont_ask_30_days`),
  KEY `dont_ask_date` (`dont_ask_date`),
  KEY `deactivated` (`deactivated`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

-- --------------------------------------------------------

--
-- Table structure for table `status`
--

CREATE TABLE IF NOT EXISTS `status` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `last_sweep` datetime NOT NULL,
  `deficit_btc` double(20,8) unsigned NOT NULL,
  `hot_wallet_btc` double(20,8) unsigned NOT NULL,
  `warm_wallet_btc` double(20,8) unsigned NOT NULL,
  `total_btc` double(20,8) unsigned NOT NULL,
  `received_btc_pending` double(20,8) unsigned NOT NULL,
  `pending_withdrawals` double(20,8) unsigned NOT NULL,
  `btc_escrow` double(20,8) unsigned NOT NULL,
  `usd_escrow` double(10,2) NOT NULL,
  `eur_escrow` double(10,2) NOT NULL,
  `cny_escrow` double(10,2) NOT NULL,
  `gbp_escrow` double(10,2) NOT NULL,
  `cad_escrow` double(10,2) NOT NULL,
  `jpy_escrow` double(10,2) NOT NULL,
  `rub_escrow` double(10,2) NOT NULL,
  `mxn_escrow` double(10,2) NOT NULL,
  `hkd_escrow` double(10,2) NOT NULL,
  `ils_escrow` double(10,2) NOT NULL,
  `inr_escrow` double(10,2) NOT NULL,
  `dkk_escrow` double(10,2) NOT NULL,
  `huf_escrow` double(10,2) NOT NULL,
  `lvl_escrow` double(10,2) NOT NULL,
  `ltl_escrow` double(10,2) NOT NULL,
  `nzd_escrow` double(10,2) NOT NULL,
  `nok_escrow` double(10,2) NOT NULL,
  `pln_escrow` double(10,2) NOT NULL,
  `ron_escrow` double(10,2) NOT NULL,
  `sgd_escrow` double(10,2) NOT NULL,
  `zar_escrow` double(10,2) NOT NULL,
  `sek_escrow` double(10,2) NOT NULL,
  `thb_escrow` double(10,2) NOT NULL,
  `try_escrow` double(10,2) NOT NULL,
  `czk_escrow` double(10,2) NOT NULL,
  `hrk_escrow` double(10,2) NOT NULL,
  `bgn_escrow` double(10,2) NOT NULL,
  `ars_escrow` double(10,2) NOT NULL,
  `cop_escrow` double(10,2) NOT NULL,
  `mur_escrow` double(10,2) NOT NULL,
  `twd_escrow` double(10,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `status`
--

INSERT INTO `status` (`id`, `last_sweep`, `deficit_btc`, `hot_wallet_btc`, `warm_wallet_btc`, `total_btc`, `received_btc_pending`, `pending_withdrawals`, `btc_escrow`, `usd_escrow`, `eur_escrow`, `cny_escrow`, `gbp_escrow`, `cad_escrow`, `jpy_escrow`, `rub_escrow`, `mxn_escrow`, `hkd_escrow`, `ils_escrow`, `inr_escrow`, `dkk_escrow`, `huf_escrow`, `lvl_escrow`, `ltl_escrow`, `nzd_escrow`, `nok_escrow`, `pln_escrow`, `ron_escrow`, `sgd_escrow`, `zar_escrow`, `sek_escrow`, `thb_escrow`, `try_escrow`, `czk_escrow`, `hrk_escrow`, `bgn_escrow`, `ars_escrow`, `cop_escrow`, `mur_escrow`, `twd_escrow`) VALUES
(1, '0000-00-00 00:00:00', 0.00000000, 0.00000000, 0.00000000, 0.00000000, 0.00000000, 0.00000000, 0.00000000, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00);

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE IF NOT EXISTS `transactions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `date` datetime NOT NULL,
  `site_user` int(10) NOT NULL,
  `btc` double(16,8) unsigned NOT NULL,
  `currency` int(10) unsigned NOT NULL,
  `btc_price` double(10,2) NOT NULL,
  `fiat` double(10,2) NOT NULL,
  `fee` double(16,8) unsigned NOT NULL,
  `transaction_type` int(10) NOT NULL,
  `site_user1` int(10) NOT NULL,
  `transaction_type1` int(10) NOT NULL,
  `fee1` double(16,8) unsigned NOT NULL,
  `btc_net` double(16,8) NOT NULL,
  `btc_net1` double(16,8) NOT NULL,
  `btc_before1` double(20,8) NOT NULL,
  `btc_after1` double(20,8) NOT NULL,
  `fiat_before1` double(10,2) NOT NULL,
  `fiat_after1` double(10,2) NOT NULL,
  `btc_before` double(20,8) NOT NULL,
  `btc_after` double(20,8) NOT NULL,
  `fiat_before` double(10,2) NOT NULL,
  `fiat_after` double(10,2) NOT NULL,
  `log_id1` int(10) NOT NULL,
  `log_id` int(10) NOT NULL,
  `fee_level` double(10,2) NOT NULL,
  `fee_level1` double(10,2) NOT NULL,
  `currency1` int(10) NOT NULL,
  `orig_btc_price` double(10,2) NOT NULL,
  `conversion_fee` double(10,2) NOT NULL,
  `convert_amount` double(10,2) NOT NULL DEFAULT '0.00',
  `convert_rate_given` double(10,2) NOT NULL DEFAULT '0.00',
  `convert_system_rate` double(10,2) NOT NULL DEFAULT '0.00',
  `convert_from_currency` int(10) NOT NULL DEFAULT '0',
  `convert_to_currency` int(10) NOT NULL DEFAULT '0',
  `conversion` enum('Y','N') NOT NULL DEFAULT 'N',
  PRIMARY KEY (`id`),
  KEY `date` (`date`),
  KEY `site_user` (`site_user`),
  KEY `currency` (`currency`),
  KEY `transaction_type` (`transaction_type`),
  KEY `site_user1` (`site_user1`),
  KEY `transaction_type1` (`transaction_type1`),
  KEY `currency1` (`currency1`),
  KEY `convert_from_currency` (`convert_from_currency`),
  KEY `convert_to_currency` (`convert_to_currency`),
  KEY `conversion` (`conversion`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `transaction_types`
--

CREATE TABLE IF NOT EXISTS `transaction_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name_en` varchar(255) NOT NULL,
  `name_es` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `transaction_types`
--

INSERT INTO `transaction_types` (`id`, `name_en`, `name_es`) VALUES
(1, 'Buy', 'Compra'),
(2, 'Sell', 'Venta');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
